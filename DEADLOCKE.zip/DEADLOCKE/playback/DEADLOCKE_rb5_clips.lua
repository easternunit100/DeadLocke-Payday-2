function DeadLocke:get_rb5_audiofiles()
	local voice = "rb5"
	local volume = 1.75
	self:create_and_add_to_playback_from_ids("v01",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "there_he_goes1_assault"),
					volume = volume
				}
			}
		}
	}, "both", voice)

	
	
	self:create_and_add_to_playback_from_ids("v02",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "whats_inside_here1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "whats_inside_here2"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	
	
	
	self:create_and_add_to_playback_from_ids("v03",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "your_move_bain_were_waiting1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "check_the_stairs1"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "check_the_stairs1_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	
	self:create_and_add_to_playback_from_ids("v06",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "dirty_business"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v07",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "no_way"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v09",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "were_on_the_clock"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time2"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time3"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time4"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time1_assault"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time2_assault"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time3_assault"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_old_hoxton", "its_about_time4_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	
	self:create_and_add_to_playback_from_ids("v12",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "thats_gonna_stall1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v14",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "vo_rb5_its_locked1_assault"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v15",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_old_hoxton", "vo_rb5_yes_done_now_lets_get_out"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
end