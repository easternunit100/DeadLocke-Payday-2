function DeadLocke:get_rb3_audiofiles()
	local voice = "rb3"	
	local volume = 1.75
	
	self:create_and_add_to_playback_from_ids("v01",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_off_to_daddy"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v02",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_whats_inside"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	
	
	self:create_and_add_to_playback_from_ids("v03",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_your_move_bain_we_are_waiting1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_check_stairs2"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_check_stairs1"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	self:create_and_add_to_playback_from_ids("v05",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_damn_more_cops1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_german", "vo_rb3_damn_more_cops2"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v06",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_dirty_business1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v07",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_no_way1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_german", "vo_rb3_no_way2"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v09",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "were_on_the_clock"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v10",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "where_is_the_safe1"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "its_about_time1"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "its_about_time1_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	self:create_and_add_to_playback_from_ids("v12",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "thats_gonna_stall1"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v12",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "thats_gonna_stall1_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	
	
	self:create_and_add_to_playback_from_ids("v13",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "oh_classic"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	
	
	
	self:create_and_add_to_playback_from_ids("v14",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_its_locked1_assault"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v15",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_yes_done_now_lets_get_out"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v15",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_german", "vo_rb3_yes_done_now_lets_get_out_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
end