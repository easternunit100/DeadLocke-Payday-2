function DeadLocke:get_rb4_audiofiles()
	local voice = "rb4"
	local volume = 1.75
	self:create_and_add_to_playback_from_ids("watchdogs_01",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_almost_done_with_lifting"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("watchdogs_02",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_alot_of_pigs"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("watchdogs_03",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "why_shooting_at_us1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_cops_shooting1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_what_the_hell_are_they_doing"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	
	self:create_and_add_to_playback_from_ids("v01",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_there_he_goes"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v01",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_there_he_goes_assault"),
					volume = volume
				}
			}
		}
	}, "assault", voice)	
	
	
	
	self:create_and_add_to_playback_from_ids("v02",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_whats_inside1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	
	
	self:create_and_add_to_playback_from_ids("v03",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_your_move_bain1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_check_stairs1"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	self:create_and_add_to_playback_from_ids("v04",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_check_stairs2"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	self:create_and_add_to_playback_from_ids("v05",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_damn_more_cops"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v06",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_dirty_bussiness1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v07",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_no_way1"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v08",{
		{
			slot = 1,
			slot_chance = 0.25,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_dallas_carries_bags1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_dallas_carries_bags2"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_dallas_carries_bags3"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_dallas_carries_bags4"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_dallas_carries_bags5"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v09",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "were_on_the_clock"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_about_time_assault1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_about_time_assault2"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_about_time_assault3"),
					volume = volume
				}
			}
		}
	}, "assault", voice)
	
	self:create_and_add_to_playback_from_ids("v11",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_about_time_control1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_rb4_about_time_control2"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	
	
	self:create_and_add_to_playback_from_ids("v12",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_russian_that_will_stall_us1"),
					volume = volume
				},
				{
					file = self:sounds_directory("char_russian", "vo_russian_that_will_stall_us2"),
					volume = volume
				},
			}
		}
	}, "both", voice)
	
	
	
	self:create_and_add_to_playback_from_ids("v13",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "whisper_hehe_clever"),
					volume = volume
				}
			}
		}
	}, "control", voice)
	
	
	self:create_and_add_to_playback_from_ids("v14",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_its_locked1_assault"),
					volume = volume
				}
			}
		}
	}, "both", voice)
	
	
	self:create_and_add_to_playback_from_ids("v15",{
		{
			slot = 1,
			file_data = {
				{
					file = self:sounds_directory("char_russian", "vo_rb4_yes_there_u_go_lets_blow"),
					volume = volume
				}
			}
		}
	}, "both", voice)
end