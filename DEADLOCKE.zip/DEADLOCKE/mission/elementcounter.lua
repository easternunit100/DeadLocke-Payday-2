DeadLocke.ElementCounterOperator = DeadLocke.ElementCounterOperator or blt_class(DeadLocke.MissionScriptElement)
local ElementCounterOperator = DeadLocke.ElementCounterOperator

function ElementCounterOperator:init(...)
	DeadLocke.ElementCounterOperator.super.init(self,...)
end

function ElementCounterOperator:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	local amount = self._values.amount

	for _, id in ipairs(self._values.elements) do
		local element = self:get_mission_element(id)

		if element then
			if self._values.operation == "add" then
				element:counter_operation_add(amount)
			elseif self._values.operation == "subtract" then
				element:counter_operation_subtract(amount)
			elseif self._values.operation == "reset" then
				element:counter_operation_reset(amount)
			elseif self._values.operation == "set" then
				element:counter_operation_set(amount)
			end
		end
	end

	DeadLocke.ElementCounterOperator.super.on_executed(self, instigator)
end


DeadLocke.ElementCounter = DeadLocke.ElementCounter or blt_class(DeadLocke.MissionScriptElement)

local ElementCounter = DeadLocke.ElementCounter



function ElementCounter:init(...)
	DeadLocke.ElementCounter.super.init(self, ...)
	self._digital_gui_units = {}
	self._triggers = {}
end

function ElementCounter:counter_value()
	return self._values.counter_target
end

function ElementCounter:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if self._values.counter_target > 0 then
		self._values.counter_target = self._values.counter_target - 1

		self:_update_digital_guis_number()

		if self._values.counter_target == 0 then
			DeadLocke.ElementCounter.super.on_executed(self, instigator)
		end
	end
end


function ElementCounter:reset_counter_target(counter_target)
	self._values.counter_target = counter_target

	self:_update_digital_guis_number()
end

function ElementCounter:counter_operation_add(amount)
	self._values.counter_target = self._values.counter_target + amount
end


function ElementCounter:counter_operation_subtract(amount)
	self._values.counter_target = self._values.counter_target - amount
end


function ElementCounter:counter_operation_reset(amount)
	self._values.counter_target = self._original_value
end

function ElementCounter:counter_operation_set(amount)
	self._values.counter_target = amount
end

function ElementCounter:_check_triggers(type)
	if not self._triggers or not self._triggers[type] then
		return
	end

	for id, cb_data in pairs(self._triggers[type]) do
		if type ~= "value" or cb_data.amount == self._values.counter_target then
			cb_data.callback()
		end
	end
end

-- This mod is not meant to impact units in any way.
function ElementCounter:_update_digital_guis_number()
end

DeadLocke.ElementCounterFilter = DeadLocke.ElementCounterFilter or blt_class(DeadLocke.MissionScriptElement)

local ElementCounterFilter = DeadLocke.ElementCounterFilter

function ElementCounterFilter:init(...)
	DeadLocke.ElementCounterFilter.super.init(self, ...)
end


function ElementCounterFilter:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if not self:_values_ok() then
		return
	end

	DeadLocke.ElementCounterFilter.super.on_executed(self, instigator)
end


function ElementCounterFilter:_values_ok()
	if self._values.check_type == "counters_equal" then
		return self:_all_counter_values_equal()
	end

	if self._values.check_type == "counters_not_equal" then
		return not self:_all_counter_values_equal()
	end

	if self._values.needed_to_execute == "all" then
		return self:_all_counters_ok()
	end

	if self._values.needed_to_execute == "any" then
		return self:_any_counters_ok()
	end
end

function ElementCounterFilter:_all_counter_values_equal()
	local test_value = nil

	for _, id in ipairs(self._values.elements) do
		local element = self:get_mission_element(id)
		test_value = test_value or element:counter_value()

		if test_value ~= element:counter_value() then
			return false
		end
	end

	return true
end

function ElementCounterFilter:_all_counters_ok()
	for _, id in ipairs(self._values.elements) do
		if not self:_check_type(self:get_mission_element(id)) then
			return false
		end
	end

	return true
end

function ElementCounterFilter:_any_counters_ok()
	for _, id in ipairs(self._values.elements) do
		if self:_check_type(self:get_mission_element(id)) then
			return true
		end
	end

	return false
end

function ElementCounterFilter:_check_type(element)
	if not self._values.check_type or self._values.check_type == "equal" then
		return element:counter_value() == self._values.value
	end

	if self._values.check_type == "less_or_equal" then
		return element:counter_value() <= self._values.value
	end

	if self._values.check_type == "greater_or_equal" then
		return self._values.value <= element:counter_value()
	end

	if self._values.check_type == "less_than" then
		return element:counter_value() < self._values.value
	end

	if self._values.check_type == "greater_than" then
		return self._values.value < element:counter_value()
	end
end