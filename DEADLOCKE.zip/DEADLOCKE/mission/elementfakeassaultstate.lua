local ElementFakeAssaultState = DeadLockeMissionScriptElement:import("ElementFakeAssaultState")
function ElementFakeAssaultState:_init(...)
end

function ElementFakeAssaultState:_can_set_fake_assault_music()
	if self._values.must_be_played then
		return true
	end
	if not DeadLocke._data.music_event_toggle then
		return false
	end
	if not self._values.track_list then
		return true
	end
	for i,v in pairs(self._values.track_list) do
		if v == Global.music_manager.current_track then
			return true
		end
	end
	return false
end


function ElementFakeAssaultState:on_executed(...)
	if not self._values.enabled then
		return
	end

	if not managers.groupai:state():get_assault_mode() then
		managers.groupai:state():set_ambience_flag()
		SoundDevice:set_state("wave_flag", self._values.state and "assault" or "control")
		if self:_can_set_fake_assault_music() then
			managers.music:post_event(DeadLocke:get_overall_music_event(self._values.state and "fake_assault" or "control"))
		end
	end
	ElementFakeAssaultState.super.on_executed(self, ...)
end
