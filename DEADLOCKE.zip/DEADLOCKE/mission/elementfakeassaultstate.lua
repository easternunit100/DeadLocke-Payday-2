local ElementFakeAssaultState = blt_class(DeadLocke.ElementMusic)
DeadLocke.ElementFakeAssaultState = ElementFakeAssaultState

function ElementFakeAssaultState:init(...)
	DeadLocke.ElementFakeAssaultState.super.init(self,...)
end


function ElementFakeAssaultState:on_executed(...)
	if not self._values.enabled then
		return
	end

	if not managers.groupai:state():get_assault_mode() then
		--managers.groupai:state():set_ambience_flag()
		SoundDevice:set_state("wave_flag", self._values.state and "assault" or "control")
		if not self._values.skip_music_event and self:_can_play_music_event() then
			managers.music:post_event(DeadLocke:get_overall_music_event(self._values.state and "fake_assault" or "control"))
		end
	end
	DeadLocke.ElementFakeAssaultState.super.on_executed(self, ...)
end



