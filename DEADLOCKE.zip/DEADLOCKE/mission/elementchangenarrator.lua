local ElementChangeNarrator = blt_class(DeadLocke.MissionScriptElement)

DeadLocke.ElementChangeNarrator = ElementChangeNarrator

function ElementChangeNarrator:init(...)
	DeadLocke.ElementChangeNarrator.super.init(self, ...)
end

function ElementChangeNarrator:client_on_executed(...)
end
function ElementChangeNarrator:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	managers.dialog:set_narrator(self._values.narrator)
	DeadLocke.ElementChangeNarrator.super.on_executed(self, instigator)
end
