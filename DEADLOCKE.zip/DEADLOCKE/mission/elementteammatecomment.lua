DeadLocke.ElementTeammateComment = blt_class(DeadLocke.MissionScriptElement)

local ElementTeammateComment = DeadLocke.ElementTeammateComment

function ElementTeammateComment:init(...)
	DeadLocke.ElementTeammateComment.super.init(self,...)
end

function ElementTeammateComment:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if self._values.comment ~= "none" then
		local radius = self._values.radius ~= 0 and self._values.radius or nil
		local trigger_unit = self._values.use_instigator and instigator or nil

		if trigger_unit and type(trigger_unit) ~= "userdata" then
			trigger_unit = nil
		end
		
		DeadLocke:criminal_comment(trigger_unit, self._values.allow_first_person, self._values.comment, self._values.position, self._values.pos_based, radius, self._values.play_ogg_line, false)
	end
	
	DeadLocke.ElementTeammateComment.super.on_executed(self, instigator)
end
