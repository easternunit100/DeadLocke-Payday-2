local ElementDebugText = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementDebugText = ElementDebugText

function ElementDebugText:init(...)
	DeadLocke.ElementDebugText.super.init(self,...)
end
function ElementDebugText:on_executed(...)
	if not self._values.enabled then
		return
	end
	DeadLocke:debug_log(self._values.debug_string)
	DeadLocke.ElementDebugText.super.on_executed(self, ...)
end