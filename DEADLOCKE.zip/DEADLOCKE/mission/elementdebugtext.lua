local ElementDebugText = DeadLockeMissionScriptElement:import("ElementDebugText")
function ElementDebugText:on_executed(...)
	if not self._values.enabled then
		return
	end
	log(self._values.debug_string)
	ElementDebugText.super.on_executed(self, ...)
end