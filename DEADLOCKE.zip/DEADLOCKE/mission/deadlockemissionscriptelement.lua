DeadLockeMissionScriptElement = {}
DeadLockeMissionScriptElement._delayed_calls = 0
DeadLockeMissionScriptElement._elements = {}
DeadLockeMissionScriptElement._triggers = {}
DeadLockeMissionScriptElement._create_shapes = {}
function DeadLockeMissionScriptElement:load_mission_script(level_id)
	local level_mission_script = level_id and DeadLocke:load_json(DeadLocke._path.."levels/"..level_id..".json")
	if not level_mission_script then
		log("[DeadLockeMissionScriptElement:init] could not load level name "..tostring(level_id).. " no such level!")
		return
	end
	self._mission_script = level_mission_script
	local elements = self._mission_script.default.elements
	for id, data in pairs(elements) do
		if self[data._class] then
			self._elements[id] = DeadLocke:deep_clone(self[data._class], data._class)
			self._elements[id]._values = data._values
			self._elements[id]._id = id
		end
	end
	if not next(self._elements) then
		log("[DeadLockeMissionScriptElement:init] no custom elements in level name "..tostring(level_id).. "!")
		return
	end
	for id, element in pairs(self._elements) do
		if element then
			if element._init then
				element:_init()
			end
		end
	end
	for id, element in pairs(self._elements) do
		if element then
			if element.on_script_activated then
				element:on_script_activated()
			end
		end
	end
	local map_name = tweak_data.levels:get_localized_level_name_from_level_id(level_id) or "Codename ["..level_id.."]"
	log("[DeadLocke:Load_map_dialogue] Map : "..map_name.." custom script loaded")
end
function DeadLockeMissionScriptElement:_print_debug_on_executed(instigator)
end
function DeadLockeMissionScriptElement:add_delayed_id_execute(time, element, ...)
end
function DeadLockeMissionScriptElement:_check_instigator(instigator)
	if type(instigator) == "userdata" then
		return instigator
	end

	return managers.player:player_unit()
end
function DeadLockeMissionScriptElement:on_weapons_hot_executed()
	if not self._mission_script or not self._mission_script.on_weapons_hot or not self._mission_script.on_weapons_hot.elements then
		return
	end
	local elements = self._mission_script.on_weapons_hot.element_ids
	for _, id in ipairs(elements) do
		local element = self:element(id)
		if element then
			element:on_executed()
		end
	end
end
function DeadLockeMissionScriptElement:on_executed(instigator, alternative, skip_execute_on_executed)
	if not self._values.enabled then
		return
	end
	instigator = self:_check_instigator(instigator)
	self._last_orientation_index = nil
	self:_reduce_trigger_times()
	if self._id and DeadLocke.debug then
		log("[MissionScriptElement:on_executed] executed element id "..self._id)
	end
	if not skip_execute_on_executed or type(skip_execute_on_executed) ~= "boolean" then
		self:_trigger_execute_on_executed(instigator, alternative)
	end
end
function DeadLockeMissionScriptElement:_reduce_trigger_times()
	--[[if self._values.trigger_times and self._values.trigger_times > 0 then
		self._values.trigger_times = self._values.trigger_times - 1

		if self._values.trigger_times <= 0 then
			self:set_enabled(false)
		end
	end]]
end
function DeadLockeMissionScriptElement:set_enabled(enable)
	self._values.enabled = enable
	if DeadLocke.debug then
		log("[DeadLockeMissionScriptElement:set_enabled] element id ["..self._id.."] is "..(enable and "enabled" or "disabled"))
	end
end
function DeadLockeMissionScriptElement:enabled()
	return self._values.enabled
end
function DeadLockeMissionScriptElement:value(name)
	--[[if self._values.instance_name and self._values.instance_var_names and self._values.instance_var_names[name] then
		local value = managers.world_instance:get_instance_param(self._values.instance_name, self._values.instance_var_names[name])

		if value then
			return value
		end
	end]]

	return self._values[name]
end

function DeadLockeMissionScriptElement:_override_group_element(element_id, element_type, variable_name, new_value)
	local element = self:get_mission_element(element_id)

	if element and element._mission_script and element._mission_script._element_groups then
		local groups = element._mission_script._element_groups

		if not element_type then
			for group_type, group_table in pairs(groups) do
				self:_override_element_type_group(element, element_id, group_table, variable_name, new_value)
			end
		elseif groups[element_type] then
			self:_override_element_type_group(element, element_id, groups[element_type], variable_name, new_value)
		end
	end
end

function DeadLockeMissionScriptElement:override_value_on_element_type(element_type, variable_name, new_value)
	for _, params in ipairs(self._values.on_executed) do
		self:_override_group_element(params.id, element_type, variable_name, new_value)
	end
end

function DeadLockeMissionScriptElement:override_value_on_element(element_ids, variable_name, new_value)
	if type(element_ids) ~= "table" then
		element_ids = {element_ids}
	end

	for _, params in ipairs(self._values.on_executed) do
		if table.contains(element_ids, params.id) then
			self:_override_group_element(params.id, nil, variable_name, new_value)
		end
	end
end
function DeadLockeMissionScriptElement:_calc_base_delay()
	if not self._values.base_delay_rand then
		return self._values.base_delay
	end

	return self._values.base_delay + math.rand(self._values.base_delay_rand)
end
function DeadLockeMissionScriptElement:_calc_element_delay(params)
	if not params.delay_rand then
		return params.delay
	end

	return params.delay + math.rand(params.delay_rand)
end
function DeadLockeMissionScriptElement:element(id)
	return self._elements[id]
end
function DeadLockeMissionScriptElement:get_mission_element(id)
	return self._elements[id]
end
function DeadLockeMissionScriptElement:_has_on_executed_alternative(alternative)
	for _, params in ipairs(self._values.on_executed) do
		if params.alternative and params.alternative == alternative then
			return true
		end
	end

	return false
end

function DeadLockeMissionScriptElement:values()
	return self._values
end
function DeadLockeMissionScriptElement:_trigger_execute_on_executed(instigator, alternative)
	local base_delay = self:_calc_base_delay()
	if base_delay and base_delay > 0 then
		DeadLockeMissionScriptElement._delayed_calls = DeadLockeMissionScriptElement._delayed_calls + 1
		local str_times = tostring(DeadLockeMissionScriptElement._delayed_calls)
		DelayedCalls:Add(tostring(self._id)..str_times, base_delay, function()
			self:execute_on_executed({
				instigator = instigator, 
				alternative = alternative
			})		
		end)
	else
		self:execute_on_executed({
			instigator = instigator, 
			alternative = alternative
		})
	end
end
function DeadLockeMissionScriptElement:delayed_on_executed(element, delay, instigator)
	DeadLockeMissionScriptElement._delayed_calls = DeadLockeMissionScriptElement._delayed_calls + 1
	local str_times = tostring(DeadLockeMissionScriptElement._delayed_calls)
	DelayedCalls:Add(tostring(element._id)..str_times, delay, function()
		element:on_executed(instigator)
	end)
end
function DeadLockeMissionScriptElement:execute_on_executed(execute_params)
	if not self._values.on_executed then
		if DeadLocke.debug then
			log("no on_executed table on id element "..self._id)
		end
		return
	end
	for _, params in ipairs(self._values.on_executed) do
		if not execute_params.alternative or not params.alternative or execute_params.alternative == params.alternative then
			local element = self:get_mission_element(params.id)
			if element then
				local delay = self:_calc_element_delay(params)
				if delay and delay > 0 then
					self:delayed_on_executed(element, delay, execute_params.instigator)
				else
					element:on_executed(execute_params.instigator)
				end
			end
		end
	end
end
function DeadLockeMissionScriptElement:get_module(value)
	return self[class]
end

function DeadLockeMissionScriptElement:import(class)
	for var, value in pairs(self) do
		self[class] = self[class] or {}
		self[class][var] = self[class][var] or value
		if value and type(value) == "function" then
			self.super = self.super or {}
			self.super[var] = self.super[var] or value
		end
	end
	return self[class]
end
DeadLockeMissionScriptElement:import("DeadLockeMissionScriptElement")

