local ElementPlayOggComment = DeadLockeMissionScriptElement:import("ElementPlayOggComment")
function ElementPlayOggComment:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	ElementPlayOggComment.super.on_executed(self, instigator)
end
