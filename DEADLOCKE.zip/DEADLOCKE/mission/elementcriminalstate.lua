local ElementCriminalState = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementCriminalState = ElementCriminalState

function ElementCriminalState:init(...)
	ElementCriminalState.super.init(self, ...)
end

function ElementCriminalState:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if instigator and type(instigator) == "table" then
		local gstate = managers.groupai:state()
		if alive(instigator) and gstate:all_char_criminals()[instigator:key()] then
			if managers.player:player_unit() == instigator then				
				if self._values.command == "isolate" then
					for u_key, u_data in pairs(gstate:all_char_criminals()) do
						if u_data and u_data.unit and alive(u_data.unit) then
							u_data.unit:base():ignore(true)
						end
					end
				elseif self._values.command == "join_back_gang" then
					for u_key, u_data in pairs(gstate:all_char_criminals()) do
						if u_data and u_data.unit and alive(u_data.unit) then
							u_data.unit:base():ignore(false)
						end
					end
				end
			elseif self._values.command == "isolate" then
				managers.groupai:state():isolate_from_criminals(instigator)
			elseif self._values.command == "join_back_gang" then
				managers.groupai:state():rejoin_criminals(instigator)		
			end
		end
	end

	DeadLocke.ElementCriminalState.super.on_executed(self, instigator)
end

function ElementCriminalState:client_on_executed(...)
	self:on_executed(...)
end