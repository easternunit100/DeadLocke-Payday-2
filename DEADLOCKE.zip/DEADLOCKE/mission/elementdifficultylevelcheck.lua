DeadLocke.ElementDifficultyLevelCheck = DeadLocke.ElementDifficultyLevelCheck or blt_class(DeadLocke.MissionScriptElement)

local ElementDifficultyLevelCheck = DeadLocke.ElementDifficultyLevelCheck

function ElementDifficultyLevelCheck:init(...)
	ElementDifficultyLevelCheck.super.init(self, ...)
end

function ElementDifficultyLevelCheck:client_on_executed(...)
	self:on_executed(...)
end

function ElementDifficultyLevelCheck:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	local current_diff = Global.game_settings and Global.game_settings.difficulty
	
	for index, diff in pairs(tweak_data.difficulties) do
	
		if self._values.difficulty == diff then
			break
		end
		
		if current_diff == diff then
			return
		end
		
	end

	ElementDifficultyLevelCheck.super.on_executed(self, instigator)
end
