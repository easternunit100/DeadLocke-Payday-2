local ElementMusic = DeadLockeMissionScriptElement:import("ElementMusic")
function ElementMusic:_can_play_music_event()
	if self._values.must_be_played then
		return true
	end
	if not DeadLocke._data.music_event_toggle then
		return false
	end
	if not self._values.track_list then
		return true
	end
	for i,v in pairs(self._values.track_list) do
		if v == Global.music_manager.current_track then
			return true
		end
	end
	return false
end

function ElementMusic:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if not self._values.use_instigator or instigator == managers.player:player_unit() then
		if self._values.stage then
			local music_event = DeadLocke:get_overall_music_event(self._values.stage)
			if self:_can_play_music_event() and music_event then
				managers.music:post_event(music_event)			
			end
		elseif self._editor_name then
			log("Cant play music event nil [" .. self._editor_name .. "]")
		end
	end
	
	ElementMusic.super.on_executed(self, instigator)
end