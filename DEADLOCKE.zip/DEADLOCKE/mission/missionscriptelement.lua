DeadLocke.MissionScriptElement = DeadLocke.MissionScriptElement or blt_class()

local MissionScriptElement = DeadLocke.MissionScriptElement
function MissionScriptElement:init(mission_script, data)
	self._mission_script = mission_script
	self._id = data.id
	self._editor_name = data._editor_name
	self._values = data._values
end
function MissionScriptElement:on_script_activated()
	if self._values.rules_elements then
		self._rules_elements = {}

		for _, id in ipairs(self._values.rules_elements) do
			local element = self:get_mission_element(id)

			table.insert(self._rules_elements, element)
		end
	end
end
function MissionScriptElement:on_created()
end
function MissionScriptElement:_print_debug_on_executed(instigator)
end
function MissionScriptElement:add_delayed_id_execute(time, element, ...)
	element:on_executed(...)
end
function MissionScriptElement:_check_instigator(instigator)
	if CoreClass.type_name(instigator) == "Unit" then
		return instigator
	end

	return managers.player:player_unit()
end
function MissionScriptElement:on_executed(instigator, alternative, skip_execute_on_executed)
	if not self._values.enabled then
		return
	end
	instigator = self:_check_instigator(instigator)
	self._last_orientation_index = nil
	self:_print_debug_on_executed(instigator)
	self:_reduce_trigger_times()
	if not skip_execute_on_executed or type(skip_execute_on_executed) ~= "boolean" then
		self:_trigger_execute_on_executed(instigator, alternative)
	end
end
function MissionScriptElement:_reduce_trigger_times()
	if self._values.trigger_times and self._values.trigger_times > 0 then
		self._values.trigger_times = self._values.trigger_times - 1

		if self._values.trigger_times <= 0 then
			self:set_enabled(false)
		end
	end
end

function MissionScriptElement:set_enabled(enabled)
	self._values.enabled = enabled

	self:on_set_enabled()
end

function MissionScriptElement:on_set_enabled()
end

function MissionScriptElement:enabled()
	return self._values.enabled
end
function MissionScriptElement:value(name)
	if self._values.instance_name and self._values.instance_var_names and self._values.instance_var_names[name] then
		local value = managers.world_instance:get_instance_param(self._values.instance_name, self._values.instance_var_names[name])

		if value then
			return value
		end
	end

	return self._values[name]
end

function MissionScriptElement:_override_group_element(element_id, element_type, variable_name, new_value)
	local element = self:get_mission_element(element_id)

	if element and element._mission_script and element._mission_script._element_groups then
		local groups = element._mission_script._element_groups

		if not element_type then
			for group_type, group_table in pairs(groups) do
				self:_override_element_type_group(element, element_id, group_table, variable_name, new_value)
			end
		elseif groups[element_type] then
			self:_override_element_type_group(element, element_id, groups[element_type], variable_name, new_value)
		end
	end
end

function MissionScriptElement:override_value_on_element_type(element_type, variable_name, new_value)
	for _, params in ipairs(self._values.on_executed) do
		self:_override_group_element(params.id, element_type, variable_name, new_value)
	end
end

function MissionScriptElement:override_value_on_element(element_ids, variable_name, new_value)
	if type(element_ids) ~= "table" then
		element_ids = {element_ids}
	end

	for _, params in ipairs(self._values.on_executed) do
		if table.contains(element_ids, params.id) then
			self:_override_group_element(params.id, nil, variable_name, new_value)
		end
	end
end
function MissionScriptElement:_calc_base_delay()
	local base_delay = self._values.base_delay or 0
	if not self._values.base_delay_rand then
		return base_delay
	end

	return base_delay + math.rand(self._values.base_delay_rand)
end
function MissionScriptElement:_calc_element_delay(params)
	if not params.delay_rand then
		return params.delay
	end

	return params.delay + math.rand(params.delay_rand)
end
function MissionScriptElement:get_mission_element(id)
	return self._mission_script:element(id)
end
function MissionScriptElement:_has_on_executed_alternative(alternative)
	for _, params in ipairs(self._values.on_executed) do
		if params.alternative and params.alternative == alternative then
			return true
		end
	end

	return false
end

function MissionScriptElement:values()
	return self._values
end

function MissionScriptElement:_execute_on_executed(params)
	self:execute_on_executed(params)
end

function MissionScriptElement:_trigger_execute_on_executed(instigator, alternative)
	local base_delay = self:_calc_base_delay()

	if base_delay > 0 then
		local clbk = callback(self, self, "_execute_on_executed", {instigator = instigator,	alternative = alternative})
		self._mission_script:add(clbk, base_delay, 1)
	else
		self:execute_on_executed({
			instigator = instigator,
			alternative = alternative
		})
	end
end

function MissionScriptElement:delayed_on_executed(element, delay, instigator)
	self._mission_script:add(callback(element, element, "on_executed", instigator), delay, 1)
end

function MissionScriptElement:execute_on_executed(execute_params)
	for _, params in ipairs(self._values.on_executed) do
		if not execute_params.alternative or not params.alternative or execute_params.alternative == params.alternative then
			local element = self:get_mission_element(params.id)
			if element then
				local delay = self:_calc_element_delay(params)
				if delay and delay > 0 then
					self._mission_script:add(callback(element, element, "on_executed", execute_params.instigator), delay, 1)
				else
					element:on_executed(execute_params.instigator)
				end
			end
		end
	end
end