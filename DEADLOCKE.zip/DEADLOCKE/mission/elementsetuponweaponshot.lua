local ElementSetupOnWeaponsHot = DeadLockeMissionScriptElement:import("ElementSetupOnWeaponsHot")

function ElementSetupOnWeaponsHot:_can_set_music_event()
	if self._values.must_be_played then
		return true
	end
	if not DeadLocke._data.music_event_toggle then
		return false
	end
	if not self._values.track_list then
		return true
	end
	for i,v in pairs(self._values.track_list) do
		if v == Global.music_manager.current_track then
			return true
		end
	end
	return false
end

function ElementSetupOnWeaponsHot:on_executed(...)
	if not self._values.enabled then
		return
	end
	if self._values.music_stage and self:_can_set_music_event() then
		DeadLocke:on_weapons_hot_music_stage(self._values.music_stage)
	end
	if self._values.sound_device_enable then
		DeadLocke:on_weapons_hot_sound_device(self._values.sound_device_enable)
	end
	ElementSetupOnWeaponsHot.super.on_executed(self, ...)
end
