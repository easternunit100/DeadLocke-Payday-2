DeadLocke.ElementSetupOnWeaponsHot = DeadLocke.ElementSetupOnWeaponsHot or blt_class(DeadLocke.ElementMusic)
local ElementSetupOnWeaponsHot = DeadLocke.ElementSetupOnWeaponsHot

function ElementSetupOnWeaponsHot:init(...)
	DeadLocke.ElementSetupOnWeaponsHot.super.init(self, ...)
end

function ElementSetupOnWeaponsHot:on_executed(...)
	if not self._values.enabled then
		return
	end
	
	
	if self._values.music_stage and self:_can_play_music_event() then
		DeadLocke:on_weapons_hot_music_stage(self._values.music_stage)
	end
	
	if self._values.sound_device_enable then
		DeadLocke:on_weapons_hot_sound_device(self._values.sound_device_enable)
	end
	
	DeadLocke.ElementSetupOnWeaponsHot.super.on_executed(self, ...)
end
