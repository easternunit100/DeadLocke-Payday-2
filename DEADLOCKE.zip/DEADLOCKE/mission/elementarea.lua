local ElementAreaTrigger = DeadLockeMissionScriptElement:import("ElementAreaTrigger")
local tmp_vec1 = Vector3()
function ElementAreaTrigger:_init(...)
	self._last_project_amount_all = 0
	self._shapes = {}
	self._shape_elements = {}
	self._rules_elements = {}
	self._inside = {}
	table.insert(DeadLockeMissionScriptElement._triggers, self)
end

function ElementAreaTrigger:project_instigators()
	local instigators = {}

	--[[if Network:is_client() then
		if self._values.instigator == "player" or self._values.instigator == "local_criminals" or self._values.instigator == "persons" then
			table.insert(instigators, managers.player:player_unit())
		elseif self._values.instigator == "player1" or self._values.instigator == "player2" or self._values.instigator == "player3" or self._values.instigator == "player4" then
			local id = tonumber(string.match(self._values.instigator, "%d$"))

			if managers.network:session() and managers.network:session():local_peer():id() == id then
				table.insert(instigators, managers.player:player_unit())
			end
		elseif self._values.instigator == "vr_player" and _G.IS_VR then
			table.insert(instigators, managers.player:player_unit())
		end

		return instigators
	end]]

	if self._values.instigator == "player" then
		table.insert(instigators, managers.player:player_unit())
	elseif self._values.instigator == "players" then
		for _, data in pairs(managers.groupai:state():all_player_criminals()) do
			table.insert(instigators, data.unit)
		end 
	elseif self._values.instigator == "player_not_in_vehicle" then
		table.insert(instigators, managers.player:player_unit())
	elseif self._values.instigator == "vr_player" and _G.IS_VR then
		table.insert(instigators, managers.player:player_unit())
	elseif self._values.instigator == "vehicle" then
		local vehicles = managers.vehicle:get_all_vehicles()

		for _, v in pairs(vehicles) do
			if not v:npc_vehicle_driving() then
				table.insert(instigators, v)
			end
		end
	elseif self._values.instigator == "npc_vehicle" then
		local vehicles = managers.vehicle:get_all_vehicles()

		for _, v in pairs(vehicles) do
			if v:npc_vehicle_driving() then
				table.insert(instigators, v)
			end
		end
	elseif self._values.instigator == "vehicle_with_players" then
		local vehicles = managers.vehicle:get_all_vehicles()

		for _, v in pairs(vehicles) do
			table.insert(instigators, v)
		end
	elseif self._values.instigator == "enemies" then
		local state = managers.groupai:state()

		if state:police_hostage_count() <= 0 and state:get_amount_enemies_converted_to_criminals() <= 0 then
			for _, data in pairs(managers.enemy:all_enemies()) do
				table.insert(instigators, data.unit)
			end
		else
			for _, data in pairs(managers.enemy:all_enemies()) do
				if not data.unit:anim_data().surrender and not data.is_converted then
					table.insert(instigators, data.unit)
				end
			end
		end
	elseif self._values.instigator == "civilians" then
		for _, data in pairs(managers.enemy:all_civilians()) do
			table.insert(instigators, data.unit)
		end
	elseif self._values.instigator == "escorts" then
		for _, data in pairs(managers.enemy:all_civilians()) do
			if tweak_data.character[data.unit:base()._tweak_table].is_escort then
				table.insert(instigators, data.unit)
			end
		end
	elseif self._values.instigator == "hostages" then
		if managers.groupai:state():police_hostage_count() > 0 then
			for _, data in pairs(managers.enemy:all_enemies()) do
				if data.unit:anim_data().surrender then
					table.insert(instigators, data.unit)
				end
			end
		end

		for _, data in pairs(managers.enemy:all_civilians()) do
			if data.unit:anim_data().tied then
				table.insert(instigators, data.unit)
			end
		end
	elseif self._values.instigator == "intimidated_enemies" then
		local state = managers.groupai:state()

		if state:police_hostage_count() > 0 or state:get_amount_enemies_converted_to_criminals() > 0 then
			for _, data in pairs(managers.enemy:all_enemies()) do
				if data.unit:anim_data().surrender or data.is_converted then
					table.insert(instigators, data.unit)
				end
			end
		end
	elseif self._values.instigator == "criminals" then
		for _, data in pairs(managers.groupai:state():all_char_criminals()) do
			table.insert(instigators, data.unit)
		end
	elseif self._values.instigator == "local_criminals" then
		table.insert(instigators, managers.player:player_unit())

		for _, data in pairs(managers.groupai:state():all_AI_criminals()) do
			table.insert(instigators, data.unit)
		end
	elseif self._values.instigator == "persons" then
		table.insert(instigators, managers.player:player_unit())

		for _, data in pairs(managers.groupai:state():all_char_criminals()) do
			table.insert(instigators, data.unit)
		end

		for _, data in pairs(managers.enemy:all_civilians()) do
			table.insert(instigators, data.unit)
		end

		for _, data in pairs(managers.enemy:all_enemies()) do
			table.insert(instigators, data.unit)
		end
	elseif self._values.instigator == "ai_teammates" then
		for _, data in pairs(managers.groupai:state():all_AI_criminals()) do
			table.insert(instigators, data.unit)
		end
	elseif self._values.instigator == "loot" or self._values.instigator == "unique_loot" then
		local all_found = World:find_units_quick("all", 14)
		local filter_func = nil
		filter_func = self._values.instigator == "loot" and function (carry_data)
			local carry_id = carry_data:carry_id()
			local carry_list = {
				"gold",
				"money",
				"coke",
				"coke_pure",
				"sandwich",
				"weapon",
				"painting",
				"circuit",
				"diamonds",
				"meth",
				"lance_bag",
				"lance_bag_large",
				"grenades",
				"engine_01",
				"engine_02",
				"engine_03",
				"engine_04",
				"engine_05",
				"engine_06",
				"engine_07",
				"engine_08",
				"engine_09",
				"engine_10",
				"engine_11",
				"engine_12",
				"ammo",
				"cage_bag",
				"turret",
				"artifact_statue",
				"samurai_suit",
				"equipment_bag",
				"cro_loot1",
				"cro_loot2",
				"ladder_bag",
				"hope_diamond",
				"mus_artifact",
				"mus_artifact_paint",
				"winch_part",
				"winch_part_e3",
				"fireworks",
				"evidence_bag",
				"watertank_empty",
				"watertank_full",
				"warhead",
				"paper_roll",
				"counterfeit_money",
				"unknown",
				"safe_wpn",
				"safe_ovk",
				"nail_muriatic_acid",
				"nail_caustic_soda",
				"nail_hydrogen_chloride",
				"nail_euphadrine_pills",
				"safe_secure_dummy",
				"din_pig",
				"meth_half",
				"parachute",
				"equipment_bag_global_event",
				"prototype",
				"master_server",
				"lost_artifact",
				"breaching_charges",
				"masterpiece_painting",
				"drk_bomb_part",
				"goat",
				"present",
				"mad_master_server_value_1",
				"mad_master_server_value_2",
				"mad_master_server_value_3",
				"mad_master_server_value_4",
				"drk_bomb_part",
				"weapon_glock",
				"weapon_scar",
				"bike_part_light",
				"bike_part_heavy",
				"toothbrush",
				"drone_control_helmet",
				"chl_puck",
				"cloaker_gold",
				"cloaker_money",
				"cloaker_cocaine",
				"robot_toy",
				"ordinary_wine",
				"expensive_vine",
				"women_shoes",
				"vr_headset",
				"diamond_necklace",
				"yayo",
				"rubies",
				"red_diamond",
				"diamonds_dah",
				"old_wine",
				"winch_part_2",
				"winch_part_3",
				"box_unknown_tag",
				"battery",
				"box_unknown"
			}

			if table.contains(carry_list, carry_id) then
				return true
			end
		end or function (carry_data)
			local carry_id = carry_data:carry_id()

			if tweak_data.carry[carry_id].is_unique_loot then
				return true
			end
		end

		for _, unit in ipairs(all_found) do
			local carry_data = unit:carry_data()

			if carry_data and filter_func(carry_data) then
				table.insert(instigators, unit)
			end
		end
	elseif self._values.instigator == "equipment" then
		if self._values.instigator_name ~= nil then
			local all_found = World:find_units_quick("all", 14)

			
			-- Lines: 232 to 236
			local function filter_func(unit)
				if unit:base() and unit:base().get_name_id and unit:base():get_name_id() == self._values.instigator_name then
					return true
				end
			end

			for _, unit in ipairs(all_found) do
				if filter_func(unit) then
					table.insert(instigators, unit)
				end
			end
		end
	elseif self._values.instigator == "player1" or self._values.instigator == "player2" or self._values.instigator == "player3" or self._values.instigator == "player4" and not Global.game_host then
		local id = tonumber(string.match(self._values.instigator, "%d$"))

		if managers.network:session() and managers.network:session():local_peer():id() == id then
			table.insert(instigators, managers.player:player_unit())
		end
	end

	return instigators
end

-- Lines: 255 to 269
function ElementAreaTrigger:project_amount_all()
	if self._values.instigator == "criminals" or self._values.instigator == "local_criminals" then
		local i = 0

		for _, data in pairs(managers.groupai:state():all_char_criminals()) do
			i = i + 1
		end

		return i
	elseif self._values.instigator == "ai_teammates" then
		local i = 0

		for _, data in pairs(managers.groupai:state():all_AI_criminals()) do
			i = i + 1
		end

		return i
	end

	return managers.network:session() and managers.network:session():amount_of_alive_players() or 0
end

-- Lines: 272 to 294
function ElementAreaTrigger:project_amount_inside()
	local counter = #self._inside

	if self._values.instigator == "vehicle_with_players" then
		for _, instigator in pairs(self._inside) do
			local vehicle = instigator:vehicle_driving()

			if vehicle then
				counter = vehicle:num_players_inside()
			end
		end
	elseif self._values.instigator == "player_not_in_vehicle" then
		counter = 0
		local vehicles = managers.vehicle:get_all_vehicles()

		for _, instigator in pairs(self._inside) do
			local in_vehicle = false

			for _, vehicle in pairs(vehicles) do
				in_vehicle = in_vehicle or vehicle:vehicle_driving():find_seat_for_player(instigator)
			end

			if not in_vehicle then
				counter = counter + 1
			end
		end
	end

	return counter
end

-- Lines: 297 to 317
function ElementAreaTrigger:is_instigator_valid(unit)
	if self._values.instigator == "vehicle_with_players" and unit then
		local result = false
		local amount = self._values.amount == "all" and self:project_amount_all()
		amount = amount or tonumber(self._values.amount)
		local inside_vehicle = unit:vehicle_driving():num_players_inside()

		if unit:vehicle_driving() and inside_vehicle > 0 and amount <= inside_vehicle then
			result = true
		end

		return result
	elseif self._values.instigator == "player_not_in_vehicle" then
		local vehicles = managers.vehicle:get_all_vehicles()

		for _, instigator in pairs(self._inside) do
			for _, vehicle in pairs(vehicles) do
				if vehicle:vehicle_driving():find_seat_for_player(instigator) then
					return false
				end
			end
		end
	end

	return true
end

-- Lines: 32 to 50
function ElementAreaTrigger:on_script_activated()
	self._on_script_activated_done = true

	if self._values.use_shape_element_ids then
		for _, id in ipairs(self._values.use_shape_element_ids) do
			local element = self:get_mission_element(id)

			table.insert(self._shape_elements, element)
		end
	end

	if self._values.rules_element_ids then
		for _, id in ipairs(self._values.rules_element_ids) do
			local element = self:get_mission_element(id)

			table.insert(self._rules_elements, element)
		end
	end

	if self._values.enabled then
		--self:add_callback()
	end
end

-- Lines: 52 to 54
function ElementAreaTrigger:_add_shape(shape)
end

-- Lines: 56 to 57
function ElementAreaTrigger:get_shapes()
	return self._shapes
end

-- Lines: 60 to 66
function ElementAreaTrigger:_preget_shapes()
	local shapes = {}
	if not self._values.use_shape_element_ids then
		if CoreShapeManager then
			if self._values.shape_type == "box" then
				if CoreShapeManager.ShapeBoxMiddle and CoreShapeManager.ShapeBoxMiddle.new then
					table.insert(shapes, CoreShapeManager.ShapeBoxMiddle:new({
						position = DeadLocke:String_to_Vector(self._values.position),
						rotation = DeadLocke:String_to_Rotation(self._values.rotation),
						width = self._values.width,
						depth = self._values.depth,
						height = self._values.height
					}))
				end
			elseif self._values.shape_type == "cylinder" then
				if CoreShapeManager.ShapeCylinderMiddle and CoreShapeManager.ShapeCylinderMiddle.new then
					table.insert(shapes, CoreShapeManager.ShapeCylinderMiddle:new({
						position = DeadLocke:String_to_Vector(self._values.position),
						rotation = DeadLocke:String_to_Rotation(self._values.rotation),
						height = self._values.height,
						radius = self._values.radius
					}))
				end
			end
		end
	end
	return shapes
end
function ElementAreaTrigger:is_inside(pos)
	local shapes = self:_preget_shapes()
	if shapes and next(shapes) then
		for _, shape in ipairs(shapes) do
			if shape and shape:is_inside(pos) then
				return true
			end
		end
	end

	return false
end

-- Lines: 69 to 79
function ElementAreaTrigger:_is_inside(pos)
	if self:is_inside(pos) then
		return true
	end

	for _, element in ipairs(self._shape_elements) do
		local use = self._values.use_disabled_shapes or element:enabled()

		if use and element:is_inside(pos) then
			return true
		end
	end

	return false
end

-- Lines: 82 to 101
function ElementAreaTrigger:set_enabled(enabled)
	if not enabled and Network:is_server() and self._values.trigger_on == "both" then
		for _, unit in ipairs(CoreTable.clone(self._inside)) do
			self:sync_exit_area(unit)
		end
	end

	ElementAreaTrigger.super.set_enabled(self, enabled)

	if not enabled then
		self._inside = {}
	end
end

-- Lines: 103 to 107
function ElementAreaTrigger:add_callback()
	--[[if not self._callback then
		self._callback = self._mission_script:add(callback(self, self, "update_area"), self._values.interval)
	end]]
	--self:update_area()
end

-- Lines: 109 to 114
function ElementAreaTrigger:remove_callback()
	--[[if self._callback then
		self._mission_script:remove(self._callback)

		self._callback = nil
	end]]
end

-- Lines: 116 to 129
function ElementAreaTrigger:on_executed(instigator, ...)
	if not self._values.enabled then
		return
	end

	ElementAreaTrigger.super.on_executed(self, instigator, ...)

	if not self._values.enabled then
		self:remove_callback()
	end
end

-- Lines: 135 to 158
function ElementAreaTrigger:instigators()
	if self._values.unit_ids then
		local instigators = {}

		--[[if Network:is_server() then
			for _, id in ipairs(self._values.unit_ids) do
				local unit = Application:editor() and managers.editor:layer("Statics"):created_units_pairs()[id] or managers.worlddefinition:get_unit(id)

				if alive(unit) then
					table.insert(instigators, unit)
				end
			end
		end]]

		return instigators
	end

	local instigators = self:project_instigators()
	for _, id in ipairs(self._values.spawn_unit_elements) do
		local element = self:get_mission_element(id)

		if element then
			for _, unit in ipairs(element:units()) do
				table.insert(instigators, unit)
			end
		end
	end

	return instigators
end


-- Lines: 167 to 168
function ElementAreaTrigger:project_amount_all()
	return nil
end

-- Lines: 172 to 173
function ElementAreaTrigger:project_amount_inside()
	return #self._inside
end

-- Lines: 177 to 178
function ElementAreaTrigger:is_instigator_valid(unit)
	return true
end

-- Lines: 182 to 193
function ElementAreaTrigger:debug_draw()
	if true then
		return
	end
	if self._values.instigator == "loot" or self._values.instigator == "unique_loot" then
		if self._shapes then
			for _, shape in ipairs(self._shapes) do
				shape:draw(0, 0, self._values.enabled and 0 or 1, self._values.enabled and 1 or 0, 0, 0.2)
			end
		end
		if self._shape_elements then
			for _, shape_element in ipairs(self._shape_elements) do
				for _, shape in ipairs(shape_element:get_shapes()) do
					shape:draw(0, 0, self._values.enabled and 0 or 1, self._values.enabled and 1 or 0, 0, 0.2)
				end
			end
		end
	end
end

-- Lines: 205 to 241
function ElementAreaTrigger:update_area()
	if not self._values.enabled then
		return
	end

	if self._values.trigger_on == "on_empty" then
		--if Network:is_server() then
			self._inside = {}

			for _, unit in ipairs(self:instigators()) do
				if alive(unit) then
					self:_should_trigger(unit)
				end
			end

			if #self._inside == 0 then
				self:on_executed()
			end
		--end
	else
		local instigators = self:instigators()

		if #instigators == 0 --[[and Network:is_server()]] then
			if self:_should_trigger(nil) then
				self:_check_amount(nil)
			end
		else
			for _, unit in ipairs(instigators) do
				if alive(unit) then
					--[[if Network:is_client() then
						self:_client_check_state(unit)
					elseif self:_should_trigger(unit) then
						self:_check_amount(unit)
					end]]
					if self:_should_trigger(unit) then
						self:_check_amount(unit)
					end
				end
			end
		end
	end
end

-- Lines: 243 to 248
function ElementAreaTrigger:sync_enter_area(unit)
	table.insert(self._inside, unit)

	if self._values.trigger_on == "on_enter" or self._values.trigger_on == "both" or self._values.trigger_on == "while_inside" then
		self:_check_amount(unit)
	end
end

-- Lines: 250 to 255
function ElementAreaTrigger:sync_exit_area(unit)
	table.delete(self._inside, unit)

	if self._values.trigger_on == "on_exit" or self._values.trigger_on == "both" then
		self:_check_amount(unit)
	end
end

-- Lines: 257 to 259
function ElementAreaTrigger:sync_while_in_area(unit)
	self:_check_amount(unit)
end

-- Lines: 261 to 278
function ElementAreaTrigger:_check_amount(unit)
	if self._values.trigger_on == "on_enter" then
		local amount = self._values.amount == "all" and ElementAreaTrigger.project_amount_all(self)
		amount = amount or tonumber(self._values.amount)

		self:_clean_destroyed_units()

		local inside = self:project_amount_inside()

		if inside > 0 and (amount and amount <= inside or not amount) then
			self:on_executed(unit)
		end
	elseif self:is_instigator_valid(unit) then
		self:on_executed(unit)
	end
end

-- Lines: 282 to 333
function ElementAreaTrigger:_should_trigger(unit)
	if alive(unit) then
		local rule_ok = self:_check_instigator_rules(unit)
		local inside = nil

		if unit:movement() then
			inside = self:_is_inside(unit:movement():m_pos())
		else
			unit:m_position(tmp_vec1)

			inside = self:_is_inside(tmp_vec1)
		end

		if table.contains(self._inside, unit) then
			if not inside or not rule_ok then
				table.delete(self._inside, unit)

				if self._values.trigger_on == "on_exit" or self._values.trigger_on == "both" then
					return true
				end
			end
		elseif inside and rule_ok then
			table.insert(self._inside, unit)

			if self._values.trigger_on == "on_enter" or self._values.trigger_on == "both" then
				return true
			end
		end

		if self._values.trigger_on == "while_inside" and inside and rule_ok then
			return true
		end
	end

	if self._values.amount == "all" then
		local project_amount_all = ElementAreaTrigger.project_amount_all(self)

		if project_amount_all ~= self._last_project_amount_all then
			self._last_project_amount_all = project_amount_all

			self:_clean_destroyed_units()

			return true
		end
	end

	return false
end

-- Lines: 337 to 344
function ElementAreaTrigger:_check_instigator_rules(unit)
	for _, element in ipairs(self._rules_elements) do
		if not element:check_rules(self._values.instigator, unit) then
			return false
		end
	end

	return true
end

-- Lines: 348 to 357
function ElementAreaTrigger:_clean_destroyed_units()
	local i = 1

	while next(self._inside) and i <= #self._inside do
		if alive(self._inside[i]) then
			i = i + 1
		else
			table.remove(self._inside, i)
		end
	end
end

-- Lines: 361 to 386
function ElementAreaTrigger:_client_check_state(unit)
	local rule_ok = self:_check_instigator_rules(unit)
	local inside = self:_is_inside(unit:position())

	if table.contains(self._inside, unit) then
		if not inside or not rule_ok then
			table.delete(self._inside, unit)
			--managers.network:session():send_to_host("to_server_area_event", 2, self._id, unit)
		elseif self._values.trigger_on == "while_inside" then
			--managers.network:session():send_to_host("to_server_area_event", 3, self._id, unit)
		end
	elseif inside and rule_ok then
		table.insert(self._inside, unit)
		--managers.network:session():send_to_host("to_server_area_event", 1, self._id, unit)
	end
end

-- Lines: 389 to 395
function ElementAreaTrigger:operation_set_interval(interval)
	self._values.interval = interval

	self:remove_callback()

	if self._values.enabled then
		self:add_callback()
	end
end

-- Lines: 397 to 399
function ElementAreaTrigger:operation_set_use_disabled_shapes(use_disabled_shapes)
	self._values.use_disabled_shapes = use_disabled_shapes
end

-- Lines: 401 to 403
function ElementAreaTrigger:operation_clear_inside()
	self._inside = {}
end

-- Lines: 406 to 410
function ElementAreaTrigger:save(data)
	data.enabled = self._values.enabled
	data.interval = self._values.interval
	data.use_disabled_shapes = self._values.use_disabled_shapes
end

-- Lines: 412 to 419
function ElementAreaTrigger:load(data)
	if not self._on_script_activated_done then
		self:on_script_activated()
	end

	self:set_enabled(data.enabled)
	self:operation_set_interval(data.interval)

	self._values.use_disabled_shapes = data.use_disabled_shapes
end
local ElementAreaOperator = DeadLockeMissionScriptElement:import("ElementAreaOperator")

-- Lines: 425 to 427
function ElementAreaOperator:_init(...)
end

-- Lines: 429 to 431
function ElementAreaOperator:client_on_executed(...)
	self:on_executed(...)
end

-- Lines: 433 to 455
function ElementAreaOperator:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	for _, id in ipairs(self._values.elements) do
		local element = self:get_mission_element(id)

		if element then
			if self._values.apply_on_interval then
				element:operation_set_interval(self._values.interval)
			end

			if self._values.apply_on_use_disabled_shapes then
				element:operation_set_use_disabled_shapes(self._values.use_disabled_shapes)
			end

			if self._values.operation == "clear_inside" then
				element:operation_clear_inside()
			end
		end
	end

	ElementAreaOperator.super.on_executed(self, instigator)
end

ElementAreaReportTrigger = ElementAreaTrigger
-- Lines: 463 to 482
function ElementAreaReportTrigger:update_area()
	if not self._values.enabled then
		return
	end

	local instigators = self:instigators()

	if #instigators == 0 --[[and Network:is_server()]] then
		self:_check_state(nil)
	else
		for _, unit in ipairs(instigators) do
			if alive(unit) then
				--[[if Network:is_client() then
					self:_client_check_state(unit)
				elseif Network:is_server() then
					self:_check_state(unit)
				end]]
				self:_check_state(unit)
			end
		end
	end
end

-- Lines: 484 to 526
function ElementAreaReportTrigger:_check_state(unit)
	self:_clean_destroyed_units()

	if alive(unit) then
		local rule_ok = self:_check_instigator_rules(unit)
		local inside = nil

		if unit:movement() then
			inside = self:_is_inside(unit:movement():m_pos())
		else
			unit:m_position(tmp_vec1)

			inside = self:_is_inside(tmp_vec1)
		end

		if inside and not rule_ok then
			self:_rule_failed(unit)
		end

		if table.contains(self._inside, unit) then
			if not inside or not rule_ok then
				self:_remove_inside(unit)
			elseif inside and rule_ok then
				self:_while_inside(unit)
			end
		elseif inside and rule_ok then
			self:_add_inside(unit)
		end
	end

	local project_amount_all = ElementAreaTrigger.project_amount_all(self)

	if project_amount_all ~= self._last_project_amount_all then
		self._last_project_amount_all = project_amount_all

		self:_clean_destroyed_units()

		return true
	end

	return false
end

-- Lines: 529 to 538
function ElementAreaReportTrigger:_add_inside(unit)
	table.insert(self._inside, unit)

	if self:_has_on_executed_alternative("while_inside") then
		self:on_executed(unit, "while_inside")
	else
		self:on_executed(unit, "enter")
	end

	self:_check_on_executed_reached_amount(unit)
end

-- Lines: 540 to 549
function ElementAreaReportTrigger:_check_on_executed_reached_amount(unit)
	local amount = self._values.amount == "all" and ElementAreaTrigger.project_amount_all(self)
	amount = amount or tonumber(self._values.amount)

	if amount == #self._inside and self:_has_on_executed_alternative("reached_amount") then
		self:on_executed(unit, "reached_amount")
	end
end

-- Lines: 551 to 555
function ElementAreaReportTrigger:_while_inside(unit)
	if self:_has_on_executed_alternative("while_inside") then
		self:on_executed(unit, "while_inside")
	end
end

-- Lines: 557 to 561
function ElementAreaReportTrigger:_rule_failed(unit)
	if self:_has_on_executed_alternative("rule_failed") then
		self:on_executed(unit, "rule_failed")
	end
end

-- Lines: 563 to 570
function ElementAreaReportTrigger:_remove_inside(unit)
	table.delete(self._inside, unit)
	self:on_executed(unit, "leave")

	if #self._inside == 0 then
		self:on_executed(unit, "empty")
	end

	self:_check_on_executed_reached_amount(unit)
end

-- Lines: 572 to 579
function ElementAreaReportTrigger:_remove_inside_by_index(index)
	table.remove(self._inside, index)
	self:on_executed(nil, "leave")

	if #self._inside == 0 then
		self:on_executed(nil, "empty")
	end

	self:_check_on_executed_reached_amount(nil)
end

-- Lines: 582 to 595
function ElementAreaReportTrigger:_clean_destroyed_units()
	local i = 1

	while next(self._inside) and i <= #self._inside do
		local unit = self._inside[i]

		if alive(unit) and (not unit:character_damage() or not unit:character_damage():dead()) then
			i = i + 1
		else
			if alive(unit) and unit:character_damage() and unit:character_damage():dead() then
				self:on_executed(unit, "on_death")
			end

			self:_remove_inside_by_index(i)
		end
	end
end

-- Lines: 598 to 625
function ElementAreaReportTrigger:_client_check_state(unit)
	local rule_ok = self:_check_instigator_rules(unit)
	local inside = self:_is_inside(unit:position())

	if table.contains(self._inside, unit) then
		if not inside or not rule_ok then
			table.delete(self._inside, unit)
			--managers.network:session():send_to_host("to_server_area_event", 2, self._id, unit)
		end
	elseif inside and rule_ok then
		table.insert(self._inside, unit)
		--managers.network:session():send_to_host("to_server_area_event", 1, self._id, unit)
	end

	if inside then
		if rule_ok then
			if self:_has_on_executed_alternative("while_inside") then
				--managers.network:session():send_to_host("to_server_area_event", 3, self._id, unit)
			end
		elseif self:_has_on_executed_alternative("rule_failed") then
			--managers.network:session():send_to_host("to_server_area_event", 4, self._id, unit)
		end
	end
end

-- Lines: 628 to 630
function ElementAreaReportTrigger:sync_enter_area(unit)
	self:_add_inside(unit)
end

-- Lines: 633 to 635
function ElementAreaReportTrigger:sync_exit_area(unit)
	self:_remove_inside(unit)
end

-- Lines: 638 to 640
function ElementAreaReportTrigger:sync_while_in_area(unit)
	self:_while_inside(unit)
end

-- Lines: 643 to 645
function ElementAreaReportTrigger:sync_rule_failed(unit)
	self:_rule_failed(unit)
end