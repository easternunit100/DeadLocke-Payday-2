DeadLocke.ElementHint = DeadLocke.ElementHint or blt_class(DeadLocke.MissionScriptElement)
local ElementHint = DeadLocke.ElementHint

function ElementHint:init(...)
	DeadLocke.ElementHint.super.init(self, ...)
end

function ElementHint:client_on_executed(...)
	self:on_executed(...)
end

function ElementHint:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if self._values.hint_id ~= "none" then
		managers.hint:show_hint(self._values.hint_id)
	else
		DeadLocke:debug_log("Cant show hint " .. self._values.hint_id .. " in element " .. self._editor_name .. ".")
	end

	DeadLocke.ElementHint.super.on_executed(self, instigator)
end