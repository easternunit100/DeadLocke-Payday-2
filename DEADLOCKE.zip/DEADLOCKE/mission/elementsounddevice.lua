local ElementSoundDevice = DeadLockeMissionScriptElement:import("ElementSoundDevice")
function ElementSoundDevice:on_executed(...)
	if not self._values.enabled then
		return
	end

	if self._values.state == "on" or self._values.state == "off" then
		local state
		if self._values.state == "on" then
			state = "assault"
		elseif self._values.state == "off" then
			state = "control"
		end
		if state then
			SoundDevice:set_state("wave_flag", state)
		end
	end
	
	ElementSoundDevice.super.on_executed(self, ...)
end