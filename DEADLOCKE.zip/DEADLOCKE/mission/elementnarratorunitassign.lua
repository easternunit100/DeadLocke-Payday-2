local ElementNarratorUnit = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementNarratorUnit = ElementNarratorUnit


function ElementNarratorUnit:init(...)
	DeadLocke.ElementNarratorUnit.super.init(self,...)
end

function ElementNarratorUnit:client_on_executed(...)
end