DeadLocke.ElementDialogue = DeadLocke.ElementDialogue or blt_class(DeadLocke.MissionScriptElement)
local ElementDialogue = DeadLocke.ElementDialogue




ElementDialogue.MutedDialogs = {
	"pln_",
	"play_pln_",
	"btc_",
	"play_btc_",
	"vld_",
	"play_vld_",
	"plt_",
	"play_plt_",
	"dr1_",
	"play_dr1_",
	"dr2_",
	"play_dr2_",
	"pyr_",
	"play_pyr_",
	"dlr_",
	"play_dlr_",
	"rb5_",
	"play_rb5_",
	"ope_",
	"play_ope_",
	"pt1_",
	"play_pt1_",
	"pt2_",
	"play_pt2_",
	"crn_",
	"play_crn_",
	"hnc_",
	"play_hnc_",
	"cpn_",
	"play_cpn_",
	"zep_",
	"play_zep_",
	"drv_",
	"play_drv_",
	"loc_",
	"play_loc_",
	"brs_",
	"play_brs_",
	"cpg_",
	"play_cpg_",
	"mga_",
	"play_mga_",
	"bot_",
	"play_bot_",
	"snp_",
	"play_snp_",
	"com_",
	"play_com_",
	"shd_",
	"play_shd_"
}

-- Lines: 33 to 35
function ElementDialogue:init(...)
	DeadLocke.ElementDialogue.super.init(self, ...)
end


function ElementDialogue:client_on_executed(...)
	self:on_executed(...)
end


function ElementDialogue:_check_for_ssuffix(instigator)
	local dialogue = self._values.dialogue			
	if self._values.use_instigator and instigator then
		local static_data = managers.criminals:character_static_data_by_unit(instigator)
		if static_data and static_data.ssuffix then
			dialogue = dialogue:gsub("{ssuffix}", static_data.ssuffix)
		end
	end
	return dialogue
end

function ElementDialogue:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if not self._values.play_on_player_instigator_only or instigator == managers.player:player_unit() then
		local done_cbk = self._values.execute_on_executed_when_done and callback(self, self, "_done_callback", instigator) or nil

		if self._values.dialogue ~= "none" then
		
			local dialogue = self:_check_for_ssuffix(instigator)
			
			if self:_can_play() then
				if self._values.force_quit_current then
					managers.dialog:quit_dialog()
				end
				managers.dialog:queue_dialog(dialogue, {
					done_cbk = done_cbk,
					position = self._values.position,
					on_unit = self._values.use_instigator and instigator or nil
				})
			else
			
				debug_print("[ElementDialogue] Skipping muted dialogue: ", self._values.dialogue)
				
				local done_cbk = self._values.execute_on_executed_when_done and callback(self, self, "_done_callback", instigator) or nil

				if done_cbk then
					done_cbk()
				end
			end
			
		end
	end

	DeadLocke.ElementDialogue.super.on_executed(self, instigator, nil, self._values.execute_on_executed_when_done)
end

-- Lines: 74 to 76
function ElementDialogue:_done_callback(instigator, reason)
	DeadLocke.ElementDialogue.super._trigger_execute_on_executed(self, instigator)
end

-- Lines: 79 to 100
function ElementDialogue:_can_play()
	if not self._values.can_not_be_muted then
		local dialog_str = string.lower(self._values.dialogue)

		for _, mute_str in ipairs(ElementDialogue.MutedDialogs) do
			local len = string.len(mute_str)

			if string.sub(dialog_str, 1, len) == mute_str then
				return false
			end
		end

		return true
	end
	return true
end