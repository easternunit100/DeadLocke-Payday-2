local ElementToggle = DeadLockeMissionScriptElement:import("ElementToggle")
function ElementToggle:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	for _, id in ipairs(self._values.elements) do
		local element = self:element(id)
		if element then
			if self._values.toggle == "on" then
				element:set_enabled(true)
			elseif self._values.toggle == "off" then
				element:set_enabled(false)
			else
				element:set_enabled(not element:value("enabled"))
			end
		end
	end
	ElementToggle.super.on_executed(self, instigator)
end