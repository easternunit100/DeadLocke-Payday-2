local ElementTeamFilter = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementTeamFilter = ElementTeamFilter

function ElementTeamFilter:init(...)
	DeadLocke.ElementTeamFilter.super.init(self, ...)
end

function ElementTeamFilter:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	DeadLocke.ElementTeamFilter.super.on_executed(self, instigator)
end

function ElementTeamFilter:client_on_executed(...)
	self:on_executed(...)
end