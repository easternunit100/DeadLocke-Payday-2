if DeadLocke and not DeadLocke._b4_Canary and managers and managers.localization and managers.blackmarket then

	DeadLocke._b4_Canary = true
end