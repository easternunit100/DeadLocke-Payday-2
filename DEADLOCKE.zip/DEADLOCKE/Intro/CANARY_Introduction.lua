if CanaryOptions and not CanaryOptions._b4_Canary and managers and managers.localization and managers.blackmarket then
	local path = "Updates/update_list.json"
	Hooks:Add("MenuManagerOnOpenMenu", "MenuManagerOnOpenMenu_Phoenix_Intro", function( menu_manager, menu, position )
		if menu == "menu_main" then
			local file = io.open( path, "r" )
			if file then
				local loc = managers.localization
				local character = managers.blackmarket:get_preferred_character()
				character = character and loc:text("menu_"..character) or "Heister"
				local upt_list = loc:text("can_ban_news_upt_intro")
				upt_list = upt_list:gsub("{character_name}", character):gsub("{subject_name}","UPDATE")
				upt_list = upt_list.."\n"
				local file_content = file:read("*all")
				for _, name in pairs(json.decode(file_content).new_settings) do
					upt_list = upt_list.." "..loc:text(name).."\n  -"..loc:text(name.."_desc").."\n"
				end
				for _, note in pairs(json.decode(file_content).notes) do
					upt_list = upt_list.." *"..loc:text(note).."\n"
				end
				upt_list = upt_list..loc:text("can_ban_news_upt_outro1")
				upt_list = upt_list.."\n -Bain"
				file:close()
				local menu_options = {
					[1] = {
						text = loc:text("can_ban_news_exit_btn"),
						is_cancel_button = true,
					}
				}
				local menu = QuickMenu:new(loc:text("can_ban_news_mail"), upt_list, menu_options)
				menu:show()
				managers.menu_component:post_event("stinger_levelup")
				os.remove( path )
				Hooks:Remove( "MenuManagerOnOpenMenu_Phoenix_Intro" )
			end
		end
	end)
	CanaryOptions._b4_Canary = true
end