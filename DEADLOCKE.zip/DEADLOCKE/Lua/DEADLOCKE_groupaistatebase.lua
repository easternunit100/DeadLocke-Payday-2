GroupAIStateBase.BAN_DIALOG = {
	"pager_a",
	"pager_b",
	"pager_d",
	"pager_e",
	"pager_f",
	"pager_g",
	"pager_h",
	"pat_05",
	"radio_missed",
	"radio_break",
	"radio_failed",
	"p01",
	"drl_alm_snd"
}

GroupAIStateBase._called_reasons = {
	alarm_pager_not_answered = 12,
	alarm_pager_hang_up = 11,
	alarm_pager_bluff_failed = 10,
	cam_drill = 9,
	civ_drill = 9,
	cop_drill = 9
}



function GroupAIStateBase:get_ban_dialog_by_name(event_name)
	for index, dialog in pairs(GroupAIStateBase.BAN_DIALOG) do
		if dialog == event_name then
			return index
		end
	end
	return nil
end

function GroupAIStateBase:get_ban_dialog_by_index(i)
	for index, dialog in pairs(GroupAIStateBase.BAN_DIALOG) do
		if i == index then
			return dialog
		end
	end
	return nil
end


function GroupAIStateBase:get_bain_inform_by_reason(reason)
	for blame, id in pairs(GroupAIStateBase._called_reasons) do
		if blame == reason then
			return id
		end
	end
	return nil
end

local Orginal_GroupAIStateBase_teammate_comment = GroupAIStateBase.teammate_comment
function GroupAIStateBase:teammate_comment(trigger_unit, message, pos, pos_based, radius, sync)
	if radius and radius <= 0 then
		radius = nil
	end
	if pos and pos == Vector3(0,0,0) then
		pos_based = nil
	end
	Orginal_GroupAIStateBase_teammate_comment(self, trigger_unit, message, pos, pos_based, radius, sync)
end

local _GroupAIStateBase_get_anticipation_duration = GroupAIStateBase._get_anticipation_duration
function GroupAIStateBase:_get_anticipation_duration(anticipation_duration_table, is_first)
	anticipation_duration_table = {
		{45, 0.6},
		{35, 0.3},
		{25, 0.1}
	}
	return _GroupAIStateBase_get_anticipation_duration(self, anticipation_duration_table, is_first)
end



local _GroupAIStateBase_register_special_unit = GroupAIStateBase.register_special_unit	
function GroupAIStateBase:register_special_unit(u_key, category_name)
	_GroupAIStateBase_register_special_unit(self, u_key, category_name)
	if not self._ban_warning or self._ban_warning + 30 < self._t then
		if DeadLocke._ban_warns and DeadLocke._ban_warns[category_name] and DeadLocke._data.ban_special_comment then
			local bain_line = DeadLocke._ban_warns[category_name]
			if managers.dialog and self:bain_state() then
				managers.dialog:queue_narrator_dialog(bain_line, {})
			end
			if DeadLocke._data.ban_toggle then
				managers.network:session():send_to_peers_synched("bain_comment", bain_line)
			end
			self._ban_warning = self._t
		end
	end
end

function GroupAIStateBase:_coach_last_man_clbk()
	if table.size(self:all_char_criminals()) == 1 and self:bain_state() then
		local _,u_data = next(self:all_char_criminals())
		local last_char_name = managers.criminals:character_name_by_unit(u_data.unit)
		if last_char_name == managers.criminals:local_character_name() then
			local ssuffix = managers.criminals:character_static_data_by_name(last_char_name).ssuffix
			local reminder = self:hostage_count() <= 0 and "h40" or "h42"
			managers.dialog:queue_narrator_dialog(reminder..ssuffix, {})
		end
	end
end

local _GroupAIStateBase_on_enemy_weapons_hot = GroupAIStateBase.on_enemy_weapons_hot
function GroupAIStateBase:on_enemy_weapons_hot(...)
	DeadLocke:on_enemy_weapons_hot_event() 
	_GroupAIStateBase_on_enemy_weapons_hot(self, ...)
	DeadLocke.music_post_event_disabled = nil
end

function GroupAIStateBase:check_ban_voice()
	if not self._pager_bluff_phnx_warnings or not self._pager_bluff_phnx_warnings[1] or not self._pager_bluff_phnx_warnings[1].dialog then
		return
	end
	if not self._pager_bluff_phnx_warnings[1].time or self._t > self._pager_bluff_phnx_warnings[1].time then
		local data = table.remove(self._pager_bluff_phnx_warnings, 1)
		if data.required and type(data.required) == "table" then
			for i, value in pairs(data.required) do
				if not value then
					return
				end
			end
		end
		local bain_line = GroupAIStateBase.BAN_DIALOG[data.dialog]
		if bain_line and DeadLocke._data.ban_global then	
			if self:bain_state() then
				if managers and managers.dialog then
					managers.dialog:queue_narrator_dialog(bain_line, {})
				end
				if DeadLocke and DeadLocke._data and DeadLocke._data.ban_toggle then
					managers.network:session():send_to_peers_synched("bain_comment", bain_line)					
				end
			end
		end
	end
end

local _GroupAIStateBase_update = GroupAIStateBase.update
function GroupAIStateBase:update(t, dt)
	_GroupAIStateBase_update(self, t, dt)
	self:check_ban_voice()
end

function GroupAIStateBase:ban_info_dialog(dialog_i, inform_unit)
	self._pager_bluff_phnx_warnings = {}
	if dialog_i == 1 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 2, 
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 2 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = math.random(3,4), 
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 3 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 5, 
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 4 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 6, 
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 5 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 7, 
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 6 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 1,
			time = self._t + 1,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 7 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 8,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 8 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 12,
			time = self._t + 3,
			required = DeadLocke._data.ban_ponr_toggle
		})
	elseif dialog_i == 9 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 13,
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 10 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 11,
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 11 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 10,
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	elseif dialog_i == 12 then
		table.insert(self._pager_bluff_phnx_warnings, {
			dialog = 9,
			time = self._t + 2,
			required = {DeadLocke._data.ban_pag_toggle}
		})
	end		
end

local _GroupAIStateBase_on_successful_alarm_pager_bluff = GroupAIStateBase.on_successful_alarm_pager_bluff
function GroupAIStateBase:on_successful_alarm_pager_bluff()
	_GroupAIStateBase_on_successful_alarm_pager_bluff(self)
	local pager_bluffs = self._nr_successful_alarm_pager_bluffs
	if pager_bluffs and pager_bluffs >= 1 and pager_bluffs <= 4 then
		self:ban_info_dialog(pager_bluffs)
	end
end



local _GroupAIStateBase_notify_bain_weapons_hot = GroupAIStateBase.notify_bain_weapons_hot
function GroupAIStateBase:notify_bain_weapons_hot(called_reason)
	_GroupAIStateBase_notify_bain_weapons_hot(self, called_reason)
	if called_reason == "empty" then
		return
	end
	local bain_reason = self:get_bain_inform_by_reason(called_reason)
	if bain_reason then
		self:ban_info_dialog(bain_reason)
	end
end

local _GroupAIStateBase_sync_event = GroupAIStateBase.sync_event
function GroupAIStateBase:sync_event(event_id, blame_id)
	local event_name = self.EVENT_SYNC[event_id]
	local blame_name = self.BLAME_SYNC[blame_id]
	if event_name == "enemy_weapons_hot" then
		DeadLocke:on_enemy_weapons_hot_event() 
	elseif event_name == "cloaker_spawned" then
		if not DeadLocke._clkr_t or DeadLocke._clkr_t + 360 < self._t then
			managers.dialog:queue_narrator_dialog( "s04", {} )
			DeadLocke._clkr_t = self._t
		end
	elseif event_name == "phalanx_spawned" then
		DeadLocke:captain_winters_arrival_comment()
	end
	_GroupAIStateBase_sync_event(self, event_id, blame_id)
	DeadLocke.music_post_event_disabled = nil
end

---- I put a nice touch to "And Now We Wait" music 
---- that if you have this track on and have 60 seconds left
---- of escape the music will intensify.
local _GroupAIStateBase_update_point_of_no_return = GroupAIStateBase._update_point_of_no_return
function GroupAIStateBase:_update_point_of_no_return(...)
	_GroupAIStateBase_update_point_of_no_return(self, ...)
	if setup:has_queued_exec() or not self._point_of_no_return_timer then
		return
	end
	local sec = math.floor(self._point_of_no_return_timer)
	if sec < 60 and not DeadLocke._last_seconds_of_escape then
		DeadLocke._last_seconds_of_escape = true
		if DeadLocke._data.music_event_toggle and DeadLocke:is_current_track_on_list({"track_15"}) then
			managers.music:post_event("kosugi_music")
			managers.music:post_event("suspense_5")
		end
	end
end


local _GroupAIStateBase_on_player_criminal_death = GroupAIStateBase.on_player_criminal_death
function GroupAIStateBase:on_player_criminal_death(peer_id)
	_GroupAIStateBase_on_player_criminal_death(self, peer_id)
	local unit = managers.network:session():peer(peer_id):unit()
	if not unit then
		return
	end
	DeadLocke:update_downs_counter(unit, true) 
end

local _GroupAIStateBase_parse_teammate_comment = GroupAIStateBase._parse_teammate_comment
function GroupAIStateBase:_parse_teammate_comment(data)
	if data.event == "g40x_any" then
		data.allow_first_person = true
	end
	_GroupAIStateBase_parse_teammate_comment(self, data)
end

function GroupAIStateBase:chk_say_player_combat_chatter(unit)
	if not unit or not alive(unit) then
		return
	end
	if not DeadLocke:is_unit_canary_user(unit) then
		return
	end
	if Network and Network:is_client() then	
		if DeadLocke:does_peer_exist(1) then
			local session = managers.network:session()
			if session then
				session:send_to_host("spot_enemy", unit)
			end
		end
		return
	end
	self:chk_say_teamAI_combat_chatter(unit)
end


local _GroupAIStateBase_sync_smoke_grenade = GroupAIStateBase.sync_smoke_grenade
function GroupAIStateBase:sync_smoke_grenade(detonate_pos, shooter_pos, duration, flashbang)
	_GroupAIStateBase_sync_smoke_grenade(self, detonate_pos, shooter_pos, duration, flashbang)
	if flashbang then
		DelayedCalls:Add("flash_bang_warn_shit", 1, function()
			DeadLocke:criminal_comment(nil, false, "g93", detonate_pos, true, 1200, false, false)
		end)
	end
end