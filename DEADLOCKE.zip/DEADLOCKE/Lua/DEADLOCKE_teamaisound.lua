local _TeamAISound_set_voice = TeamAISound.set_voice
function TeamAISound:set_voice(voice)
	_TeamAISound_set_voice(self, voice)
	--PlayerSound.get_custom_clips(self, voice)
end
