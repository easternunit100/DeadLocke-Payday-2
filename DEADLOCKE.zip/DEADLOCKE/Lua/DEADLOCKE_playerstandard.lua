if not DeadLocke then
	return
end


local _PlayerStandard_capa = PlayerStandard._check_action_primary_attack
function PlayerStandard:_check_action_primary_attack(t, ...)
	local new_action = _PlayerStandard_capa(self, t, ...)
	if self._shooting then		
		local my_head_pos = self._unit:movement():m_head_pos()
		local col_ray = World:raycast("ray", my_head_pos, my_head_pos + self._ext_camera:forward() * 1000 * 1000, "slot_mask", World:make_slot_mask(12, 25, 8))
		if col_ray and DeadLocke._data.wacry_chttr_request then 
			if not self._unit:sound():speaking() then
				managers.groupai:state():chk_say_player_combat_chatter(self._unit)
			end	
			DeadLocke._last_fired_t = t
		end
	end
	return new_action
end

PlayerStandard.voice_type_varies = {
	boost = {
		characters = {
			russian = {"g18","f40_any","g09"},
			american = {"g18","g09"},
			spanish = {"g18","g09"},
			german = {"g18","g09","f40_any"},
			jowi = {"f40_any","g09"},
			old_hoxton = {"g18","f40_any","g09"},
			female_1 = {"g18","g09"},
			sokol = {"g18","g09"},
			wild = {"g18","g09"}
		}
	},
	revive = {
		characters = {
			american = {"g13","f41_any"},
			spanish = {"g13","f36x_any"},
			german = {"f41_any"},
			russian = {"g13","f36x_any"}
		}
	},
	escort_keep = {
		characters = {
			russian = {"p12","g09","f40_any"},
			german = {"p12","g09","f40_any"},
			spanish = {"g09","f40_any"}
		}
	},
	escort_go = {
		characters = {
			russian = {"p16","p14","p13","p15",},
			german = {"p16","p18","p15","g18"},	
			old_hoxton = {"p15","p14","p16"}
		}
	},
	escort_get_up = {
		characters = {
			russian = {"f41_any","f40_any"},
			german = {"f41_any","p15"},	
			old_hoxton = {"f41_any","p15"}
		}
	},
	mark_turret = {
		requirements = {DeadLocke._data.ply_turret_mark_toggle},
		characters = {
			russian = {"f42_any","f44x_any"},
			german = {"g10","f44x_any"},	
			old_hoxton = {"g29","f42_any","g10","f44x_any"},
			spanish = {"g29","f42_any","g10","f44x_any"}
		}
	},
	mark_camera = {
		requirements = {DeadLocke._data.ply_cams_toggle},
		characters = {
			spanish = {"f39_any","g25" },
			sokol = {"f39_any","g25" }
		}
	},
	mark_cop_quiet = {
		requirements = {DeadLocke._data.ply_spot_toggle},
		characters = {
			old_hoxton = {'g15',"{sound}"},
			russian = {'g10','g15',"{sound}"},
			american = {'g10','g15',"{sound}"},
			sokol = {'g10','g15',"{sound}"},
			jowi = {'g10','g15',"{sound}"},
			dragan = {'g10','g15',"{sound}"},
		}
	},
	medic = {
		requirements = {DeadLocke._data.ply_spot_medic_toggle},
		characters = {
			russian = {"g23","{sound}"},
			old_hoxton = {"g10","g23","{sound}"},
			spanish = {"g10","{sound}"},
			german = {"f42_any","g10","g23","{sound}"},
			american = {"g10","g23","{sound}"}
		}
	},
	tank = {
		requirements = {DeadLocke._data.ply_spot_dozer_toggle},
		distance = 800,
		chance = 0.5,
		comment = "g29",
		characters_can = {
			american = true,
			russian = true,
			german = true,
			spanish = true,
			old_hoxton = true,
			jowi = true,
			wild = true,
			sydney = true,
			jimmy = true,
			female_01 = true,
			sokol = true,
		}
	},
	tank_hw = {
		requirements = {DeadLocke._data.ply_spot_dozer_toggle},
		distance = 1000,
		chance = 0.75,
		comment = "g29",
		characters_can = {
			american = true,
			russian = true,
			german = true,
			spanish = true,
			old_hoxton = true,
			jowi = true,
			wild = true,
			sydney = true,
			jimmy = true,
			female_01 = true,
			sokol = true,
		}
	},
	tank_mini = {
		requirements = {DeadLocke._data.ply_spot_dozer_toggle},
		distance = 1000,
		chance = 0.75,
		comment = "g29",
		characters_can = {
			american = true,
			russian = true,
			german = true,
			spanish = true,
			old_hoxton = true,
			jowi = true,
			wild = true,
			sydney = true,
			jimmy = true,
			female_01 = true,
			sokol = true,
		}
	},
	tank_medic = {
		requirements = {DeadLocke._data.ply_spot_dozer_toggle},
		distance = 1000,
		chance = 0.75,
		comment = "g29",
		characters_can = {
			american = true,
			russian = true,
			german = true,
			spanish = true,
			old_hoxton = true,
			jowi = true,
			wild = true,
			sydney = true,
			jimmy = true,
			female_01 = true,
			sokol = true,
		}
	}
}

function PlayerStandard:get_voice_type_varies(voice_type, target_unit)
	if not voice_type then
		return false
	end
	local vr_character = managers.criminals:local_character_name()
	if PlayerStandard.voice_type_varies[voice_type] then
		local voice_type_data = PlayerStandard.voice_type_varies[voice_type]
		if voice_type_data.requirements then
			if not DeadLocke:has_requirements(voice_type_data.requirements) then
				return false
			end
		end
		if voice_type_data.distance and target_unit then
			local target_head_pos = target_unit:movement():m_head_pos() + math.UP * 30
			local vec = target_head_pos - self._unit:movement():m_pos()
			local distance = mvector3.normalize(vec)
			if voice_type_data.characters_can and voice_type_data.characters_can[vr_character] and distance < voice_type_data.distance and voice_type_data.chance and voice_type_data.chance < math.random() then
				return voice_type_data.comment
			end
			return false
		end
		if voice_type_data and voice_type_data.characters and voice_type_data.characters[vr_character] then
			local voices_table = voice_type_data.characters[vr_character]
			if voices_table and type(voices_table) == "table" then
				local random_sound_name = voices_table[math.random(#voices_table)]
				if random_sound_name ~= "{sound}" then
					return random_sound_name
				end
			end
		end
	end
	return false
end


local old_say_line = PlayerStandard.say_line
function PlayerStandard:say_line(sound_name, skip_alert)
	local vr_character = managers.criminals:local_character_name()
	if sound_name == "s12" and vr_character == "german" then
		sound_name = "s02x_plu"
	elseif not DeadLocke._flat_mask_up and managers.job:current_level_id() == "flat" and sound_name == "a01x_any" then
		sound_name = "p47"
		DeadLocke._flat_mask_up = true
	end
	old_say_line(self, sound_name, skip_alert)
end

local _PlayerStandard_start_action_interact = PlayerStandard._start_action_interact
function PlayerStandard:_start_action_interact(t,...)
	_PlayerStandard_start_action_interact(self, t, ...)
	if self._interact_params and self._interact_params.tweak_data == "revive" then
		local revive_unit = self._interact_params.object 
		if not DeadLocke._revive_line_t or DeadLocke._revive_line_t + self._interact_params.timer < t then
			local last_down = DeadLocke:get_maximum_downs_until_death(revive_unit)
			local revive_key = revive_unit:key()
			local suffix = "a"
			if DeadLocke:_unit_downs_by_unit_key(revive_key) then
				local unit_downs = DeadLocke:_unit_downs_by_unit_key(revive_key)
				if unit_downs >= last_down then 
					suffix = "c"
				elseif unit_downs >= 2 then
					suffix = "b"
				end
			end
			
			local revive_line = "s09"..suffix
			local character = managers.criminals:character_name_by_unit(self._unit)
			
			if character ~= "old_hoxton" and math.random() < 0.5 then
				revive_line = "s08x_sin"
			end
			
			self._unit:sound():say(revive_line, true)
			DeadLocke._revive_line_t = t
		end		
	end
end

function PlayerStandard:_start_action_intimidate(t, secondary)
	if not self._intimidate_t or tweak_data.player.movement_state.interaction_delay < t - self._intimidate_t then
		local skip_alert = managers.groupai:state():whisper_mode()
		local vr_character = managers.criminals:local_character_name()
		local voice_type, plural, prime_target = self:_get_unit_intimidation_action(not secondary, not secondary, true, false, true, nil, nil, nil, secondary)
		if prime_target and prime_target.unit and prime_target.unit.base and (prime_target.unit:base().unintimidateable or prime_target.unit:anim_data() and prime_target.unit:anim_data().unintimidateable) then
			return
		end
		local interact_type, sound_name
		local sound_suffix = plural and "plu" or "sin"	
		if voice_type == "stop" or voice_type == "down" then
			interact_type = "cmd_"..voice_type
			sound_name = "f02x_" .. sound_suffix
			if self._stopped_t and self._stopped_t + 2 > t and not plural and DeadLocke._data.ply_knees_toggle then
				sound_name = "f02b_"..sound_suffix
			else
				self._stopped_t = t
			end
			self._shout_down_t = t
		elseif voice_type == "stop_cop" then
			interact_type = "cmd_stop"
			sound_name = "l01x_" .. sound_suffix
		elseif voice_type == "mark_cop" or voice_type == "mark_cop_quiet" then
			interact_type = "cmd_point"
			local shout_sound = tweak_data.character[prime_target.unit:base()._tweak_table][voice_type == "mark_cop_quiet" and "silent_priority_shout" or "priority_shout"]
			if shout_sound then
				shout_sound = shout_sound..(voice_type == "mark_cop_quiet" and "_any" or "x_any")
				local voice_vari = voice_type == "mark_cop_quiet" and voice_type or prime_target.unit:base()._tweak_table
				if managers.modifiers.modify_value then
					sound_name = managers.modifiers:modify_value("PlayerStandart:_start_action_intimidate", sound_name, prime_target.unit)
				end
				sound_name = self:get_voice_type_varies(voice_vari, prime_target.unit) or shout_sound
			end
			if managers.player:has_category_upgrade("player", "special_enemy_highlight") then
				prime_target.unit:contour():add(managers.player:get_contour_for_marked_enemy(), true, managers.player:upgrade_value("player", "mark_enemy_time_multiplier", 1))
				managers.network:session():send_to_peers_synched("spot_enemy", prime_target.unit)
			end
		elseif voice_type == "down_cop" then
			interact_type = "cmd_down"
			sound_name = "l02x_" .. sound_suffix
		elseif voice_type == "cuff_cop" then
			interact_type = "cmd_down"
			sound_name = "l03x_"..sound_suffix
			if math.random() < 0.5 then
				sound_name = "f03b_any"
			end
		elseif voice_type == "down_stay" then
			interact_type = "cmd_down"
			sound_name = self._shout_down_t and t < self._shout_down_t + 2 and "f03b_any" or "f03a_" .. sound_suffix
		elseif voice_type == "come" then
			interact_type = "cmd_come"
			local static_data = managers.criminals:character_static_data_by_unit(prime_target.unit)
			sound_name = "f38_any"
			if static_data then
				local character_code = static_data.ssuffix
				sound_name = "f21" .. character_code .. "_sin"
			end
		elseif voice_type == "revive" then
			interact_type = "cmd_get_up"
			local static_data = managers.criminals:character_static_data_by_unit(prime_target.unit)
			if not static_data then
				return
			end
			local character_code = static_data.ssuffix
			sound_name = self:get_voice_type_varies(voice_type) or "f36x_any"
			if math.random() < self._ext_movement:rally_skill_data().revive_chance then
				prime_target.unit:interaction():interact(self._unit)
			end
			self._ext_movement:rally_skill_data().morale_boost_delay_t = managers.player:player_timer():time() + (self._ext_movement:rally_skill_data().morale_boost_cooldown_t or 3.5)
		elseif voice_type == "boost" then
			interact_type = "cmd_gogo"
			local static_data = managers.criminals:character_static_data_by_unit(prime_target.unit)
			if not static_data then
				return
			end
			sound_name = self:get_voice_type_varies(voice_type) or "g18"
			self._ext_movement:rally_skill_data().morale_boost_delay_t = managers.player:player_timer():time() + (self._ext_movement:rally_skill_data().morale_boost_cooldown_t or 3.5)
		elseif voice_type == "escort" then
			interact_type = "cmd_point"
			sound_name = "f41_" .. sound_suffix
		elseif voice_type == "escort_keep" then
			interact_type = "cmd_point"
			sound_name = self:get_voice_type_varies(voice_type) or "f40_any"
			self._keep_going_t = t
		elseif voice_type == "escort_go" then
			interact_type = "cmd_point"
			if self._keep_going_t and self._keep_going_t + 2 > t then
				sound_name = self:get_voice_type_varies(voice_type) or "f40_any"
			else
				sound_name = self:get_voice_type_varies("escort_get_up") or "f41_any"
			end
		elseif voice_type == "bridge_codeword" then
			sound_name = "bri_14" --- This is just a PDTH leftover, it plays nothing.
			interact_type = "cmd_point"
		elseif voice_type == "bridge_chair" then
			sound_name = "bri_29" --- This is just a PDTH leftover, it plays nothing.
			interact_type = "cmd_point"
		elseif voice_type == "undercover_interrogate" then
			sound_name = "f46x_any"
			interact_type = "cmd_point"
		elseif voice_type == "undercover_escort" then
			sound_name = self:get_voice_type_varies("escort_get_up") or "f41_any"
			interact_type = "cmd_point"
		elseif voice_type == "mark_camera" then
			sound_name = self:get_voice_type_varies(voice_type) or "f39_any"
			interact_type = "cmd_point"
			prime_target.unit:contour():add("mark_unit", true, managers.player:upgrade_value("player", "mark_enemy_time_multiplier", 1))
		elseif voice_type == "mark_turret" then
			sound_name = self:get_voice_type_varies(voice_type) or "f44x_any"
			interact_type = "cmd_point"
			local type = prime_target.unit:base().get_type and prime_target.unit:base():get_type()
			prime_target.unit:contour():add(managers.player:get_contour_for_marked_enemy(type), true, managers.player:upgrade_value("player", "mark_enemy_time_multiplier", 1))
		elseif voice_type == "ai_stay" then
			sound_name = "f48x_any"
			interact_type = "cmd_stop"
		elseif voice_type == "can_need_med" then
			sound_name = "g80x_any"
			interact_type = "cmd_point"
		end
		self:_do_action_intimidate(t, interact_type, sound_name, skip_alert)
	end
end