local Camdestroy_old = Camdestroy_old or ElementSecurityCamera.on_destroyed
function ElementSecurityCamera:on_destroyed()
	if not DeadLocke._cameras_comment then
		DelayedCalls:Add("guards_checking_cams", 5, function()
			if managers and managers.groupai and managers.groupai:state() and  managers.groupai:state():whisper_mode() then
				DeadLocke:criminal_comment(nil, true, "c01", nil, false, nil, true, true)
				DeadLocke._cameras_comment = true
			end
		end)
	end
end
