local _LevelsTweakData_get_music_event = LevelsTweakData.get_music_event
function LevelsTweakData:get_music_event(stage)
	local music_event = _LevelsTweakData_get_music_event(self, stage)
	music_event = DeadLocke:get_overrided_music_event(music_event) or music_event
	return DeadLocke:get_overrided_music_event(music_event)
end