dofile(DeadLocke._path.."playback/DEADLOCKE_rb4_clips.lua")
dofile(DeadLocke._path.."playback/DEADLOCKE_rb3_clips.lua")
dofile(DeadLocke._path.."playback/DEADLOCKE_rb5_clips.lua")
function DeadLocke:get_heister_custom_clips()
	if not blt or not blt.xaudio then
		log("[DeadLocke:get_heister_custom_clips] no xaudio installed yet...")
		return
	end
	blt.xaudio.setup()
	self:get_rb5_audiofiles()	
	self:get_rb4_audiofiles()	
	self:get_rb3_audiofiles()	
	self._current_wave_flag = "control"
	log("[DeadLocke:get_heister_custom_clips]  Loaded all custom heister sounds!!!")
end