local _CarryData_link_to = CarryData.link_to
function CarryData:link_to(parent_unit, keep_collisions)
	_CarryData_link_to(self, parent_unit, keep_collisions)
	if self._linked_to and managers.enemy:all_enemies()[self._linked_to:key()] then
		DeadLocke:comment_on_thief_looter(self._unit)
	end
end