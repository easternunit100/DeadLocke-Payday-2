DeadLockeNetwork = DeadLockeNetwork or {}
DeadLockeNetwork._network_id = "ProjectDeadlocke2"
--- Network Related functions
function DeadLockeNetwork:send_json_data_to_peers(...)	
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	LuaNetworking:SendToPeers( self._network_id, DeadLocke:get_json_data_from_params(...) )
end

function DeadLockeNetwork:send_json_data_to_peer(peer_id, ...)
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	LuaNetworking:SendToPeer(peer_id, self._network_id, DeadLocke:get_json_data_from_params(...) )
end
function DeadLockeNetwork:send_json_data_to_unit(unit, ...)
	local peer_id = managers.criminals:character_peer_id_by_unit(unit)
	if peer_id ~= 0 then
		LuaNetworking:SendToPeer(peer_id, self._network_id, DeadLocke:get_json_data_from_params(...) )
	end
end

function DeadLockeNetwork:send_json_data_to_host(...)
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	LuaNetworking:SendToPeer(1 , self._network_id, DeadLocke:get_json_data_from_params(...) )
end

function DeadLockeNetwork:send_json_data_to_peers_except(peer_id, ...)
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	LuaNetworking:SendToPeersExcept(peer_id , self._network_id, DeadLocke:get_json_data_from_params(...) )
end

function DeadLockeNetwork:sync_play_ogg_line(sound_name, character, sender)
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	local unit = managers.criminals:character_unit_by_name(character)
	if unit then
		unit:sound():play_ogg_line(sound_name)
	end
end
function DeadLockeNetwork:sync_chk_say_player_combat_chatter(character, sender)
	if not managers or not managers.groupai or not managers.groupai.state or not managers.groupai:state().chk_say_player_combat_chatter then
		return
	end
	local unit = managers.criminals:character_unit_by_name(character)
	if unit and alive(unit) then
		managers.groupai:state():chk_say_player_combat_chatter(unit)
	end
end
function DeadLockeNetwork:sync_cancel_id_on_executed(type, id, sender)
	self:cancel_id_on_executed(type, id, false)
end
function DeadLockeNetwork:bain_comment(bain_line, skip_narr_prefix, sender)
	if managers.dialog and managers.groupai and managers.groupai:state():bain_state() then
		if skip_narr_prefix then
			managers.dialog:queue_dialog(bain_line, {})
		else
			managers.dialog:queue_narrator_dialog(bain_line, {})
		end
	end
end
function DeadLockeNetwork:sync_criminal_comment(trigger_unit_name, allow_first_person, message, string_pos, pos_based, radius, play_ogg_comment)
	if not managers or not managers.groupai or not managers.groupai:state() then
		return
	end
	self:criminal_comment(trigger_unit_name, allow_first_person, message, string_pos, pos_based, radius, play_ogg_comment, false)
end
function DeadLockeNetwork:sync_play_ogg_comment(trigger_unit_name, allow_first_person, message, string_pos, pos_based, radius, vari_unit)
	if not managers or not managers.groupai or not managers.groupai:state() then
		return
	end
end
function DeadLockeNetwork:sync_last_speaker(character, sender)
	local unit = managers.criminals:character_unit_by_name(character)
	if unit then
		self._last_speaker = unit
	end
end
function DeadLockeNetwork:sync_music_event(track_list, event, sender)
end
function DeadLockeNetwork:sync_set_interactor_voice(player_voice, sender)
	local player = managers.player:player_unit()
	if player and alive(player) then
		local static_data = managers.criminals:character_static_data_by_unit(player)
		if static_data and static_data.voice then
			player:sound():set_interactor_voice(player_voice)
			player:sound():say(string.format("Play_%s_answering", static_data.voice), true, true)
		end
	end
end
function DeadLockeNetwork:sync_set_active(name, sender)
	if name then
		local unit = managers.criminals:character_unit_by_name(name)
		if unit and alive(unit) and unit.interaction then
			unit:interaction():set_tweak_data("talk_to_heister_"..name)
			unit:interaction():set_active_safehouse(true)
		end
	end
end
function DeadLockeNetwork:sync_teammate_message(message_id, sender)
	if message_id then
		self:receive_message_by_message_id(message_id, sender)
	end
end
function DeadLockeNetwork:sync_additional_lives(sender)
end
function DeadLockeNetwork:debug_log_crap(arg1, sender)
	log(arg1)
end
function DeadLockeNetwork:sync_enable_peer_data_value(value_id, enabled, sender)
	if not DeadLocke:does_peer_exist(sender) then
		return
	end
	DeadLocke:enable_peer_data_value(value_id, enabled, sender)
end

function DeadLockeNetwork:now_send_me_yours(sender)
	DeadLocke:send_my_values_to_sender(sender)
end
function DeadLockeNetwork:send_me_your_data(sender) 
	DeadLocke:send_my_values_to_sender(sender)
	self:send_json_data_to_peer(sender, "now_send_me_yours")
end
function DeadLockeNetwork:sync_deadlocke_synchronized(sender) 
	DeadLocke:add_peer(sender)
	self:send_json_data_to_peer(sender, "send_me_your_data")
end
function DeadLockeNetwork:sync_deadlocke_pended(sender) 
	DeadLocke:add_peer(sender)
	self:send_json_data_to_peer(sender, "sync_deadlocke_synchronized")
end
function DeadLockeNetwork:sync_deadlock_pending(sender) 
	self:send_json_data_to_peer(sender, "sync_deadlocke_pended")
end
function DeadLockeNetwork:get_function_from_json_data(data, sender) 
	local json_data = DeadLocke:safe_decode(data)
	if not json_data or not next(json_data) then
		log("[DeadLockeNetwork:get_function_from_json_data] ERROR WHILE DECODING JSON_DATA!!! : "..tostring(data))
		return
	end
	if not sender then
		log("[NetworkReceivedData_DeadLocke] : no sender identified!!")
		return
	end
	
	local only_one
	if #json_data <= 1 then
		only_one = true
	else
		table.insert(json_data, sender)
	end
	local func_name = table.remove(json_data, 1)
	if self[func_name] then
		if only_one then
			self[func_name](self, sender)
		else
			self[func_name](self, unpack(json_data))
		end
	end
end


Hooks:Add("NetworkReceivedData", "NetworkReceivedData_DeadLocke", function(sender, network_id, data)
	if network_id == DeadLockeNetwork._network_id then
		DeadLockeNetwork:get_function_from_json_data(data, sender) 
	end	
end)
Hooks:Add("BaseNetworkSessionOnLoadComplete", "BaseNetworkSessionOnLoadComplete_PHOENIX", function(local_peer, id)
	DeadLocke:add_peer(id)
	DeadLocke:incharge_speaker(true)
	DeadLockeNetwork:send_json_data_to_peers("sync_deadlock_pending")
	DeadLocke:apply_dlocke_options_to_peer(id)	
end)