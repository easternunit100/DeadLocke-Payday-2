local _GroupAIStateBesiege_spawn_phalanx = GroupAIStateBesiege._spawn_phalanx
function GroupAIStateBesiege:_spawn_phalanx()
	_GroupAIStateBesiege_spawn_phalanx(self)
	if self._phalanx_spawn_group then
		DeadLocke:captain_winters_arrival_comment()
	end
end