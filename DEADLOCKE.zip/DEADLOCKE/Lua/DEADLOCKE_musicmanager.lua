local _MusicManager_post_event = MusicManager.post_event
function MusicManager:post_event(name)
	if DeadLocke and DeadLocke.music_post_event_disabled then
		name = nil
	end
	_MusicManager_post_event(self, name)
end