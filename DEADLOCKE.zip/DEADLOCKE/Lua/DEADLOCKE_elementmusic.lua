if not ElementMusic then
	return
end

function ElementMusic:_can_set_fake_assault_music()
	if not DeadLocke._data.music_event_toggle then
		return false
	end
	if not self._values.track_list then
		return true
	end
	for i,v in pairs(self._values.track_list) do
		if v == Global.music_manager.current_track then
			return true
		end
	end
	return false
end


local _ElementMusic_on_executed = ElementMusic.on_executed
function ElementMusic:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	if DeadLocke:level_id() == "man" then
		if self._id == 103025 then
			self._values.track_list = {"track_pth_05", "track_43"}
			if self:_can_set_fake_assault_music() then				
				self._values.music_event = "music_heist_assault"
			end
		end
	end
	_ElementMusic_on_executed(self, instigator)
end
