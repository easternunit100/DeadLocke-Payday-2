local old_update_downed = PlayerDamage.update_downed 
function PlayerDamage:update_downed(t, dt)
	if self._downed_timer and self._downed_timer <= 10 and not self._said_help then		
		self._unit:sound():say("f11e_plu", true, false)
		self._said_help = true		
	end
	return old_update_downed(self, t, dt)
end

local _PlayerDamage_on_downed = PlayerDamage.on_downed
function PlayerDamage:on_downed()
	_PlayerDamage_on_downed(self)
	if self._down_time == 0 then
		self._said_help = true
	end
end

function PlayerDamage:comment_on_bang_effect()
	local t = TimerManager:game():time()
	if self._unit and alive(self._unit) and (not self._flashbang_comment_t or self._flashbang_comment_t + 3 < t) then
		PlayerStandard.say_line(self, "g41x_any")
		self._flashbang_comment_t = t
	end
end

--Flashbangs
local Flashbanged_old = Flashbanged_old or PlayerDamage.on_flashbanged
function PlayerDamage:on_flashbanged(sound_eff_mul)
	Flashbanged_old( self, sound_eff_mul )
	self:comment_on_bang_effect()
end

--[[local old_start_concussion = PlayerDamage._start_concussion
function PlayerDamage:_start_concussion(mul)
	old_start_concussion(self, mul)
	self:comment_on_bang_effect()
end]]

local _PlayerDamage_call_listeners = PlayerDamage._call_listeners
function PlayerDamage:_call_listeners(damage_info, ...)
	_PlayerDamage_call_listeners(self, damage_info, ...)
	if damage_info and damage_info.result and damage_info.result.variant == "bullet" and damage_info.result.type == "hurt" then
		if damage_info.attacker_unit and managers.enemy:is_enemy(damage_info.attacker_unit) then
			local t = TimerManager:game():time()
			if DeadLocke._last_fired_t and DeadLocke._last_fired_t + 2 > t then
				if DeadLocke._data.wacry_chttr_request then
					if not self:need_revive() then
						if not self._unit:sound():speaking() then
							managers.groupai:state():chk_say_player_combat_chatter(self._unit)
						end
					end
				end
			end
		end
	end
end

local _PlayerDamage_regenerate_armor = PlayerDamage._regenerate_armor
function PlayerDamage:_regenerate_armor(...)
	_PlayerDamage_regenerate_armor(self, ...)
	DeadLocke:_normalize_combat_chatter_chance()
end

local old_pause_downed_timer = PlayerDamage.pause_downed_timer
function PlayerDamage:pause_downed_timer(...)
	old_pause_downed_timer(self, ...)
	local t = TimerManager:game():time()
	if self._downed_paused_counter == 1 then
		self._bar_helpup = self._unit:sound():play("bar_helpup")
		DelayedCalls:Add("phnx_healed_say", 1, function()
			if not self._said_fixmeup_t or self._said_fixmeup_t + tweak_data.interaction.revive.timer < t then
				if self._unit and alive(self._unit) then
					self._unit:sound():say( "s05a_sin", true, false)	
					self._said_fixmeup_t = t		
				end
			end
		end)
	end
end

local _PlayerDamage_unpause_downed_timer = PlayerDamage.unpause_downed_timer
function PlayerDamage:unpause_downed_timer(peer_id)
	_PlayerDamage_unpause_downed_timer(self, peer_id)
	if self._downed_paused_counter == 0 and self._bar_helpup then
		self._bar_helpup:stop()
		self._bar_helpup = nil
	end
end
