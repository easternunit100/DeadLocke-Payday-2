local old_CopDamage_damage_bullet = CopDamage.damage_bullet
function CopDamage:damage_bullet(attack_data)
	local result = old_CopDamage_damage_bullet(self, attack_data)
	if result and result.type == "death" then
		if managers.groupai:state():whisper_mode() then
			if attack_data and attack_data.weapon_unit and attack_data.weapon_unit:base() then
				if self._unit:movement():cool() then
					local weapon_unit = attack_data.weapon_unit
					local vr_character = managers.criminals:local_character_name()
					if not DeadLocke:is_tutorial_stage() then
						if CopDamage.is_cop(self._unit:base()._tweak_table) then
							if vr_character == "russian" then
								if attack_data.attacker_unit and attack_data.attacker_unit:base().is_local_player then								
									local russian_comment = {'Play_rb4_sh12_05','Play_rb4_sh11_06','Play_rb4_sh12_10'}
									local special_comment = russian_comment[math.random(#russian_comment)]
									local player_unit = attack_data.attacker_unit
									local success
									local wp_base = weapon_unit:base()
									if wp_base then
										if wp_base.got_silencer then
											if wp_base:got_silencer() then
												success = true
											end
										elseif wp_base.weapon_tweak_data then
											if wp_base:weapon_tweak_data().category == "bow" then
												if wp_base._damage_class_string ~= "InstantExplosiveBulletBase" then
													success = true
												end
											end
										elseif wp_base._projectile_entry and not tweak_data.projectiles[tostring(wp_base._projectile_entry)].is_explosive  then
											success = true
										end	
									end
									if success then
										DelayedCalls:Add("dallas_comment_unit_key_death_"..tostring(self._unit:key()), .75, function()
											if player_unit and alive(player_unit) then
												player_unit:sound():say(special_comment, false, false)
											end
										end)
									end
								end
							end
						end
					end
				end				
			end
		end
	end
	return result
end