DeadLocke._dialog_data = DeadLocke:load_json(DeadLocke._path.."data/DIALOG_DATA.json")
DeadLocke._duplicate_to_ssuffix = {
	"Play_ban_h40",
	"Play_ban_h02",
	"Play_ban_h42",
	"Play_loc_h40",
	"Play_loc_h02",
	"Play_loc_h42"
}
local _DialogManager_load_dialog_data = DialogManager._load_dialog_data
function DialogManager:_load_dialog_data(name)
	_DialogManager_load_dialog_data(self, name)
	for index, id in pairs(DeadLocke._duplicate_to_ssuffix) do
		for _, char in ipairs(tweak_data.criminals.characters) do
			local ssuffix = char and char.static_data and char.static_data.ssuffix or ""
			table.insert(DeadLocke._dialog_data, {
				_meta = "dialog",
				id = id..ssuffix,
				sound = id,
				priority = 1		
			})
		end
	end
	if DeadLocke._dialog_data then
		for _, node in ipairs(DeadLocke._dialog_data) do
			if node._meta == "dialog" then
				if node.id then
					self._dialog_list[node.id] = self._dialog_list[node.id] or {
						id = node.id,
						character = node.character,
						sound = node.sound,
						string_id = node.string_id,
						priority = node.priority or tweak_data.dialog.DEFAULT_PRIORITY
					}
				end
			end
		end
	end
end


function DialogManager:current_narrator()
	return self._current_narrator
end

function DialogManager:queue_narrator_dialog(id, params)
	return self:queue_dialog(self._narrator_prefix .. id, params)
end

local _DialogManager_set_narrator = DialogManager.set_narrator
function DialogManager:set_narrator(narrator)
	_DialogManager_set_narrator(self, narrator)
	self._current_narrator = narrator
end