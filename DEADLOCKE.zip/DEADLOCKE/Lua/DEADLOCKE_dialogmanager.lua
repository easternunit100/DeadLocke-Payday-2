DeadLocke._dialog_data = DeadLocke:load_json(DeadLocke._path.."data/DIALOG_DATA.json")
local _DialogManager_load_dialog_data = DialogManager._load_dialog_data
function DialogManager:_load_dialog_data(name)
	_DialogManager_load_dialog_data(self, name)
	if DeadLocke._dialog_data then
		for _, node in ipairs(DeadLocke._dialog_data) do
			if node._meta == "dialog" then
				if node.id then
					self._dialog_list[node.id] = self._dialog_list[node.id] or {
						id = node.id,
						character = node.character,
						sound = node.sound,
						string_id = node.string_id,
						priority = node.priority or tweak_data.dialog.DEFAULT_PRIORITY
					}
				end
			end
		end
	end
end

local _DialogManager_finished = DialogManager.finished
function DialogManager:finished()
	if self._comment_on_finished and self._current_dialog.id then
		local dialog = self._comment_on_finished
		if dialog.respond_to_ids[self._current_dialog.id] then
			DelayedCalls:Add("DialogManager_on_finished_id_"..self._current_dialog.id, dialog.delay or 0, function()			
				DeadLocke:criminal_comment(nil, true, dialog.comment, nil, false, nil, false, false)
			end)
		end
		self._comment_on_finished = nil
	end
	_DialogManager_finished(self)
end