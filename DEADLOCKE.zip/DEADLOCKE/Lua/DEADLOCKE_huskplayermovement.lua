local _HuskPlayerMovement_start_bleedout = HuskPlayerMovement._start_bleedout
function HuskPlayerMovement:_start_bleedout(event_desc)
	if _HuskPlayerMovement_start_bleedout(self, event_desc) then
		DeadLocke:update_downs_counter(self._unit, false)
	end
end