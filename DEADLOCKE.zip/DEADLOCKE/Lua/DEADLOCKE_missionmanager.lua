local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end

if Network and Network:is_client() then
	local _MissionManager_client_run_mission_element = MissionManager.client_run_mission_element
	function MissionManager:client_run_mission_element(id, unit, orientation_element_index)
		_MissionManager_client_run_mission_element(self, id, unit, orientation_element_index)
		if id then
			DeadLocke:on_execute_mod(id, unit)
		end
	end
end