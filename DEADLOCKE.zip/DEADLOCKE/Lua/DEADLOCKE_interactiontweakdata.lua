--- Yea this is my first time I add tweak_data :/........ :D!!!!
local _InteractionTweakData_init = InteractionTweakData.init
function InteractionTweakData:init(tweak_data)
	_InteractionTweakData_init(self, tweak_data)
	self.lance.phoenix_event = {}
	self.lance.phoenix_event.start_say = {
		sound = {
			default = {"g61"},
		},
		sync = true
	}
	self.lance.phoenix_event.on_interacted = {
		sound = {
			default = {"g21"},
		},
		delay = 1,
		sync = true
	}


	self.drill.phoenix_event = clone(self.lance.phoenix_event)

	self.drill_upgrade.phoenix_event = {}
	self.drill_upgrade.phoenix_event.start_say = {
		sound = {
			default = {"g61"},
		},
		sync = true
	}

	self.pick_lock_30.say_waiting = "p04"

	self.sc_tape_loop.say_waiting = "p04"
	self.sc_tape_loop.phoenix_event = {}
	self.sc_tape_loop.phoenix_event.on_interacted = {
		sound = {default ={"g18"}},
		sync = true
	}

	self.drill_jammed.phoenix_event = {}
	self.drill_jammed.phoenix_event.start_say = {
		sound = {
			default = {'g22', 'g92', 'g61', 'p04'},
			german = {"g72",'g22', 'g92', 'g61', 'p04'}
		},
		delay_id_t = 30,
		sync = true
	}



	self.huge_lance_jammed.phoenix_event = self.drill_jammed.phoenix_event
	self.lance_jammed.phoenix_event = self.drill_jammed.phoenix_event


	self.hostage_convert.phoenix_event = {}
	self.hostage_convert.phoenix_event.start_say = {
		value = "hostage_convert",
		sound = {
			american = {"f38_any","s21x_sin","f40_any"},
			spanish = {"f38_any","s21x_sin","f40_any"},
			german = {"f38_any","s21x_sin","f40_any"},
			russian = {"f38_any","s21x_sin","f40_any"},
			default = {"f38_any","f40_any"}
		},
		sync = true
	}

	self.hostage_stay.phoenix_event = {}
	self.hostage_stay.phoenix_event.on_interacted = {
		sound = {default = {"f03a_sin","f03b_any"}},
		sync = true
	}

	self.connect_hose.phoenix_event = {}
	self.connect_hose.phoenix_event.start_say = {
		sound = {german = {"g72"}},
		sync = true
	}


	self.gen_pku_jewelry.phoenix_event = {}
	self.gen_pku_jewelry.phoenix_event.on_interacted = {
		sound = {
			russian = {"Play_rbr_knk_jwl_b_dia_23","Play_rb4_sh21_02"},
			german = {"Play_rbr_knk_jwl_b_dia_23"},
			old_hoxton = {"Play_rbr_knk_jwl_b_dia_23"}
		},
		sync = false,
		do_not_repeat_unit = true,
		only_whisper = true
	}



	self.gen_pku_artifact.phoenix_event = self.gen_pku_jewelry.phoenix_event

	self.bodybags_bag.phoenix_event = {}
	self.bodybags_bag.phoenix_event.on_interacted = {
		sound = {russian = {"Play_rb4_sh12_18"}},
		start_say_chance = 50,
		delay_id_t = 30,
		sync = false
	}


	self.corpse_dispose.phoenix_event = {}
	self.corpse_dispose.phoenix_event.on_interacted = {
		sound = {russian = {"Play_rb4_sh12_06"}},
		sync = false,
		delay_id_t = 60,
		delay = 1.5,
		is_cop_check = true
	}

	self.pickup_keycard.phoenix_event = {}
	self.pickup_keycard.phoenix_event.on_interacted = {
		sound = {
			default = {"v10"}
		},
		sync = true
	}

	self.cut_fence.phoenix_event = {}
	self.cut_fence.phoenix_event.on_interacted = {
		sound = {
			russian = {"Play_rb4_sh12_02"}
		},
		sync = false,
		delay_id_t = 30,
		only_whisper = true
	}

	self.gen_int_thermite_rig.say_waiting = "i01x_any"
	
	self.key.phoenix_event = {}
	self.key.phoenix_event.on_interacted = {
		sound = {default = {"p30"}},
		sync = true
	}
	self.hostage_trade.phoenix_event = {}
	self.hostage_trade.phoenix_event.on_interacted = {
		sound = {default = {"f40_any"}},
		sync = true
	}
	
	self.can_hi_to_heister = {}
	self.can_hi_to_heister.timer = 0
	self.can_hi_to_heister.interact_distance = 300
	self.can_hi_to_heister.max_interact_distance = 0
	self.can_hi_to_heister.icon = "develop"
	self.can_hi_to_heister.no_contour = true
	self.can_hi_to_heister.action_text_id = "hud_can_hi_to_heister"
	self.can_hi_to_heister.interaction_obj = Idstring("Spine2")
end
