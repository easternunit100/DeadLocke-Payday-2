local _UnitNetworkHandler_long_dis_interaction = UnitNetworkHandler.long_dis_interaction
function UnitNetworkHandler:long_dis_interaction(target_unit, amount, aggressor_unit, secondary)
	if not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_character(target_unit) or not self._verify_character(aggressor_unit) then
		return
	end
	
	--[[if target_unit == aggressor_unit then
		local gstate = managers and managers.groupai and managers.groupai.state and managers.groupai:state()
		if gstate and gstate.chk_say_player_combat_chatter then
			gstate:chk_say_player_combat_chatter(target_unit) 
		end
		return
	end]]
	
	if target_unit and target_unit.base and target_unit:base() and target_unit:base().is_local_player then
		local respond_line, delay
		if secondary then
			if DeadLocke._data.ply_defend_call_toggle then
				respond_line = "r03x_sin"
				delay = 1.5
			end
		elseif DeadLocke._data.ply_call_toggle then
			respond_line = (aggressor_unit:movement():downed() and "r02a" or "r01x") .."_sin"
		end
		if respond_line then
			DelayedCalls:Add("deadlocked_on_respond", delay or 0, function()
				if target_unit and alive(target_unit) then
					target_unit:sound():say(respond_line, true)
				end
			end)
		end
	end
	_UnitNetworkHandler_long_dis_interaction(self, target_unit, amount, aggressor_unit, secondary)
end	
local _UnitNetworkHandler_sync_doctor_bag_taken = UnitNetworkHandler.sync_doctor_bag_taken
function UnitNetworkHandler:sync_doctor_bag_taken(unit, amount, sender, ...)
	if not alive(unit) or not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_sender(sender) then
		return
	end
	_UnitNetworkHandler_sync_doctor_bag_taken(self, unit, amount, sender, ...)
	local peer = self._verify_sender(sender)
	DeadLocke:update_downs_counter(peer:unit(), true)
end

function UnitNetworkHandler:spot_enemy(unit)
	if not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_character(unit) then
		return
	end
	local gstate = managers and managers.groupai and managers.groupai.state and managers.groupai:state()
	if gstate and gstate.chk_say_player_combat_chatter  then
		if unit and alive(unit) and unit.base and unit:base() and unit:base().is_husk_player then
			gstate:chk_say_player_combat_chatter(unit)
		end
	end
end