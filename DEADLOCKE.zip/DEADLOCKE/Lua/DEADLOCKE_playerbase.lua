local can_chk_set_unit_upgrades = PlayerBase._chk_set_unit_upgrades
function PlayerBase:_chk_set_unit_upgrades()
	can_chk_set_unit_upgrades(self)
	if managers.player:has_category_upgrade("player", "additional_lives") then		
		DeadLockeNetwork:enable_peer_data_value("additional_lives", true)
	end
end