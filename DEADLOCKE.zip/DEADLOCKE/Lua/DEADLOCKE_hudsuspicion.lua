local HUDDetected_old = HUDSuspicion.discovered
function HUDSuspicion:discovered()
	HUDDetected_old(self)
	local t = TimerManager:game():time()
	local vr_character = managers.criminals:local_character_name()
	local vr_fuck = vr_character == "russian" and {'Play_rb4_sh11_07','g29'} or {'g29'}
	if not DeadLocke._discovered_cooldown_t or DeadLocke._discovered_cooldown_t < t then
		if DeadLocke._data.ply_detect_toggle then
			local player_unit = managers.player:player_unit()
			if player_unit and alive(player_unit) then
				player_unit:sound():say( vr_fuck[math.random( #vr_fuck )] )
				if not DeadLocke._discovered_counter or DeadLocke._discovered_counter < 3 then
					local timer = 1
					DeadLocke._discovered_counter = (DeadLocke._discovered_counter or 0) + 1
					if DeadLocke._discovered_counter == 3 then
						timer = 4
						DeadLocke._discovered_counter = nil
					end
					DeadLocke._discovered_cooldown_t = t + timer
				end
			end
		end
	end
end