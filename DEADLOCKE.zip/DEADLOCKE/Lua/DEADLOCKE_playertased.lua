local PlayerTased_comment = PlayerTased.enter
function PlayerTased:enter(state_data, enter_data)
	PlayerTased_comment(self, state_data, enter_data)
	self._unit:sound():say( "s07x_sin", true, false )
end