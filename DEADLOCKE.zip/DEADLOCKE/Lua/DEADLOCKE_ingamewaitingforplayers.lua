local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end


local _IngameWaitingForPlayersState_init = IngameWaitingForPlayersState.init
function IngameWaitingForPlayersState:init(game_state_machine)
	_IngameWaitingForPlayersState_init(self, game_state_machine)
	local level_id = Global and Global.level_data and Global.level_data.level_id
	if level_id then
		if not DeadLocke._loaded_mission_script then
			if game_state_machine:current_state_name() ~= "menu_main" then
				DeadLocke:Load_map_dialogue(level_id)
				DeadLocke._loaded_mission_script = true
			end
		end
	end
end