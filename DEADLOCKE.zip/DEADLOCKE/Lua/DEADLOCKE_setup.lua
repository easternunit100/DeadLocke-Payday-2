if not SoundDevice then
	return
end

local DeadLockeSoundDevice
if SoundDevice and type(SoundDevice) == "userdata" then
	DeadLockeSoundDevice = getmetatable(SoundDevice)
end

if DeadLockeSoundDevice then
	local _DeadLockeSoundDevice_set_state = DeadLockeSoundDevice.set_state
	function DeadLockeSoundDevice:set_state(type, state)
		if type == "wave_flag" and DeadLocke then
			DeadLocke._current_wave_flag = state
		end
		return _DeadLockeSoundDevice_set_state(self, type, state)
	end
end