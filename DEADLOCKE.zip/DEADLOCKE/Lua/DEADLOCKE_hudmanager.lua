local _HUDManager_sync_start_anticipation_music = HUDManager.sync_start_anticipation_music
function HUDManager:sync_start_anticipation_music()
	_HUDManager_sync_start_anticipation_music(self)
	local time = 30
	DelayedCalls:Add("police_in_wait_for_it", time - 3, function()
		local get_ready = {"a01x_any"}
		local vr_character = managers.criminals:local_character_name()
		if vr_character == "russian" then
			table.insert(get_ready, "Play_rb4_sh21_01")
		end
		local loc_unit = managers.player:player_unit()
		if loc_unit and alive(loc_unit) then
			loc_unit:sound():say(get_ready[math.random(#get_ready)], false, false)
		end
	end)
	time = time - 5
	DelayedCalls:Add("police_in_10s", time, function()
		DeadLocke:say("g50", "ply_assault_toggle", DeadLocke:local_peer_data().ply_assault_ai_toggle)
	end)
	time = time - 10
	DelayedCalls:Add("police_in_20s", time, function()
		DeadLocke:say("g70", "ply_assault_toggle", DeadLocke:local_peer_data().ply_assault_ai_toggle)
	end)
	time = time - 10
	DelayedCalls:Add("police_in_30s", time, function()
		DeadLocke:say("g62", "ply_assault_toggle", DeadLocke:local_peer_data().ply_assault_ai_toggle)
	end)
end

function HUDManager:check_anticipation_voice(t)
	if not self._anticipation_dialogs[1] then
		return
	end
	if t < self._anticipation_dialogs[1].time then
		local data = table.remove(self._anticipation_dialogs, 1)
		if DeadLocke._data.ban_global and not self._hud.in_assault then
			self:sync_assault_dialog(data.dialog)
			if DeadLocke._data.ban_toggle then
				managers.network:session():send_to_peers_synched("sync_assault_dialog", data.dialog)
			end
		end
	end
end

local _HUDManager_sync_start_assault = HUDManager.sync_start_assault
function HUDManager:sync_start_assault(data)
	_HUDManager_sync_start_assault(self, data)
	if not DeadLocke._in_assault then
		DelayedCalls:Add("DeadLocke_assault_comment", 1, function()
			local player = managers.player:player_unit()
			if player and alive(player) then
				player:sound():say("a01x_any")
			end
		end)
		DeadLocke._in_assault = true
	end
end

local _HUDManager_sync_end_assault = HUDManager.sync_end_assault
function HUDManager:sync_end_assault(result)
	_HUDManager_sync_end_assault(self, result)
	DeadLocke._in_assault = nil
	if managers and managers.dialog then
		managers.dialog._comment_on_finished = {
			respond_to_ids = {
				Play_ban_b12 = true,
				Play_ban_b11 = true,
				Play_ban_b10 = true,
				Play_loc_b12 = true,
				Play_loc_b11 = true,
				Play_loc_b10 = true,
			},
			comment = "p24",
			delay = 0.5
		}
	end
end