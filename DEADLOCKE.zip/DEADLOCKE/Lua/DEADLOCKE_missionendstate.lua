local _MissionEndState_play_finishing_sound = MissionEndState.play_finishing_sound
function MissionEndState:play_finishing_sound(success)
	_MissionEndState_play_finishing_sound(self, success)
	if self._server_left then
		return
	end

	if success and managers.groupai:state():bain_state()  then
		local job_chain = managers.job:current_job_chain_data() 
		if not job_chain or #job_chain <= 0 then
			return
		end
		local level_id = DeadLocke:level_id()
		if job_chain[#job_chain] and job_chain[#job_chain].level_id == level_id then
			local level_data = level_id and tweak_data.levels[level_id]
			if level_data and not level_data.outro_event then
				managers.dialog:queue_narrator_dialog("g02x", {})
			end
		end
	end
end