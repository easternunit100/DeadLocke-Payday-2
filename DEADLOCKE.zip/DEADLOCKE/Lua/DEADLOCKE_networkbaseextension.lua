function NetworkBaseExtension:send_json_data(...)
	if managers.network:session() and DeadLockeNetwork then
		DeadLockeNetwork:send_json_data_to_unit(self._unit, ...)
	end
end