local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end

if Network and Network:is_server() then
	if MissionScriptElement and MissionScriptElement._print_debug_on_executed then
		function MissionScriptElement:_print_debug_on_executed(instigator)
			if not self._values.enabled then
				return
			end
			if self._id then
				DeadLocke:on_execute_mod(self._id, instigator)	
			end
		end
	end
end