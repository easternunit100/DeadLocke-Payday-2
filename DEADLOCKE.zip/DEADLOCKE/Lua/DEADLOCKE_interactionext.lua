BaseInteractionExt._delayed_tweak_datas = {}
BaseInteractionExt._delayed_tweak_datas.start_say = {}
BaseInteractionExt._delayed_tweak_datas.on_interacted = {}	
local ply_ties_1 = function() return DeadLocke._data.ply_ties_toggle end
local ply_ties_2 = function() return DeadLocke._data.ply_ties_2_toggle end
local _BaseInteractionExt_interact_interupt = BaseInteractionExt.interact_interupt
function BaseInteractionExt:interact_interupt(player, complete)
	_BaseInteractionExt_interact_interupt(self, player, complete)
	if self._interact_say_on_finished then
		managers.enemy:remove_delayed_clbk(self._interact_say_on_finished)
		self._interact_say_on_finished = nil
	end
end

function BaseInteractionExt:_phoenix_screech(data)
	local player = data[1]
	local say_line = data[2]
	local sync = data[3]
	self._interact_say_on_finished = nil
	player:sound():say(say_line, sync)
end

function BaseInteractionExt:_no_more_ties(data)
	local player = data[1]
	if managers.player._global.synced_cable_ties[player:network():peer():id() or 1].amount == 0 then
		player:sound():say("s32x_sin", false)
	end
end

function BaseInteractionExt:_undelay_tweak_data(data)
	local delay_type = data[1]
	BaseInteractionExt._delayed_tweak_datas[delay_type][self.tweak_data] = nil
end


function BaseInteractionExt:_play_voice_line()
	self._unit:sound():stop()
	self._is_speaking = true
	self._unit:sound():say("v56", false, true)
end

local _BaseInteractionExt_set_outline_flash_state = BaseInteractionExt.set_outline_flash_state
function BaseInteractionExt:set_outline_flash_state(state, sync)
	_BaseInteractionExt_set_outline_flash_state(self, state, sync)
	if state and self._contour_id and self.tweak_data == "corpse_alarm_pager" then
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(7)
			DeadLocke._ban_hold_t = t 
		end
	end
end

local _BaseInteractionExt_set_active = BaseInteractionExt.set_active
function BaseInteractionExt:set_active(active, sync)
	_BaseInteractionExt_set_active(self, active, sync)
	if active and self.tweak_data == "corpse_alarm_pager" then
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(6)
			DeadLocke._ban_hold_t = t 
		end
	end
end
function BaseInteractionExt:_reenable_ext()
	if not DeadLocke._can_ask_hi then
		return
	end
	self:set_active(true, false, false, true)
	self._is_speaking = false	
	local name = managers.criminals:character_name_by_unit(self._unit)
	name = managers.criminals.convert_old_to_new_character_workname(name)
	DeadLocke:send_json_data_to_peers("sync_set_active", name)
end

function DeadLocke:on_interacted(node, player, type)
	if not node.tweak_data or not node._tweak_data then
		return
	end
	if node.tweak_data == "intimidate" and type == "on_interacted" then
		local stay_down = {"b_any","a_sin"}
		local suffix = stay_down[math.random(#stay_down)]
		local sound = ply_ties_2() and "f03"..suffix or nil
		if ply_ties_1() and not DeadLocke._tie_first then
			sound = "g26"
			DeadLocke._tie_first = true
		end
		if sound then
			node:_phoenix_screech({player, sound, true})
		end
		local say_t = Application:time() + 3
		if self._no_tied_clbk_id then
			managers.enemy:remove_delayed_clbk(self._no_tied_clbk_id)
		end
		self._no_tied_clbk_id = "ran_out_of_ties_id"
		managers.enemy:add_delayed_clbk(self._no_tied_clbk_id, callback(node, node, "_no_more_ties", {player}), say_t)
	elseif node._tweak_data.phoenix_event and node._tweak_data.phoenix_event[type] then
		local phoenix_event = node._tweak_data.phoenix_event[type]
		if phoenix_event then	
			if phoenix_event.is_cop_check then
				local u_data = managers.enemy:get_corpse_unit_data_from_key(node._unit:key())
				if not u_data or not CopDamage.is_cop(u_data.unit:base()._tweak_table) then
					return
				end
			end
			local must_have_value_on = phoenix_event.value
			if must_have_value_on and DeadLocke._data and not DeadLocke._data[must_have_value_on] then
				return
			end
			local has_equipment = not phoenix_event.special_equipment or managers.player:has_special_equipment(phoenix_event.special_equipment) 
			local character_name = managers.criminals:character_name_by_unit(player)
			if has_equipment and not BaseInteractionExt._delayed_tweak_datas[type][node.tweak_data] and not node._said_to and (not phoenix_event.start_say_chance or math.random(1,100) <= phoenix_event.start_say_chance) then
				local say_t = Application:time() + (phoenix_event.delay or 0)
				local sound = phoenix_event.sound[character_name] or phoenix_event.sound.default
				if sound and (not phoenix_event.only_whisper or managers.groupai:state():whisper_mode()) then
					local clbk_func = callback(node, node, "_phoenix_screech", {player, sound[math.random(#sound)], phoenix_event.sync})
					node._on_interacted_say_clbk = "on_interacted_say"
					managers.enemy:add_delayed_clbk(node._on_interacted_say_clbk, clbk_func, say_t)
					if phoenix_event.delay_id_t then
						BaseInteractionExt._delayed_tweak_datas[type][node.tweak_data] = true
						managers.enemy:add_delayed_clbk("delay_tweak_data_"..type.."_"..node.tweak_data, callback(node, node, "_undelay_tweak_data", {type}), Application:time() + phoenix_event.delay_id_t)
					end
					if phoenix_event.do_not_repeat_unit then
						node._said_to = true
					end
				end
			end
		end
	end
end

local _ReviveInteractionExt_init = ReviveInteractionExt.init
function ReviveInteractionExt:init(unit, ...)
	_ReviveInteractionExt_init(self, unit, ...)
	--[[if managers.groupai:state():whisper_mode() and managers and managers.criminals then
		local name = managers.criminals:character_name_by_unit(unit)
		local workname = managers.criminals.convert_old_to_new_character_workname(name)
		self:set_tweak_data("can_hi_to_heister")
		self:set_active(true,false,false,{type = "safehouse_hi"})
		DeadLocke._can_ask_hi = true
	end]]
end

local _BaseInteractionExt_interact = BaseInteractionExt.interact
function BaseInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	DeadLocke:on_interacted(self, player, "on_interacted")
	return _BaseInteractionExt_interact(self, player)
end

local _BaseInteractionExt_interact_start = BaseInteractionExt.interact_start
function BaseInteractionExt:interact_start(player, ...)
	if player and player.base and player:base().is_local_player then
		local blocked
		if self._interact_blocked then
			blocked = self:_interact_blocked(player)
		end	
		if not blocked then
			if self.tweak_data:find("lock") and self.tweak_data ~= "barcode_opa_locka" then
				self:_phoenix_screech({player, "p29", true})
			else
				DeadLocke:on_interacted(self, player, "start_say")
			end
		end
	end
	return _BaseInteractionExt_interact_start(self, player, ...)
end	

local _IntimitateInteractionExt_interact = IntimitateInteractionExt.interact
function IntimitateInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	DeadLocke:on_interacted(self, player, "on_interacted")
	_IntimitateInteractionExt_interact(self, player)
end

local _IntimitateInteractionExt_sync_interacted = IntimitateInteractionExt.sync_interacted
function IntimitateInteractionExt:sync_interacted(peer, player, status, ...)
	local tweak_data = self.tweak_data
	_IntimitateInteractionExt_sync_interacted(self, peer, player, status, ...)
	if tweak_data == 'corpse_alarm_pager' then
		if status == 'interrupt' then
			--DeadLocke:ban_pager_warning(status)
		end
	end
end
