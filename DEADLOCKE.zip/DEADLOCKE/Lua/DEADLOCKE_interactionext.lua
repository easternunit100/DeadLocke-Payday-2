BaseInteractionExt._delayed_tweak_datas = {}
BaseInteractionExt._delayed_tweak_datas.start_say = {}
BaseInteractionExt._delayed_tweak_datas.on_interacted = {}	
local ply_ties_1 = function() return DeadLocke._data.ply_ties_toggle end
local ply_ties_2 = function() return DeadLocke._data.ply_ties_2_toggle end
local _BaseInteractionExt_interact_interupt = BaseInteractionExt.interact_interupt
function BaseInteractionExt:interact_interupt(player, complete)
	_BaseInteractionExt_interact_interupt(self, player, complete)
	if self._interact_say_on_finished then
		managers.enemy:remove_delayed_clbk(self._interact_say_on_finished)
		self._interact_say_on_finished = nil
	end
end

function BaseInteractionExt:_phoenix_screech(data)
	local player = data[1]
	local say_line = data[2]
	local sync = data[3]
	self._interact_say_on_finished = nil
	player:sound():say(say_line, sync)
end

function BaseInteractionExt:_no_more_ties(data)
	local player = data[1]
	if managers.player._global.synced_cable_ties[player:network():peer():id() or 1].amount == 0 then
		player:sound():say("s32x_sin", false)
	end
	self._no_tied_clbk_id = nil
end

function BaseInteractionExt:_undelay_tweak_data(data)
	local delay_type = data[1]
	BaseInteractionExt._delayed_tweak_datas[delay_type][self.tweak_data] = nil
end


function BaseInteractionExt:_play_voice_line()
	self._unit:sound():stop()
	self._is_speaking = true
	self._unit:sound():say("v56", false, true)
end

local _BaseInteractionExt_set_outline_flash_state = BaseInteractionExt.set_outline_flash_state
function BaseInteractionExt:set_outline_flash_state(state, sync)
	_BaseInteractionExt_set_outline_flash_state(self, state, sync)
	if state and self._contour_id and self.tweak_data == "corpse_alarm_pager" then
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(7)
			DeadLocke._ban_hold_t = t 
		end
	end
end

local _BaseInteractionExt_set_active = BaseInteractionExt.set_active
function BaseInteractionExt:set_active(active, sync)
	_BaseInteractionExt_set_active(self, active, sync)
	if active and self.tweak_data == "corpse_alarm_pager" then
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(6)
			DeadLocke._ban_hold_t = t 
		end
	end
end
function BaseInteractionExt:_reenable_ext()
	if not DeadLocke._can_ask_hi then
		return
	end
	self:set_active(true, false, false, true)
	self._is_speaking = false	
	local name = managers.criminals:character_name_by_unit(self._unit)
	name = managers.criminals.convert_old_to_new_character_workname(name)
	DeadLocke:send_json_data_to_peers("sync_set_active", name)
end

local _ReviveInteractionExt_init = ReviveInteractionExt.init
function ReviveInteractionExt:init(unit, ...)
	_ReviveInteractionExt_init(self, unit, ...)
	--[[if managers.groupai:state():whisper_mode() and managers and managers.criminals then
		local name = managers.criminals:character_name_by_unit(unit)
		local workname = managers.criminals.convert_old_to_new_character_workname(name)
		self:set_tweak_data("can_hi_to_heister")
		self:set_active(true,false,false,{type = "safehouse_hi"})
		DeadLocke._can_ask_hi = true
	end]]
end

local _BaseInteractionExt_interact = BaseInteractionExt.interact
function BaseInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	DeadLocke:on_interacted(self, player, "on_interacted")
	return _BaseInteractionExt_interact(self, player)
end

local _BaseInteractionExt_interact_start = BaseInteractionExt.interact_start
function BaseInteractionExt:interact_start(player, ...)
	if player and player.base and player:base().is_local_player then
		local blocked
		if self._interact_blocked then
			blocked = self:_interact_blocked(player)
		end	
		if not blocked then
			if self.tweak_data:find("lock") and self.tweak_data ~= "barcode_opa_locka" then
				self:_phoenix_screech({player, "p29", true})
			else
				DeadLocke:on_interacted(self, player, "start_say")
			end
		end
	end
	return _BaseInteractionExt_interact_start(self, player, ...)
end	

local _IntimitateInteractionExt_interact = IntimitateInteractionExt.interact
function IntimitateInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	DeadLocke:on_interacted(self, player, "on_interacted")
	_IntimitateInteractionExt_interact(self, player)
end

local _IntimitateInteractionExt_sync_interacted = IntimitateInteractionExt.sync_interacted
function IntimitateInteractionExt:sync_interacted(peer, player, status, ...)
	local tweak_data = self.tweak_data
	_IntimitateInteractionExt_sync_interacted(self, peer, player, status, ...)
	if tweak_data == 'corpse_alarm_pager' then
		if status == 'interrupt' then
			--DeadLocke:ban_pager_warning(status)
		end
	end
end
