local old_use_trip_mine = PlayerEquipment.use_trip_mine
function PlayerEquipment:use_trip_mine()
	local used_trip_mine = old_use_trip_mine(self)
	local peer_id = managers.network:session():local_peer():id()
	if used_trip_mine and managers.player._global.synced_deployables[peer_id].deployable == "trip_mine" and managers.player._global.synced_deployables[peer_id].amount == 1 then
		DelayedCalls:Add("check_mines_count", 4, function()
			local unit = managers.player:local_player()
			if unit and alive(unit) then
				unit:sound():say( "s40x_sin", false, false )
			end
		end)
	end
	return used_trip_mine
end