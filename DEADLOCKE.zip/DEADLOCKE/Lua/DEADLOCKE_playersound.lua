function PlayerSound:my_directory()
	return self._sound_directory
end

function PlayerSound:_sound_playback(sound_name)
	local static_data = managers.criminals:character_static_data_by_unit(self._unit)
	if not static_data then
		return nil
	end
	
	local voice = static_data.voice
	local playback = DeadLocke:_get_heister_sound_playback_from_id(sound_name, voice)
	return playback
end

function PlayerSound:playback_playing()	
	return self._playback and self._playback:playing()
end	

function PlayerSound:say_mod(sound_name, sync)	
	local playback = self:_sound_playback(sound_name)
	if playback and not playback:playing() then
		self._playback = playback
		self._playback:play({type = "playersound", unit = self._unit})
	end
end	

function PlayerSound:speaking_mod()
	return self._vm and self._vm:active()
end

function PlayerSound:play_ogg_line(id, sync)
	self:say_mod(id, sync)
end

local _PlayerSound_say = PlayerSound.say
function PlayerSound:say(sound_name, sync, ...)
	local char_name = managers.criminals:character_name_by_unit(self._unit)
	local force_switch
	local static_data = managers.criminals:character_static_data_by_unit(self._unit)
	if static_data and static_data.voice then
		if sound_name == "Play_"..static_data.voice.."_idle" or sound_name == "Play_"..static_data.voice.."_answering" then
			force_switch = true
		end
	end
	if force_switch or self._unit.base and self._unit:base() and self._unit:base().is_local_player then 
		self._unit:sound_source():set_switch("int_ext", force_switch and "third" or DeadLocke:is_third_person_sound(sound_name))
	end
	if char_name == "old_hoxton" and DeadLocke:pdth_leftover_id(sound_name) then
		self:set_voice( "rb2" )
	end
	local sound_name = DeadLocke:pdth_leftover_id(sound_name) or DeadLocke:alternatives(sound_name, char_name) or sound_name
	self._last_speech = _PlayerSound_say(self, sound_name, sync, ...)	
	if self._unit.base and self._unit:base() and self._unit:base().is_local_player then
		self._unit:sound_source():set_switch("int_ext", "third")
	end
	if char_name == "old_hoxton" and static_data and static_data.voice then
		self:set_voice(static_data.voice)
	end

	return self._last_speech
end