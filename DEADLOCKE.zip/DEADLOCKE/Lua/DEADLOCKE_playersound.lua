function PlayerSound:my_directory()
	return self._sound_directory
end
function PlayerSound:can_play_ogg(id)
	return self._bank[id] and true or false
end
function PlayerSound:say_mod(id, sync)
	if not self._bank or not self._bank[id] then
		return
	end
	local text = {}
	local times = 1
	self._last_data = self._last_data or {}
	while self._bank[id][times] do
		if not self._bank[id][times] then
			break
		end
		self._last_data[id] = self._last_data[id]  or {}
		self._last_data[id][times] = self._last_data[id][times] or {}
		local clone_chat_bank = {}
		for i,v in pairs(self._bank[id][times]) do
			if #self._bank[id][times] <= 1 or self._last_data[id][times].order ~= i and self._last_text ~= v then
				table.insert(clone_chat_bank, {text = v, order = i})
			end
		end
		local cht_data = clone_chat_bank[math.random(#clone_chat_bank)]
		self._last_data[id][times].order = cht_data.order
		if type(cht_data.text) == "string" then
			table.insert(text, {cht_data.text, nil})
		end
		times = times + 1
	end
	self._last_text = text
	for index, txt_data in pairs(text) do
		local _text = txt_data[1]
		self._vm_buffer = XAudio.Buffer:new(_text)
		self._vm = XAudio.VoicelineManager:new(self._unit, self._vm_buffer)
		self._vm:play(self._vm_buffer, sound_name)
		self._vm:update()
		for channel, src in pairs(self._vm._sources) do
			if self._vm._sources[channel] then
				self._vm._sources[channel]._gain = 2 --- Ok come on really  0 - 1? It's still so low..
			end
		end
		self._vm_buffer:close()
		self._vm = nil
	end	
	if sync then
		local character = managers.criminals:character_name_by_unit(self._unit)
		if character then
			DeadLockeNetwork:send_json_data_to_peers("sync_play_ogg_line", id, character)	
		end
	end
end	
function PlayerSound:play_ogg_line(id, sync)
	self:say_mod(id, sync)
end
local _PlayerSound_say = PlayerSound.say
function PlayerSound:say(sound_name, sync, ...)
	local char_name = managers.criminals:character_name_by_unit(self._unit)
	local force_switch
	local static_data = managers.criminals:character_static_data_by_unit(self._unit)
	if static_data and static_data.voice then
		if sound_name == "Play_"..static_data.voice.."_idle" or sound_name == "Play_"..static_data.voice.."_answering" then
			force_switch = true
		end
	end
	if force_switch or self._unit.base and self._unit:base() and self._unit:base().is_local_player then 
		self._unit:sound_source():set_switch("int_ext", force_switch and "third" or DeadLocke:is_third_person_sound(sound_name))
	end
	if char_name == "old_hoxton" and DeadLocke:pdth_leftover_id(sound_name) then
		self:set_voice( "rb2" )
	end
	local sound_name = DeadLocke:pdth_leftover_id(sound_name) or DeadLocke:alternatives(sound_name, char_name) or sound_name
	self._last_speech = _PlayerSound_say(self, sound_name, sync, ...)	
	if self._unit.base and self._unit:base() and self._unit:base().is_local_player then
		self._unit:sound_source():set_switch("int_ext", "third")
	end
	if char_name == "old_hoxton" and static_data and static_data.voice then
		self:set_voice(static_data.voice)
	end

	return self._last_speech
end
function PlayerSound:set_interactor_voice(interactor_voice)
	CivilianHeisterSound.set_interactor_voice(self, interactor_voice)
end

--- Go to the "sounds" file and "rb4" or "rb5" or "rb3" and literally drop a freaking ogg file and the game will play it. 
--- Hey person who's reading this! Try it out for yourself and the game will play your damn ogg file :)
function PlayerSound:get_custom_clips(voice)
	if XAudio then
		if blt and blt.xaudio then	
			blt.xaudio.setup()	
			if not self._bank then
				self._bank = {}
				if file then
					if file and file.DirectoryExists and file.GetDirectories and file.GetFiles then
						local directory = string.format(tostring(DeadLocke._path).."sounds/robbers/%s", tostring(voice))
						if directory and file.DirectoryExists(directory) then
							local folders = file.GetDirectories(directory)
							if folders and type(folders) == "table" then
								for i,dir in pairs(folders) do
									if dir then
										local _dir = tostring(dir)
										self._bank[_dir] = {}
										local bank
										local sound_directory = directory.."/".._dir
										local audio_files = file.GetFiles(sound_directory)
										if audio_files and type(audio_files) == "table" then
											bank = {}
											for _, audio_id in pairs(audio_files) do
												if audio_id then
													local audio_string = tostring(audio_id)
													if audio_string then
														table.insert(bank, sound_directory.."/"..audio_string)
													end
												end
											end
										end
										if bank then
											table.insert(self._bank[_dir], bank)
										end
									end
								end
							end	
						end
					end
				end
				if self._bank and next(self._bank) then
					--log("Added custom clips to voice "..tostring(voice))
				end
			end
		end
	end
end


local _PlayerSound_set_voice = PlayerSound.set_voice
function PlayerSound:set_voice(voice)
	_PlayerSound_set_voice(self, voice)
	self:get_custom_clips(voice)
end