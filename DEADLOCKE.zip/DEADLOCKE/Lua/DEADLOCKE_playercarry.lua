local PlayerCarry_old = PlayerCarry.enter
function PlayerCarry:enter(state_data, enter_data)
	PlayerCarry_old(self, state_data, enter_data)
	local vr_character = managers.criminals:local_character_name()
	local current_map = managers.job:current_level_id()
	if managers.player:get_my_carry_data() then
		local carry_data = managers.player:get_my_carry_data()
		if carry_data.carry_id == "lance_bag" then
			local say =  { 'g61', 'g92', 'g13', 'null' }
			if vr_character == 'female_1' then
				say = { 'g29', 's05x_sin', 'g13', 'null' }
			elseif vr_character == 'jowi' then
				say = { 'g13', 'g14', 'null' }
			elseif vr_character == 'dragan' then
				say = { 'g92', 'g13', 's05x_sin', 'null' }
			end
			self._unit:sound():say(say[math.random(#say)], true)
		end
	end		
end