local Helpcall_old = PlayerBleedOut.enter
function PlayerBleedOut:enter(...)
	Helpcall_old(self, ...)
	PlayerStandard.say_line(self, "f11e_plu")
end

local _PlayerBleedOut_enter = PlayerBleedOut.enter
function PlayerBleedOut:enter(...)
	_PlayerBleedOut_enter(self, ...)
	DeadLocke:update_downs_counter(self._unit, false)
end