SecurityCamera.destroyed_cameras = {}
local _SecurityCamera_generate_cooldown = SecurityCamera.generate_cooldown
function SecurityCamera:generate_cooldown(amount)
	_SecurityCamera_generate_cooldown(self, amount)
	table.insert(SecurityCamera.destroyed_cameras, self._unit)
	if Network and Network:is_server() and managers.groupai:state():whisper_mode() then
		local total = #SecurityCamera.cameras
		local destroyed = #SecurityCamera.destroyed_cameras
		if total == destroyed then		
			---Fantastic, you destroyed each and every camera in the entire area really nice done
		elseif total / 2 == destroyed then		
			---That's half of the cameras keep at it.
		end
	end
end