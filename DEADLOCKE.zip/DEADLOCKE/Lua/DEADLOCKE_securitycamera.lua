local _SecurityCamera_generate_cooldown = SecurityCamera.generate_cooldown
function SecurityCamera:generate_cooldown(amount)
	_SecurityCamera_generate_cooldown(self, amount)
	local total = 0
	local destroyed = 0
	if managers.groupai:state():whisper_mode() then
		for _, unit in ipairs(SecurityCamera.cameras) do
			if alive(unit) and unit:enabled() then
				total = total + 1
				if unit:base():destroyed() then
					destroyed = destroyed + 1
				end
			end
		end
	end
	if total / 2 == destroyed then		
	end
end