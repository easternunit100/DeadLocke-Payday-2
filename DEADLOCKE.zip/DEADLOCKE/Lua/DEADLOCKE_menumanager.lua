-- ALL THIS WAS NEVER POSSIBLE WITHOUT KAIL
_G.DeadLocke = _G.DeadLocke or {}
DeadLocke.debug = false
DeadLocke._path = ModPath
DeadLocke._data_path = SavePath .. "phoenix_data.txt"
DeadLocke._data = {}
DeadLocke._intro_mail_loc = "can_ban_news_upt_intro"
DeadLocke._outro_mail_loc = "can_ban_news_upt_outro1"
DeadLocke._mail_end_loc = "can_ban_news_upt_end"
DeadLocke._drill_remind_id = "dlocke_drill_reminder_id"
DeadLocke._on_hostage_trade_clbk_id = "dlocke_trade_reminder"
DeadLocke._other_deployable_bag_units = {}
DeadLocke._down_counters = {}
DeadLocke._investigation_areas = {}
DeadLocke._jammed_devices = {}
DeadLocke._peer_ids = {}
DeadLocke._incharge = false
DeadLocke._incharge_peer_id = false
DeadLocke._combat_chatter_allow = false
DeadLocke._combat_chatter_min_chance = 0.8
DeadLocke._combat_chatter_max_chance = 1
DeadLocke._combat_chatter_chance = DeadLocke._combat_chatter_min_chance
DeadLocke._last_speaker = nil
DeadLocke._num_of_jammed_drills = 0
DeadLocke._jammed_drills = {}
DeadLocke._saved_elements = {}
DeadLocke._warcried = false
DeadLocke._last_unit_commenter = false
DeadLocke._can_ask_hi = false
DeadLocke._flash_counter = 0
DeadLocke._b4_Canary = false
DeadLocke._message_id = 1
DeadLocke._cop_comment_cooldown_t = {}
DeadLocke._loot_required = {}
DeadLocke._enemy_access = {
	fbi = true,
	swat = true
}


DeadLocke._MenuCallbackHandlers = {
	{
		clbk_id = "callback_ban_global",
		value_id = "ban_global"
	},
	{
		clbk_id = "callback_bain_tog",
		value_id = "ban_toggle"
	},
	{
		clbk_id = "callback_bain_ponr_tog",
		value_id = "ban_ponr_toggle"
	},
	{
		clbk_id = "callback_bain_pag_tog",
		value_id = "ban_pag_toggle"
	},
	{
		clbk_id = "callback_ply_assault_tog",
		value_id = "ply_assault_toggle"
	},
	{
		clbk_id = "callback_ply_assault_ai_tog",
		value_id = "ply_assault_ai_toggle"
	},
	{
		clbk_id = "callback_ply_call_tog",
		value_id = "ply_call_toggle"
	},
	{
		clbk_id = "callback_ply_knees_tog",
		value_id = "ply_knees_toggle"
	},
	{
		clbk_id = "callback_ply_spot_tog",
		value_id = "ply_spot_toggle"
	},
	{
		clbk_id = "callback_ply_spot_dozer_tog",
		value_id = "ply_spot_dozer_toggle"
	},
	{
		clbk_id = "callback_ply_cams_tog",
		value_id = "ply_cams_toggle"
	},
	{
		clbk_id = "callback_ply_ties_tog",
		value_id = "ply_ties_toggle"
	},
	{
		clbk_id = "callback_ply_ties_2_tog",
		value_id = "ply_ties_2_toggle"
	},
	{
		clbk_id = "callback_ply_detect_tog",
		value_id = "ply_detect_toggle"
	},
	{
		clbk_id = "callback_ply_spot_medic_tog",
		value_id = "ply_spot_medic_toggle"
	},
	{
		clbk_id = "callback_ply_inspire_tog",
		value_id = "ply_inspire_toggle"
	},
	{
		clbk_id = "callback_ply_turret_mark_toggle",
		value_id = "ply_turret_mark_toggle"
	},
	{
		clbk_id = "callback_music_event_toggle",
		value_id = "music_event_toggle"
	},
	{
		clbk_id = "callback_ban_special_comment",
		value_id = "ban_special_comment"
	},
	{
		clbk_id = "callback_ply_defend_call_tog",
		value_id = "ply_defend_call_toggle"
	},
	{
		clbk_id = "clbk_vehicle_comment",
		value_id = "can_vehicle"
	},
	{
		clbk_id = "callback_ban_h_success_toggle",
		value_id = "ply_ban_success"
	},
	{
		clbk_id = "clbk_wacry_chttr_request",
		value_id = "wacry_chttr_request"
	},
	{
		clbk_id = "clbk_can_hostage_convert",
		value_id = "can_hostage_convert"
	},
}
DeadLocke._suspense_phases = 5
DeadLocke._ban_warns = {
	tank = "s02_a",
	taser = "s01_a",
	sheild = "s03_a"
}
DeadLocke._message_events = {
	{
		sound = "g80x_any",
		receive_id = "can_message_id_request_1",
		send_id = "can_message_id_send_1"
	},
	{
		sound = "g80x_any",
		receive_id = "can_message_id_request_2",
		send_id = "can_message_id_send_2"
	},
	{
		sound = "g81x_any",
		receive_id = "can_message_id_request_3",
		send_id = "can_message_id_send_3"
	},
	{
		sound = "g81x_any",
		receive_id = "can_message_id_request_4",
		send_id = "can_message_id_send_4"
	}
}
DeadLocke.pdth_leftovers = {
	"dia_23",
	"dia_71",
	"fwb_54",
	"fwb_60",
	"fwb_67",
	"slh_26",
	"slh_37",
	"slh_55",
	"str_03",
}
DeadLocke._gameplay_tips = {
	stealth = {
		"cam_lure",
		"murky",
		"ecm",
		"sprint",
		"baggingcorpse",
		"pagermax"
	},
	loud = {
		"inspire",
		"baninfo",
		"aicarry",
		"teammatelastdown",
		"playerslastdowninfo",
		"playerlastdown"
	},
	upgrades = {
		"drill"
	}
}
DeadLocke._alternatives = {
	g93 = {
		default = {"f42_any"},
		chars = {
			rust = {"g29"},
			sydney = {"g29"},
			chico = {"g29"}
		}
	}
}
DeadLocke.old_to_modern_pd_sound_names = {
	["hos_b_apa_25"]	= "v32",
	["hos_b_apa_10"]	= "v07",
	["hos_b_bri_17"]	= "v30",
	["hos_b_fwb_21"]	= "g68",
	["hos_b_bri_13"]	= "p04",
	["hos_b_slh_34"]	= "v03",
	["hos_b_dia_43"]	= "v41",
	--["hos_b_bri_06"]	= "Saw in place",
	["hos_b_slh_20"]	= "v20",
	--["hos_b_dia_56"]	= "Oh dirty business ain't it",
	--["hos_b_str_37"]	= "Finally",
	["hos_b_dia_13"]	= "v04",
	["hos_b_dia_71"]	= "v08",
	--["hos_b_bri_25"]	= "See you on the top bain",
	["hos_b_bri_16"]	= "v44",
	--["hos_b_apa_42"]	= "Check the stairs",
	--["hos_b_str_38"]	= "How long? This hospital is full of cops!",
	["hos_b_bri_37"]	= "v46",
	--["hos_b_slh_03"]	= "10 seconds. No fuck ups.",
	--["hos_b_slh_18"]	= "This is going to stall",
	["hos_b_slh_23"]	= "v52",
	["hos_b_fwb_61"]	= "v27",
	--["hos_b_str_39"]	= "We gotta wait a little longer",
	["hos_b_fwb_10"]	= "g92",
}
DeadLocke.third_person_ids = {
	"g90",
	"g50",
	"g51",
	"g70",
	"g40x_any",
	"f03a_sin",
	"f03a_plu",
	"s05a_sin",
	"s05b_sin",
	"s09a",
	"s09b",
	"s09c",
}
DeadLocke._suspense_music_phases = { -- These are the music events used for the tracks in Shadow Raid and Murky Station
	"suspense_1",
	"suspense_2",
	"suspense_3",
	"suspense_4",
	"suspense_5"
}
DeadLocke._alesso_music = {
	intro = "alesso_music_play",
	cut = "alesso_music_cut",
	stealth = "alesso_music_stealth",
	control = "alesso_music_control",
	drop = "alesso_music_drop",
	fade = "alesso_music_fade",
	assault = "alesso_music_assault",
	fake_assault = "alesso_music_assault",
	anticipation = "alesso_music_anticipation",
	standby = "alesso_music_hacking_standby",
	hacking = "alesso_music_hacking_progress",
	crowd_crazy = "crowd_crazy",
	crowd_heavy = "crowd_heavy",
	crowd_medium ="crowd_medium",
	crowd_single_ending = "crowd_single_ending"
}
DeadLocke.randomize = {
	"f02x_sin",
	"f02x_plu",
	"f11b_sin",
	"l01x_sin",
}
DeadLocke._silent_throwables = {
	wpn_prj_four = true,
	wpn_prj_ace = true
}
DeadLocke._carry_list = {
	"gold",
	"money",
	"diamonds",
	"coke",
	"coke_pure",
	"sandwich",
	"weapon",
	"painting",
	"circuit",
	"diamonds",
	"meth",
	"lance_bag",
	"lance_bag_large",
	"grenades",
	"engine_01",
	"engine_02",
	"engine_03",
	"engine_04",
	"engine_05",
	"engine_06",
	"engine_07",
	"engine_08",
	"engine_09",
	"engine_10",
	"engine_11",
	"engine_12",
	"ammo",
	"cage_bag",
	"turret",
	"artifact_statue",
	"samurai_suit",
	"equipment_bag",
	"cro_loot1",
	"cro_loot2",
	"ladder_bag",
	"hope_diamond",
	"mus_artifact",
	"mus_artifact_paint",
	"winch_part",
	"winch_part_e3",
	"fireworks",
	"evidence_bag",
	"watertank_empty",
	"watertank_full",
	"warhead",
	"paper_roll",
	"counterfeit_money",
	"unknown",
	"safe_wpn",
	"safe_ovk",
	"nail_muriatic_acid",
	"nail_caustic_soda",
	"nail_hydrogen_chloride",
	"nail_euphadrine_pills",
	"safe_secure_dummy",
	"din_pig",
	"meth_half",
	"parachute",
	"equipment_bag_global_event",
	"prototype",
	"master_server",
	"lost_artifact",
	"breaching_charges",
	"masterpiece_painting",
	"drk_bomb_part",
	"goat",
	"present",
	"mad_master_server_value_1",
	"mad_master_server_value_2",
	"mad_master_server_value_3",
	"mad_master_server_value_4",
	"drk_bomb_part",
	"weapon_glock",
	"weapon_scar",
	"bike_part_light",
	"bike_part_heavy",
	"toothbrush",
	"drone_control_helmet",
	"chl_puck",
	"cloaker_gold",
	"cloaker_money",
	"cloaker_cocaine",
	"robot_toy",
	"ordinary_wine",
	"expensive_vine",
	"women_shoes",
	"vr_headset",
	"diamond_necklace",
	"yayo"
}

DeadLocke._syncable_values = {
	"ply_assault_toggle"
}

DeadLocke._syncable_event_ids = {}
for i_event, value_name in pairs(DeadLocke._syncable_values) do
	DeadLocke._syncable_event_ids[i_event] = value_name
end
function DeadLocke:safe_decode(data)
	local result
	pcall(function()
		result = json.decode(data)
	end)
	return result
end

function DeadLocke:load_json(file_path)
	local file = io.open( file_path, "r" )
	if file then
		local file_content = file:read("*all")
		file:close()
		return json.decode(file_content)
	end
end

function DeadLocke:GetDirectories(path)
	if file and file.GetDirectories then
		return file.GetDirectories( path )
	end
	return nil
end
function DeadLocke:GetFiles(dir)
	if file and file.GetFiles then
		return file.GetFiles( dir )
	end
	return nil
end

function DeadLocke:DirectoryExists(path)
	if file and file.DirectoryExists then
		return file.DirectoryExists( path )
	end
	return nil
end

DeadLocke._music_level_event_overrides_data = {
	run = {
		tracks = {"track_59"},
		event_overrides = {
			music_heist_setup = "music_heist_control"
		}		
	}
}

local Net = _G.LuaNetworking

--[[
	A simple save function that json encodes our _data table and saves it to a file.
]]
function DeadLocke:Save()
	local file = io.open( self._data_path, "w+" )
	if file then
		file:write( json.encode( self._data ) )
		file:close()
	end
end

--[[
	A simple load function that decodes the saved json _data table if it exists.
]]
function DeadLocke:Load()
	local file = io.open( self._data_path, "r" )
	if file then
		self._data = json.decode( file:read("*all") )
		file:close()
	end
end

function DeadLocke:level_id()
	return Global and Global.level_data and Global.level_data.level_id
end

function DeadLocke:_get_value_name_by_event_id(event_id)
	for index, name in pairs(self._syncable_values) do
		if index == event_id then
			return name
		end
	end
	return nil
end
function DeadLocke:_get_event_id_by_value_name(value_name)
	for index, name in pairs(self._syncable_values) do
		if value_name == name then
			return index
		end
	end
	return nil
end
function DeadLocke:is_current_track_on_list(track_list)
	if not track_list then
		return true
	end
	for i,v in pairs(track_list) do
		if v == Global.music_manager.current_track then
			return true
		end
	end
	return false
end

function DeadLocke:get_alesso_music_event(stage)
	local level_id = self:level_id()
	if level_id ~= "arena" then
		return nil
	end
	return self._alesso_music[stage]
end

function DeadLocke:get_overall_music_event(stage)
	return tweak_data.levels:get_music_event(stage) or self:get_alesso_music_event(stage)
end

function DeadLocke:get_drill_name(unit)
	local tweak_data = unit and unit.interaction and unit:interaction() and unit:interaction().tweak_data
	local drill_name = tweak_data and tweak_data:gsub('_jammed',''):gsub('_upgrade','')
	return drill_name
end

function DeadLocke:amount_of_saws()
	local amount = 0
	for d_key, d_data in pairs(self:all_active_drills()) do
		if d_data.is_saw then
			amount = amount + 1
		end
	end
	return amount
end




function DeadLocke:narrator()
	if managers.dialog and managers.dialog._narrator_prefix == "Play_loc_" then
		return "locke"
	end
	return "bain"
end


function DeadLocke:_normalize_combat_chatter_chance()
	self._combat_chatter_chance = self._combat_chatter_min_chance
end
function DeadLocke:_fuel_combat_chatter_chance(add_chance)
	self._combat_chatter_chance = self._combat_chatter_chance + add_chance
	if self._combat_chatter_chance > self._combat_chatter_max_chance then
		self._combat_chatter_chance = self._combat_chatter_max_chance
	end
end
function DeadLocke:_can_combat_chatter()
	return math.random(1) <= self._combat_chatter_chance
end
function DeadLocke:_narrator_prefix()
	return managers and managers.dialog and managers.dialog._narrator_prefix
end
function DeadLocke:my_peer()
	return managers and managers.network and managers.network.session and managers.network:session() and managers.network:session():local_peer()
end


function DeadLocke:all_active_drills()
	local units = World:find_units_quick("all")
	local drills = {}
	if units then
		for _, unit in pairs(units) do
			if unit and type(unit) == "userdata" and unit.base and unit:base() and unit:base()._jammed_count then
				if unit:timer_gui() and unit:timer_gui():is_visible() then
					local u_base = unit:base()
					drills[unit:key()] = {
						unit = unit,
						pos = unit:position(),
						_jammed_count = u_base._jammed_count,
						_jammed = u_base._jammed,
						is_drill = u_base.is_drill,
						is_saw = u_base.is_saw,
						is_hacking_device = u_base.is_hacking_device,
						is_lance = self:get_drill_name(unit) == "lance",
						is_huge_lance = self:get_drill_name(unit) == "huge_lance"
					}
				end
			end
		end
	end
	return drills
end
function DeadLocke:mission_script()
	return self._mission_script
end
function DeadLocke:mod_directory()
	return self._path
end
function DeadLocke:on_weapons_hot_music_stage(stage)
	self._weapons_hot_music_stage = stage	
end
function DeadLocke:on_weapons_hot_sound_device(enable)
	self._weapons_hot_sound_device = enable
end
function DeadLocke:on_enemy_weapons_hot_event()
	if DeadLockeMissionScriptElement and DeadLockeMissionScriptElement.on_weapons_hot_executed then
		DeadLockeMissionScriptElement:on_weapons_hot_executed()
	end
	if self._weapons_hot_music_stage  then
		if self._weapons_hot_music_stage  ~= "skip_music_event" then
			managers.music:post_event(self:get_overall_music_event(self._weapons_hot_music_stage ))
		end
		self.music_post_event_disabled = true
	end
	if not managers.groupai:state():get_assault_mode() and self._weapons_hot_sound_device then
		SoundDevice:set_state("wave_flag", "assault")
	end
end
function DeadLocke:_game_t()
	return TimerManager:game():time()
end
function DeadLocke:does_peer_exist(peer_id)
	for i, data in pairs(self._peer_ids) do
		if data.peer_id == peer_id then
			return true
		end
	end
	return false
end

function DeadLocke:add_peer(peer_id)
	local re_add = false
	for i, data in pairs(self._peer_ids) do
		if data.peer_id == peer_id then
			table.remove(self._peer_ids, i)
			re_add = true
			break
		end
	end
	local local_p_id = self:my_peer() and self:my_peer():id()
	local peer = managers.network:session():peer(peer_id)
	local is_local_peer = local_p_id == peer_id
	local add_peer = {
		peer_id = peer_id,
		is_local_peer = is_local_peer,
		peer_name = peer:name(),
		data = {}
	}
	table.insert(self._peer_ids, add_peer)
	if is_local_peer then
		self._local_peer_data = add_peer.data
		return
	end
	if re_add then
		log(string.format("[DeadLocke:add_peer] DeadLocke user %s re added to the list..", peer:name()))
	else	
		log(string.format("[DeadLocke:add_peer] DeadLocke user %s added to the list..", peer:name()))
	end
	if peer_id < local_p_id then
		if self._incharge then
			log("[DeadLocke:add_peer] you are not longer the host announcer..")
			self:incharge_speaker(false)
		end
	end
end

function DeadLocke:local_peer_data()
	return self._local_peer_data or {}
end

function DeadLocke:get_overrided_music_event(music_event)
	local level_id = self:level_id()
	if self._music_level_event_overrides_data[level_id] then
		local data = self._music_level_event_overrides_data[level_id]
		if not data.tracks or self:is_current_track_on_list(data.tracks) then
			if data.event_overrides and data.event_overrides[music_event] then
				return data.event_overrides[music_event]
			end
		end
	end
	return nil
end
function DeadLocke:remove_peer(peer_id, remove_type)
	for i, data in pairs(self._peer_ids) do
		if data.peer_id == peer_id then
			table.remove(self._peer_ids, i)
			local old_data = data
			self:on_peer_left_event(old_data, remove_type)
			return
		end
	end
end
function DeadLocke:get_peer_data_from_peer_id(peer_id)
	for i, data in pairs(self._peer_ids) do
		if data.peer_id == peer_id then
			return data.data
		end
	end
end
function DeadLocke:has_value_enabled(value, peer_id)
	peer_id = peer_id or managers.network:session():local_peer():id()
	local peer_data = self:get_peer_data_from_peer_id(peer_id)
	if not peer_data then
		return false
	end
	return peer_data[value]
end

function DeadLocke:send_my_values_to_sender(peer_id)
	for value_name, enabled in pairs(self._data) do
		if enabled and self:_get_event_id_by_value_name(value_name) then
			DeadLockeNetwork:send_json_data_to_peer(peer_id, "sync_enable_peer_data_value", value_name, true)
		end
	end
end
function DeadLocke:dlocke_data_string()
	local s = ""
	local first = true
	for value_id, enabled in pairs(self._data) do
		if enabled then
			if first then
				s = s..value_id
				first = false
			else
				s = s .. " " .. value_id
			end
		end
	end
	return s
end
function DeadLocke:get_my_dlocke_data()
	return self:dlocke_data_string()
end
function DeadLocke:apply_dlocke_options_to_peer(peer_id)
	local dlock_data_string = self:dlocke_data_string()
	local peer_dlocke_data = string.split(dlock_data_string or "", " ")
	for _, value_id in pairs(peer_dlocke_data or {}) do
		if self:_get_event_id_by_value_name(value_id) then
			self:enable_peer_data_value(value_id, true, peer_id)
		end
	end
end

function DeadLocke:enable_peer_data_value(value_id, enable, peer_id)
	peer_id = peer_id or self:my_peer() and self:my_peer():id()
	if not self:does_peer_exist(peer_id) then
		return
	end
	local peer_data = self:get_peer_data_from_peer_id(peer_id)
	enable = enable and true or false
	peer_data[value_id] = enable
	--log("[DeadLocke:enable_peer_data_value] value_id "..value_id.." for peer_id "..tostring(peer_id).." is now "..(enable and "enabled" or "disabled"))
end



function DeadLocke:set_values_to_peer_id_by_package(peer_id, can_package)
end
function DeadLocke:get_peer_data_from_unit(unit)
	if not unit then
		return nil
	end
	if not managers or not managers.criminals then
		return nil
	end
	local peer_id = managers.criminals:character_peer_id_by_unit(unit)
	return self:get_peer_data_from_peer_id(peer_id)
end
function DeadLocke:incharge()
	return self._incharge
end
function DeadLocke:incharge_speaker(enable)
	self._incharge = enable
end
function DeadLocke:on_peer_left_event(old_data, remove_type)
	if remove_type == "left" then
		log(string.format("[DeadLocke:on_peer_left_event] DeadLocke user %s has the left the game..", old_data.peer_name))
	elseif remove_type == "kicked" then
		log(string.format("[DeadLocke:on_peer_left_event] DeadLocke user %s has been kicked from the game..", old_data.peer_name))
	else
		log(string.format("[DeadLocke:on_peer_left_event] DeadLocke user %s disconnected from the game..", old_data.peer_name))
	end
	if old_data.peer_id == 1 then
		return
	end
	local enable = true
	local priority_peer_id, priority_peer_name
	for i, data in pairs(self._peer_ids) do
		if data and data.peer_id then
			if not priority_peer_id or data.peer_id > priority_peer_id then
				priority_peer_id = data.peer_id
				priority_peer_name = data.peer_name
			end
		end
	end
	enable = priority_peer_id == managers.network:session():local_peer():id()
	self:incharge_speaker(enable)
	if self._incharge then
		log("[DeadLocke:on_peer_left_event] You are now the host announcer..")
	else
		if priority_peer_name then
			log(string.format("[DeadLocke:on_peer_left_event] %s is now the host announcer..", priority_peer_name))
		else
			log("[DeadLocke:on_peer_left_event] a new host announcer assigned with an unknown name..")
		end
	end
end
function DeadLocke:pdth_leftover_id(sound_name)
	for i, v in pairs(self.pdth_leftovers) do
		if v == sound_name then
			return "Play_rbr_knk_jwl_b_"..sound_name
		end
	end
end
function DeadLocke:display_message(message)
	local t = TimerManager:game():time()
	if DeadLocke._display_message_delay and DeadLocke._display_message_delay + 3 < t then
		return
	end
	managers.hud:show_hint( { text = message } )
	DeadLocke._display_message_delay = t
end

function DeadLocke:is_tutorial_stage()
	local map = managers.job:current_level_id()
	return map == "short1_stage1" or map == "short1_stage2" or map == "short2_stage1" or map == "short2_stage2b"
end

function DeadLocke:can_criminal_say(sound_name, unit)
	local char_name = managers.criminals:character_name_by_unit(unit)
	if self.HEISTERS_COMMENT_NAMES[sound_name] then
		local sound_name_data = self.HEISTERS_COMMENT_NAMES[sound_name]
		for _, name in pairs(sound_name_data.characters) do
			if char_name == name then
				local can = sound_name_data.canners or false
				if can and sound_name_data.is_tutorial then
					can = unit:base().is_local_player and not self:is_tutorial_stage()
				end
				return can
			end
		end
		if sound_name_data and sound_name_data.canners then
			return false
		end
	end
	return true
end

DeadLocke.HEISTERS_COMMENT_NAMES = DeadLocke:load_json(DeadLocke._path.."data/HEISTERS_COMMENT_NAMES.json")
function DeadLocke:criminal_comment(trigger_unit, allow_first_person, message, pos, pos_based, radius, play_ogg_line, sync)
	if not managers or not managers.groupai or not managers.groupai.state then
		return
	end
	if not message then
		return
	end
	local gstate = managers.groupai:state()
	local close_unit, close_unit_d, trigger_unit_name
	if radius and type(radius) == "string" then
		radius = tonumber(radius) or nil
	end
	if pos and type(pos) == "string" then
		pos = self:String_to_Vector(pos)
	end
	if trigger_unit and type(trigger_unit) == "string" then
		trigger_unit = managers.criminals:character_unit_by_name(trigger_unit)
	end
	if radius and radius <= 0 then
		radius = nil
	end
	local function can_say(unit)
		return play_ogg_line and unit:sound()._bank and unit:sound()._bank[message] or not play_ogg_line and self:can_criminal_say(message, unit)
	end
	local close_pos = (pos_based and pos) and pos or managers.player:player_unit() and managers.player:player_unit():position() or game_state_machine:current_state() and game_state_machine:current_state()._camera_object or Vector3()
	if trigger_unit and alive(trigger_unit) then
		if can_say(trigger_unit) then
			close_unit = trigger_unit
			trigger_unit_name = managers.criminals:character_name_by_unit(trigger_unit)
			radius = nil
		end
	else
		for u_key, u_data in pairs(gstate._criminals) do
			if u_data and not u_data.is_deployable and u_data.unit and alive(u_data.unit) and (allow_first_person or not u_data.unit:base().is_local_player) and not u_data.unit:movement():downed() and not u_data.unit:sound():speaking() then
				if can_say(u_data.unit) then
					local close_dis = mvector3.distance_sq(close_pos, u_data.m_pos)
					if (not radius or close_dis < radius * radius) and (not close_unit_d or close_dis < close_unit_d) then
						close_unit = u_data.unit
						close_unit_d = close_dis
					end
				end
			end
		end
	end
	if close_unit then
		if play_ogg_line then
			close_unit:sound():play_ogg_line(message, false, true)
		else
			close_unit:sound():say(message, false)
		end
	end
	if sync then
		DeadLockeNetwork:send_json_data_to_peers("sync_criminal_comment", trigger_unit_name or false, allow_first_person or false, message, pos and tostring(pos) or false, pos_based or false, radius or 0, play_ogg_line or false)
	end
end
function DeadLocke:on_execute_mod(id, instigator)
	if not DeadLockeMissionScriptElement then
		return
	end
	local element = DeadLockeMissionScriptElement:get_mission_element(id)
	if element then
		element:on_executed(instigator)
	end
end
function DeadLocke:start_inform_ene_cooldown(cooldown_t, msg_type)
	local t = self:_game_t()
	self._cop_comment_cooldown_t[msg_type] = self._cop_comment_cooldown_t[msg_type] or {}
	local ene_cooldown = self._cop_comment_cooldown_t[msg_type]
	ene_cooldown._cooldown_t = cooldown_t + t
	self._cooldown_delay_t = t + 5
end

function DeadLocke:ene_inform_has_cooldown_met(msg_type)
	local t = TimerManager:game():time()
	if not self._cop_comment_cooldown_t[msg_type] then
		return true
	end
	local ene_cooldown = self._cop_comment_cooldown_t[msg_type]
	if self._cooldown_delay_t and self._cooldown_delay_t < t then
		return false
	end
	return not ene_cooldown._cooldown_t or ene_cooldown._cooldown_t < t
end

function DeadLocke:_has_deployable(unit)
	local peer_id = managers.criminals:character_peer_id_by_unit(unit)
	if not peer_id or peer_id == 0 then
		return false
	end
	local player_glob = managers.player._global
	if not player_glob or not player_glob.synced_deployables then
		return false
	end
	local synced_deployables = player_glob.synced_deployables
	return synced_deployables[peer_id] and synced_deployables[peer_id].amount and synced_deployables[peer_id].amount > 0 and synced_deployables[peer_id]
end

function DeadLocke:_has_deployable_type(unit, deployable)
	if not self:_has_deployable(unit) then
		return
	end
	local deployables = self:_has_deployable(unit)
	return deployables.deployable == deployable
end

function DeadLocke:_next_to_cops(data)
	local close_peers = {}
	local range = 5000
	for u_key, u_data in pairs(managers.enemy:all_enemies()) do
		if data.key ~= u_key then
			if u_data.unit and alive(u_data.unit) and not u_data.unit:character_damage():dead() then
				local anim_data = u_data.unit:anim_data()
				if not anim_data.surrender and not anim_data.hands_tied and not anim_data.hands_back then
					if mvector3.distance_sq(data.m_pos, u_data.m_pos) < range * range then
						table.insert(close_peers, u_data.unit)
					end
				end
			end
		end
	end
	return close_peers
end

function DeadLocke:inform_law_enforcements(data)
	if not managers.groupai:state()._special_unit_types[data.unit:base()._tweak_table] then
		return
	end
	if data.unit:in_slot(16) or not data.char_tweak.chatter.aggressive then
		return
	end
	local sound_name, cooldown_t, msg_type
	local enemy_target = data.attention_obj
	if enemy_target then
		if enemy_target.is_deployable then
			msg_type = "sentry_detected"
			sound_name = "ch2"
			cooldown_t = 60
		elseif enemy_target.unit:in_slot(managers.slot:get_mask("all_criminals")) then
			local weapon = enemy_target.unit.inventory and enemy_target.unit:inventory():equipped_unit()
			if weapon and weapon:base():is_category("saw") then
				msg_type = "saw_maniac"
				sound_name = "ch4"
				cooldown_t = 60
			elseif self:_has_deployable(enemy_target.unit) then
				if self:_has_deployable_type(enemy_target.unit, "doctor_bag") then
					msg_type = "doc_bag"
					sound_name = "med"
				elseif self:_has_deployable_type(enemy_target.unit, "ammo_bag") then
					msg_type = "ammo_bag"
					sound_name = "amm"
				end
				cooldown_t = 60
			end
		end
	end
	if #self:_next_to_cops(data) <= 0 then
		return
	end
	if enemy_target.dis > 700 then
		return
	end
	if not msg_type or not self:ene_inform_has_cooldown_met(msg_type) then
		return
	end
	if data.unit then
		data.unit:sound():say(sound_name, true)
		self:start_inform_ene_cooldown(cooldown_t, msg_type)
	end
end


function DeadLocke:update_downs_counter(arg1, reset)
	local unit
	if arg1 then
		if type(arg1) == "number" then
			unit = managers.criminals:character_unit_by_peer_id(arg1)
		elseif type(arg1) == "string" then
			unit = managers.criminals:character_unit_by_name(arg1)
		elseif type(arg1) == "userdata" then
			unit = arg1
		end
	end
	if not unit then
		return
	end
	local u_key = unit:key()
	if not self._down_counters[u_key] then
		self._down_counters[u_key] = 0
	end
	local add_down = reset and 0 or self._down_counters[u_key] + 1
	self._down_counters[u_key] = add_down
end

function DeadLocke:close_teammate()
	local close_unit, close_unit_dis
	local close_pos = managers.player:player_unit() and managers.player:player_unit():position() or Vector3()
	for u_key, u_data in pairs(managers.groupai:state()._criminals) do
		if u_data and not u_data.is_deployable and u_data.unit and alive(u_data.unit) and not u_data.unit:base().is_local_player and not u_data.unit:movement():downed() and not u_data.unit:sound():speaking() then
			local close_dis = mvector3.distance_sq(close_pos, u_data.unit:position())
			if not close_unit_dis or close_dis < close_unit_dis then
				close_unit = u_data.unit
				close_unit_dis = close_dis
			end
		end
	end
	return close_unit
end

function DeadLocke:comment_on_thief_looter(loot_unit)
	local t = TimerManager:game():time()
	if not self._steal_warning_t or self._steal_warning_t + 30 < t then
		DelayedCalls:Add("loot_unit_stolen_"..tostring(loot_unit:key()), 1, function()
			self:criminal_comment(nil, false, "p31", loot_unit:position(), true, nil, false, false)
		end)
		self._steal_warning_t = t
	end
end

function DeadLocke:ai_needs_host_desired_value(desired_value)
	local desired_values = {
		"ply_assault_toggle"
	}
	return table.contains(desired_values, desired_value)
end
function DeadLocke:captain_winters_arrival_comment()
	DelayedCalls:Add("cpa_arrived", 2, function()
		DeadLocke:say("f45x_any")
	end)
end

function DeadLocke:say(sound_name, desired_value, use_ai)
	if not self:incharge() then
		return
	end
	local canary_unit
	local canary_units = {}
	for can_u_key, can_u_data in pairs(self:all_modded_units()) do
		if can_u_data and can_u_data.unit and alive(can_u_data.unit) and not can_u_data.unit:movement():downed() then
			if not desired_value or can_u_data.peer_data[desired_value] then
				table.insert(canary_units, can_u_data.unit)
			end
		end
	end
	if Network and Network:is_server() and use_ai and self:ai_needs_host_desired_value(desired_value) then
		for u_key, u_data in pairs(managers.groupai:state():all_AI_criminals()) do
			if u_data.unit and alive(u_data.unit) and not u_data.unit:movement():downed() then
				table.insert(canary_units, u_data.unit)
			end
		end
	end
	for index, can_unit in pairs(canary_units) do
		if not self:can_criminal_say(sound_name, can_unit) or #canary_units > 1 and self._last_speaker == can_unit then
			table.remove(canary_units, index)
		end
	end
	if next(canary_units) then
		canary_unit = canary_units[math.random(#canary_units)]
	end
	if canary_unit then
		canary_unit:sound():say(sound_name, true, true)
		self._last_speaker = canary_unit
		local last_speaker_name = managers.criminals:character_name_by_unit(self._last_speaker)
		if last_speaker_name then
			DeadLockeNetwork:send_json_data_to_peers("sync_last_speaker", last_speaker_name)
		end
	end
end

function DeadLocke:register_jammed_drill(unit)
	if not unit then
		return
	end
	local u_key = unit:key()
	local u_sighting = {
		unit = unit,
		pos = unit:position(),
		priority = 6
	}
	if unit.base and unit:base() then
		if unit:base().is_huge_lance then
			u_sighting.priority = 1
		elseif unit:base().is_lance then
			u_sighting.priority = 2
		elseif unit:base().is_hacking_device then
			u_sighting.priority = 3
		elseif unit:base().is_saw then
			u_sighting.priority = 4
		elseif unit:base().is_drill then
			u_sighting.priority = 5
		end
		u_sighting.jammed_count = unit:base()._jammed_count
	end
	self._jammed_drills[u_key] = u_sighting
	if next(self._jammed_drills) and not self._drill_remind_clbk then
		self._next_jammed_reminder_t = 30
		self._drill_remind_clbk = callback(self, self, "_drill_reminder_clbk")
		managers.enemy:add_delayed_clbk(self._drill_remind_id, self._drill_remind_clbk, Application:time() + 20)
	end
end

function DeadLocke:unregister_jammed_drill(unit)
	if not unit then
		return
	end
	self._jammed_drills[unit:key()] = nil
	if not next(self._jammed_drills) and self._drill_remind_clbk then
		managers.enemy:remove_delayed_clbk(self._drill_remind_id)
		self._drill_remind_clbk = nil
	end
end

function DeadLocke:all_jammed_drills()
	return self._jammed_drills
end

function DeadLocke:closest_jammed_drill()
	local close_u_data_d, best_priority, close_u_data
	local close_pos = managers.player:player_unit() and managers.player:player_unit():position() or Vector3()
	local devices = {}
	for u_key, u_data in pairs(self._jammed_drills) do
		local close_dis = mvector3.distance_sq(close_pos, u_data.pos)
		if (not close_u_data_d or close_dis < close_u_data_d) and (not best_priority or u_data.priority <= best_priority) then
			close_u_data_d = close_dis
			close_u_data = u_data
			best_priority = u_data.priority
		end
	end
	return close_u_data
end

function DeadLocke:_drill_reminder_clbk()
	local d_data = DeadLocke:closest_jammed_drill()
	if not d_data then
		return
	end
	d_data.unit:base():_drill_remind_clbk()
	managers.enemy:add_delayed_clbk("drill_remind_id", self._drill_remind_clbk, self:_game_t()  + self._next_jammed_reminder_t)
	if self._next_jammed_reminder_t >= 75 then
		return
	end
	self._next_jammed_reminder_t = self._next_jammed_reminder_t + 15
end


function DeadLocke:_revive_line(rescuer, revive_unit)
end


function DeadLocke:_on_alarm(called_reason)
end

function DeadLocke:hostage_trade_comment()
	self:say("p07")
	self._on_hostage_trade_clbk = nil
end

function DeadLocke:alternatives(sound_name, char_name)
	for snd_name , snd_data in pairs(self._alternatives) do
		if snd_name == sound_name then
			for char, snds in pairs(snd_data.chars) do
				if char == char_name then
					return snds[math.random(#snds)]
				end
			end
			if snd_data.default then
				return snd_data.default[math.random(#snd_data.default)]
			end
		end
	end
	for old_sound, new_sound in pairs(self.old_to_modern_pd_sound_names) do
		if old_sound == sound_name then
			return new_sound
		end
	end
	return sound_name
end

function DeadLocke:get_sound_device(name)
	local music_data = {
		intro = "control",
		anticipation = "control",
		assault = "assault",
		fake_assault = "assault",
		control = "control"
	}
	return name and music_data[name] or nil
end

function DeadLocke:queue_dialog(id, params, sync)
end

function DeadLocke:is_third_person_sound(sound_name)
	local random_switch = {"first","third"}
	for i,v in pairs(self.randomize) do
		local snd_name = v
		if type(sound_name) == "number" then
			snd_name = SoundDevice:string_to_id(v)
		end
		if snd_name == sound_name then
			return random_switch[math.random(#random_switch)]
		end
	end
	for i,v in pairs(self.third_person_ids) do
		local snd_name = v
		if type(sound_name) == "number" then
			snd_name = SoundDevice:string_to_id(v)
		end
		if snd_name == sound_name then
			return "third"
		end
	end
	return "first"
end

function DeadLocke:get_track_group_by_name(group_name)
end


function DeadLocke:_unit_downs_by_unit(unit)
	local u_key = unit:key()
	return self:_unit_downs_by_unit_key(u_key)
end
function DeadLocke:_unit_downs_by_unit_key(u_key)
	if managers.groupai:state():all_AI_criminals()[u_key] then
		return 0
	end
	return self._down_counters[u_key] or 0
end
--JSON Related Code 
function DeadLocke:get_json_data_from_params(...) -- May be a bit buggy
	local params = {...}
	local json_t = {}
	local i = 0
	local str = ""
	while #params do
		i = i + 1
		if i  == 1 then
			str = str.."["
		elseif i > #params then
			if next(json_t) then
				local data = table.remove(json_t, 1)
				params = data.prev_params
				i = data.prev_i + 1
				--str = str.. (#params > i and "]" or "], ")
				str = str.. (i > #params and "]" or "], ")
				str = data.prev_str..str
				if i > #params then
					str = str.."]"
					break
				end
				if params[i] == nil then
					error("[DeadLocke:get_json_data_from_params] nil value at index "..i)
				end
			else
				str = str.."]"
				break
			end
		end
		local conc = ""
		local skip
		if params[i] == nil then
			params[i] = "null"
		elseif type(params[i]) == "string" then
			conc = "\""
		elseif type(params[i]) == "table" then
			table.insert(json_t, {
				prev_params = params,
				prev_str = str,
				prev_i = i
			})
			params = params[i]
			i = 0
			skip = true
			str = ""
		end
		if not skip then
			str = str..conc..tostring(params[i])..conc..(#params == i and "" or ", ")
		end
	end
	return str
end


function DeadLocke:is_peer_id_canary_user(peer_id)
	if not peer_id then
		return false
	end
	if peer_id == 0 then
		return false
	end
	for i, data in pairs(self._peer_ids) do
		if data.peer_id == peer_id then
			return true
		end
	end
	return false
end
function DeadLocke:is_unit_canary_user(unit)
	if not unit then
		return false
	end
	local peer_id = managers.criminals:character_peer_id_by_unit(unit)
	return self:is_peer_id_canary_user(peer_id)
end

function DeadLocke:sync_peer_toggleable_data(dlock_data, peer_id) 
	local toggle_data = json.decode(dlock_data)
	if not toggle_data then
		log("[DeadLocke:sync_peer_toggleable_data] could not get dlock_data from peer!!")
		return
	end
	for value, enable in pairs(toggle_data) do
		self:enable_peer_data_value(value, enable, peer_id, false)	
	end
end

function DeadLocke:OnResetValues()	
	local my_peer_id = self:my_peer() and self:my_peer():id()	 
	if my_peer_id then
		for value_id, enabled in pairs(self._data) do
			if self:_get_event_id_by_value_name(value_id) then
				DeadLockeNetwork:send_json_data_to_peers("sync_enable_peer_data_value", value_id, enabled and true or false)
			end
		end
	end
end
function DeadLocke:get_maximum_downs_until_death(unit)
	local u_key = unit:key()
	local last_down = 3
	local additional_lives
	if unit:base().is_local_player then
		additional_lives = managers.player:has_category_upgrade("player", "additional_lives")
	else
		local data = DeadLocke:get_peer_data_from_unit(unit)
		if data then
			additional_lives = data.additional_lives
		end
	end
	if additional_lives then
		last_down = last_down + 1
	end
	if Global.game_settings.difficulty == "sm_wish" then
		last_down = last_down - 2
	end
	return last_down
end


function DeadLocke:player_unit()
	return managers.player:player_unit()
end
function DeadLocke:is_unit_player(unit)
	return managers.groupai:state():all_player_criminals()[unit:key()] and true or false
end
function DeadLocke:is_unit_char_criminal(unit)
	return managers.groupai:state():all_char_criminals()[unit:key()] and true or false
end
function DeadLocke:is_unit_team_AI(unit)
	return managers.groupai:state():is_unit_team_AI(unit)
end

function DeadLocke:modded_peers_count()
	local count = 0
	for i, data in pairs(self._peer_ids) do
		if data and data.peer_id then
			count = count + 1
		end
	end
	return count
end
function DeadLocke:all_modded_units()
	local modded_units = {}
	for u_key, u_data in pairs(managers.groupai:state():all_char_criminals()) do
		if u_data and u_data.unit then
			if self:is_unit_canary_user(u_data.unit) then
				modded_units[u_key] = {
					unit = u_data.unit,
					peer_data = self:get_peer_data_from_unit(u_data.unit)
				}
			end
		end
	end
	return modded_units
end

function DeadLocke:begin_with_phase(assault)
	if not managers or not managers.mission or not managers.mission._scripts then
		return
	end
	local mission_scripts = managers.mission._scripts
	if assault then
		for name, script in pairs(mission_scripts) do
			for index, id in pairs(script._elements) do
				if script._elements[id] and script._elements[id]._values and script._elements[id]._values.music_event == "music_heist_control" then
					self._saved_elements[id] = script._elements[id]
					script._elements[id]._values.music_event = "music_heist_assault"
				end
			end
		end
	else
		for id, data in pairs(self._saved_elements) do
			if data and data._values and data._values.music_event then
				mission_scripts.default._elements[id]._values.music_event = data
			end
		end
	end
end

function DeadLocke:String_to(value, type)
	local text = tostring(value)
	local _table = {}
	local test = ""
	local first
	for i = 1, #text do
		local go = text:sub(i,i)
		if go == "(" then
			local go = text:sub(i + 1,i + 1)
			test = ""
			first = true
		elseif go == "," then
			table.insert(_table, tonumber(test))
			test = ""
			local go = text:sub(i + 1,i + 1)
			test = test..go
		elseif go == ")" then
			table.insert(_table, tonumber(test))
			if _table[1] and _table[2] and _table[2] then
				if type == "Vector3" then
					return Vector3(_table[1],_table[2],_table[3])
				elseif type == "Rotation" then
					return Rotation(_table[1],_table[2],_table[3])
				end
			else
				if type == "Vector3" then
					log("ERROR : No Vector3")
				elseif type == "Rotation" then
					log("ERROR : No Rotation")
				end
				return nil
			end
		elseif first and go ~= "," or go ~= ")" or go ~= "(" then
			test = test..go
		end
	end
end

function DeadLocke:String_to_Vector(pos)
	return self:String_to(pos, "Vector3")
end
function DeadLocke:String_to_Rotation(rot)
	return self:String_to(rot, "Rotation")
end
function DeadLocke:deep_clone(data, class)
	if not data then
		if class and type(class) == "string" then
			error("[DeadLocke:deep_clone] could not clone class "..class)
		end
		return
	end
	local clone_data = {}
	for i,v in pairs(data) do
		clone_data[i] = v
	end
	return clone_data
end


dofile(DeadLocke._path.."Lua/DEADLOCKE_networkmanager.lua")
function DeadLocke:Load_map_dialogue(level_id)
	local levels_sounds = {
		"short1/stage1",
		"short1/stage2",
		"short2/stage1",
		"short2/stage2",
		"vlad/ukrainian_job",
	}
	for i, path_name in pairs(levels_sounds) do
		if not PackageManager:load( "levels/narratives/"..path_name.."/world_sounds" ) then
			PackageManager:load( "levels/narratives/"..path_name.."/world_sounds" )
			log("Loading World sound: levels/narratives/"..path_name.."/world_sounds")
		end
	end
	dofile(DeadLocke._path.."mission/deadlockemissionscriptelement.lua")
	dofile(DeadLocke._path.."mission/elementdialogue.lua")
	dofile(DeadLocke._path.."mission/elementfakeassaultstate.lua")
	dofile(DeadLocke._path.."mission/elementteammatecomment.lua")
	dofile(DeadLocke._path.."mission/elementplayoggcomment.lua")
	dofile(DeadLocke._path.."mission/elementtoggle.lua")
	dofile(DeadLocke._path.."mission/elementfilter.lua")
	dofile(DeadLocke._path.."mission/elementdebugtext.lua")
	dofile(DeadLocke._path.."mission/elementmusic.lua")
	dofile(DeadLocke._path.."mission/elementcounter.lua")
	dofile(DeadLocke._path.."mission/elementsounddevice.lua")
	dofile(DeadLocke._path.."mission/elementinstigator.lua")
	dofile(DeadLocke._path.."mission/elementsetuponweaponshot.lua")
	dofile(DeadLocke._path.."mission/elementrandom.lua")
	dofile(DeadLocke._path.."mission/elementlogicchance.lua")
	--dofile(DeadLocke._path.."mission/elementarea.lua")
	if DeadLockeMissionScriptElement then
		DeadLockeMissionScriptElement:load_mission_script(level_id)
	end
end


dofile(DeadLocke._path.."Lua/DEADLOCKE_networkmanager.lua")


function DeadLocke:displaynotification()
end

Hooks:Add("MenuManagerOnOpenMenu", "MenuManagerOnOpenMenu_CanaryWarning", function( menu_manager, menu, position )

	if menu == "menu_main" then
		DeadLocke:displaynotification()
	end

end)
--[[
	Load our localization keys for our menu, and menu items.
]]
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_DeadLocke", function( loc )
	loc:load_localization_file(DeadLocke._path .. "loc/english.txt")

end)

--[[
	Setup our menu callbacks, load our saved data, and build the menu from our json file.
]]
Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_DeadLocke", function( menu_manager )

	--[[
		Setup our callbacks as defined in our item callback keys, and perform our logic on the data retrieved.
	]]
	for index, clbk_data in pairs(DeadLocke._MenuCallbackHandlers) do
		MenuCallbackHandler[clbk_data.clbk_id] = function(self, item)
			local enabled = item:value() == "on" and true or false
			DeadLocke._data[clbk_data.value_id] = enabled
			DeadLocke:Save()
			DeadLocke:enable_peer_data_value(clbk_data.value_id, enabled, nil)
			DeadLockeNetwork:send_json_data_to_peers("sync_enable_peer_data_value", clbk_data.value_id, enabled)
			log("[DeadLocke MenuCallbackHandler]: "..clbk_data.clbk_id.." value: " .. item:value())
		end
	end
	MenuCallbackHandler.callback_reset_options = function(self, item)
		local items_to_reset_1 = {
			can_ban_global = true,
			can_ban_start_assault_toggle = true,
			can_ply_inspire_toggle = true,
			can_ply_call_toggle = true,
			can_ply_defend_call_toggle = true,
			can_ply_knees_toggle = true,
			can_ply_spot_toggle = true,
			can_ply_cams_toggle = true,
			can_ply_ties_toggle = true,
			can_ply_ties_2_toggle = true,
			can_ply_detect_toggle = true,
			can_ban_ponr_toggle = true
		}
		local default_value_1 = true
		local items_to_reset_2 = {
			can_ban_toggle = true,
			can_ply_assault_toggle = true,
			can_ban_pag_toggle = true,
			can_infrm_drill_done = true,
			can_ply_mark_turet_toggle = true,
			can_ply_spot_dozer_toggle = true,
			can_ply_spot_medic_toggle = true,
			can_music_event_toggle = true,
			can_ban_special_comment = true,
			can_dallas_drill_comment = true
		}
		local default_value_2 = false
		MenuHelper:ResetItemsToDefaultValue( item, items_to_reset_1, default_value_1 )
		MenuHelper:ResetItemsToDefaultValue( item, items_to_reset_2, default_value_2 )
		DeadLocke:OnResetValues()
		log("Settings reset!")
	end
	DeadLocke:Load()
	MenuHelper:LoadFromJsonFile( DeadLocke._path .. "Menu/canary_menu.txt", DeadLocke, DeadLocke._data )
end )
