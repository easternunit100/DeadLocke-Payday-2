local _VehicleStateBroken_enter = VehicleStateBroken.enter
function VehicleStateBroken:enter(state_data, enter_data)
	_VehicleStateBroken_enter(self, state_data, enter_data)
	local pm = managers.player
	local player_vehicle = pm:get_vehicle()
	if player_vehicle and player_vehicle.vehicle_unit == self._unit then
		local player = pm:player_unit()
		local t = TimerManager:game():time()
		if player and alive(player) and (not DeadLocke._vehicle_comment_t or DeadLocke._vehicle_comment_t + 10 < t)   then
			local current_state = player:movement():current_state()
			if current_state and current_state._seat and current_state._seat.driving then
				DelayedCalls:Add("broken_vehicle_"..tostring(self._unit:key()), 1, function()
					local sound_name = self._unit:vehicle_driving():num_players_inside() > 2 and "d05" or "g29"
					if DeadLocke._data.can_vehicle then
						player:sound():say(sound_name, true)
						DeadLocke._vehicle_comment_t = t
					end
				end)
			end
		end
	end
end