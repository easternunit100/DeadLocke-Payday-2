local _TradeManager_sync_hostage_trade_dialog = TradeManager.sync_hostage_trade_dialog
function TradeManager:sync_hostage_trade_dialog(i)
	_TradeManager_sync_hostage_trade_dialog(self, i)
	if not DeadLocke._on_hostage_trade_clbk and table.size(managers.groupai:state():all_char_criminals()) > 1 then
		if i and i > 1 and i < 8 then
			DeadLocke._on_hostage_trade_clbk = callback(DeadLocke, DeadLocke, "hostage_trade_comment")
			managers.enemy:add_delayed_clbk(DeadLocke._on_hostage_trade_clbk_id, DeadLocke._on_hostage_trade_clbk, Application:time() + 3)	
		end
	end
end

local _Tr_sync_set_trade_death = TradeManager.sync_set_trade_death
function TradeManager:sync_set_trade_death(criminal_name, respawn_penalty, hostages_killed, from_local, ...)
	_Tr_sync_set_trade_death(self, criminal_name, respawn_penalty, hostages_killed, from_local, ...)
	
	if criminal_name ~= managers.criminals:local_character_name() then		
		DelayedCalls:Add('DelayedMod_trade_death_comment_' .. tostring(criminal_name), 2, function()
			local player = managers.player:player_unit()
			if player and alive(player) then
				player:sound():say("g60", false, false)  --- Hoxton has a bug with this voice line where he sometimes says "I got the drill"
			end
		end)
		
		local crim_data = managers.criminals:character_data_by_name(criminal_name)
		if crim_data and not crim_data.ai then
			local _ban_informing_about_hostages = {}
				
			local function _queue_dialog(id, params)	
				params = params or {}
				if _ban_informing_about_hostages and next(_ban_informing_about_hostages) then
					local next_data = table.remove(_ban_informing_about_hostages, 1)
					function params.done_cbk()
						_queue_dialog(next_data[1], next_data[2])	
					end
				end
				managers.dialog:queue_narrator_dialog(id, params)
			end
			
			if hostages_killed then
				if hostages_killed == 0 then
					table.insert(_ban_informing_about_hostages, {"h13x"})
				elseif hostages_killed < 3 then
					table.insert(_ban_informing_about_hostages, {"h14x"})
				else
					table.insert(_ban_informing_about_hostages, {"h15x"})
				end
			end
			
			if managers.groupai:state():get_assault_mode() or respawn_penalty and respawn_penalty > 10 then
				table.insert(_ban_informing_about_hostages, {"h16x"})
			end

			local cable_tie_data = managers.player:has_special_equipment("cable_tie")
			if cable_tie_data and Application:digest_value(cable_tie_data.amount, false) > 0 then
				table.insert(_ban_informing_about_hostages, {"h01x"})
			elseif self:get_criminal_to_trade(true) then
				table.insert(_ban_informing_about_hostages, {"h21x"})
			end
			
			
			if _ban_informing_about_hostages and next(_ban_informing_about_hostages) then
				local data = table.remove(_ban_informing_about_hostages, 1)
				_queue_dialog(data[1], {delay = 6})
			end	
		end
	end
	
end

