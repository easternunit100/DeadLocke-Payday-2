local _TradeManager_sync_hostage_trade_dialog = TradeManager.sync_hostage_trade_dialog
function TradeManager:sync_hostage_trade_dialog(i)
	_TradeManager_sync_hostage_trade_dialog(self, i)
	if not DeadLocke._on_hostage_trade_clbk and table.size(managers.groupai:state():all_char_criminals()) > 1 then
		DeadLocke._on_hostage_trade_clbk = callback(DeadLocke, DeadLocke, "hostage_trade_comment")
		managers.enemy:add_delayed_clbk(DeadLocke._on_hostage_trade_clbk_id, DeadLocke._on_hostage_trade_clbk, Application:time() + 5)	
	end
end

local _TradeManager_sync_set_trade_death = TradeManager.sync_set_trade_death
function TradeManager:sync_set_trade_death(criminal_name, ...)
	_TradeManager_sync_set_trade_death(self, criminal_name, ...)
	if managers.criminals:local_character_name() == criminal_name then
		return
	end
	DelayedCalls:Add('DelayedMod_trade_death_comment_' .. tostring(criminal_name), 2, function()
		local player = managers.player:player_unit()
		if player and alive(player) then
			player:sound():say("g60", false, false)  --- Hoxton has a bug with this voice line where he sometimes says "I got the drill"
		end
	end)
end
