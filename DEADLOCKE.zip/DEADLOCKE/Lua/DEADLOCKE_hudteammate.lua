local _HUDTeammate_start_timer = HUDTeammate.start_timer
function HUDTeammate:start_timer(time)
	_HUDTeammate_start_timer(self, time)
	local player = managers.player:player_unit()
	if not self._main_player and player and alive(player) and not player:movement():downed() then
		local t = TimerManager:game():time()
		if not DeadLocke._downed_comment_t or DeadLocke._downed_comment_t + 2 < t then
			player:sound():say("g29", false, false)
			DeadLocke._downed_comment_t = t
		end
	end
end