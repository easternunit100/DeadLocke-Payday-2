if not NetworkPeer then 
	return 
end


local _NetworkPeer_set_waiting_for_player_ready = NetworkPeer.set_waiting_for_player_ready
function NetworkPeer:set_waiting_for_player_ready(state)
	_NetworkPeer_set_waiting_for_player_ready(self, state)
	if self._waiting_for_player_ready and self._character then
		local empty_function = function()
		end 
		local static_data = managers.criminals:character_static_data_by_name(self._character)
		if not static_data then
			return
		end
		local source = SoundDevice:create_source("on_ready_"..self._character)
		source:set_switch("robber", static_data.voice)
		source:set_switch("int_ext", "first")
		source:post_event("a01x_any", empty_function, nil, "end_of_event")
	end
end