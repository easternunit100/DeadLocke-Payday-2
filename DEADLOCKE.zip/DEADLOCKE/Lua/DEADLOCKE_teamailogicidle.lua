local _TeamAILogicIdle_enter = TeamAILogicIdle.enter
function TeamAILogicIdle.enter(data, new_logic_name, enter_params)
	local SAVE_DOWNED_TIME_MIN = tweak_data.player.damage.DOWNED_TIME_MIN
	local SAVE_DOWNED_TIME = tweak_data.player.damage.DOWNED_TIME
	
	local objective = data.objective
	if objective and objective.follow_unit then
		local revive_unit = objective.follow_unit
		local last_down = DeadLocke:get_maximum_downs_until_death(revive_unit)
		local revive_key = revive_unit:key()
		if DeadLocke:_unit_downs_by_unit_key(revive_key)  then
			local unit_downs = DeadLocke:_unit_downs_by_unit_key(revive_key) 
			if unit_downs >= last_down then 
				tweak_data.player.damage.DOWNED_TIME_MIN = 10000000
			elseif unit_downs >= 2 then
				tweak_data.player.damage.DOWNED_TIME = 100000000
			else
				tweak_data.player.damage.DOWNED_TIME_MIN = -1000
				tweak_data.player.damage.DOWNED_TIME = -1000
			end
		end
	end
	
	_TeamAILogicIdle_enter(data, new_logic_name, enter_params)
	
	tweak_data.player.damage.DOWNED_TIME_MIN = SAVE_DOWNED_TIME_MIN
	tweak_data.player.damage.DOWNED_TIME = SAVE_DOWNED_TIME
end