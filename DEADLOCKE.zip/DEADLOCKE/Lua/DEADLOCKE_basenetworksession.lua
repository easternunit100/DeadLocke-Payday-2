local _BaseNetworkSession_on_peer_left = BaseNetworkSession.on_peer_left
function BaseNetworkSession:on_peer_left(peer, peer_id)
	_BaseNetworkSession_on_peer_left(self, peer, peer_id)
	DeadLocke:remove_peer(peer_id, "left")
end

local _BaseNetworkSession_on_peer_lost = BaseNetworkSession.on_peer_lost
function BaseNetworkSession:on_peer_lost(peer, peer_id)
	_BaseNetworkSession_on_peer_lost(self, peer, peer_id)
	DeadLocke:remove_peer(peer_id)
end

local _BaseNetworkSession_on_peer_kicked = BaseNetworkSession.on_peer_kicked
function BaseNetworkSession:on_peer_kicked(peer, peer_id, message_id)
	_BaseNetworkSession_on_peer_kicked(self, peer, peer_id)
	DeadLocke:remove_peer(peer_id, "kicked")
end