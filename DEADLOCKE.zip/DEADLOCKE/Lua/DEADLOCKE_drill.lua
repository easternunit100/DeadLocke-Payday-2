if not DeadLocke then
	return
end

Drill._drll_complain_id = "drill_complain_id"
local _Drill_init = Drill.init
function Drill:init(unit)
	_Drill_init(self, unit)
	self.is_lance = DeadLocke:get_drill_name(unit) == "lance"
	self.is_huge_lance = DeadLocke:get_drill_name(unit) == "huge_lance"
end

function Drill:_change_num_jammed_drills(d)
end

function Drill:_drill_complain_clbk()
	local player = managers.player:player_unit()
	if player and alive(player) and not player:movement():downed() then
		if managers.criminals:character_name_by_unit(player) == "russian" then
			if managers.dialog then
				managers.dialog:queue_dialog("Play_rb4_sh21_03", {})
			end
		end
	end
end

local _Drill_set_jammed = Drill.set_jammed
function Drill:set_jammed(jammed)
	_Drill_set_jammed(self, jammed)
	if self._jammed then
		if not DeadLocke:is_tutorial_stage() then
			if self.is_drill and not self.is_huge_lance then
				if not Drill._compln_remind_clbk then
					Drill._compln_remind_clbk = callback(Drill, Drill, "_drill_complain_clbk")
					managers.enemy:add_delayed_clbk(Drill._drll_complain_id, Drill._compln_remind_clbk, Application:time() + 1.5)
				end
			end
		end
		DeadLocke:register_jammed_drill(self._unit)
	else
		if self.is_hacking_device and not managers.groupai:state():whisper_mode() then
			if math.random(1) < 0.5 then
				DeadLocke:criminal_comment(nil, true, "p10", self._unit:position(), true, 500, false, false)
			end
		end
		DeadLocke:unregister_jammed_drill(self._unit)
	end
end


local _Drill_done = Drill.done
function Drill:done()
	_Drill_done(self)
	if DeadLocke._data.inf_drill_done_toggle then
		local comment = self.is_drill and "v23" or self.is_hacking_device and "v24" or "v07"
		DeadLocke:criminal_comment(nil, true, comment, self._unit:position(), true, 2000, false ,false)
	end
end


function Drill:_drill_remind_clbk()
	local close_unit = DeadLocke:close_teammate()
	local vr_character = managers.criminals:local_character_name()
	local suffix = DeadLocke:amount_of_saws() > 1 and "plu" or "sin"
	local char_name = managers.criminals:character_name_by_unit(close_unit)
	local is_lance = DeadLocke:get_drill_name(self._unit) == "lance"
	local device = (self.is_huge_lance or is_lance) and "lance" or self.is_hacking_device and "hacking_device" or self.is_saw and "saw" or self.is_drill and "drill" or "default"
	local drill_1, drill_2, hack_2 = "d01x_sin", "d02x_sin", "d03_plu"
	if char_name == "jowi" or char_name == "dragan" then
		drill_2 = "d01x_sin"
	end
	if char_name == "american" then
		drill_1 = "d05"
	end
	if char_name == "american" or char_name == "old_hoxton" or char_name == "russian" or char_name == "spanish" then
		hack_2 = "d04_plu"
	end
	local Drill_COMMENTS = {}
	Drill_COMMENTS.drill = {drill_1,drill_2}
	Drill_COMMENTS.lance = (char_name == "russian" or char_name == "american" or char_name == "spanish") and {"d03_sin","d04_sin"} or {drill_1,drill_2}
	Drill_COMMENTS.saw = char_name == "german" and {"d03_"..suffix,"d04_"..suffix} or {"d05","d05"}
	Drill_COMMENTS.hacking_device = char_name == "german" and {"d05","d05"} or {"d03_plu",hack_2}
	Drill_COMMENTS.default = {"d05","d05"}
	local message = Drill_COMMENTS[device][self._jammed_count <= 1 and 1 or 2]	
	if managers.groupai:state():whisper_mode() then	
		message = nil
		if vr_character == "american" then
			local loc_unit = managers.player:player_unit()
			if loc_unit and alive(loc_unit) and not loc_unit:movement():downed() then
				if device == "drill" then
					close_unit = loc_unit
					message = "d01x_sin"
				end
			end
		end
	end
	if message and close_unit then
		close_unit:sound():say(message, false, true)
	end
end