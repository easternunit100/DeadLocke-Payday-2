PlayerMaskOff.voice_type_varies = PlayerStandard.voice_type_varies
PlayerMaskOff.get_voice_type_varies = PlayerStandard.get_voice_type_varies
function PlayerMaskOff:mark_units(line, t, no_gesture, skip_alert)
	local mark_sec_camera = managers.player:has_category_upgrade("player", "sec_camera_highlight_mask_off")
	local mark_special_enemies = managers.player:has_category_upgrade("player", "special_enemy_highlight_mask_off")
	local voice_type, plural, prime_target = self:_get_unit_intimidation_action(mark_special_enemies, false, false, false, false)
	local interact_type, sound_name
	if voice_type == "mark_cop" or voice_type == "mark_cop_quiet" then
		interact_type = "cmd_point"
		local shout_sound = tweak_data.character[prime_target.unit:base()._tweak_table][voice_type == "mark_cop_quiet" and "silent_priority_shout" or "priority_shout"]
		if shout_sound then
			shout_sound = shout_sound..(voice_type == "mark_cop_quiet" and "_any" or "x_any")
			local voice_vari = voice_type == "mark_cop_quiet" and voice_type or prime_target.unit:base()._tweak_table
			sound_name = self:get_voice_type_varies(voice_vari, prime_target.unit) or shout_sound
		end
		if managers.player:has_category_upgrade("player", "special_enemy_highlight") then
			prime_target.unit:contour():add(managers.player:get_contour_for_marked_enemy(), true, managers.player:upgrade_value("player", "mark_enemy_time_multiplier", 1))
		end
	elseif voice_type == "mark_camera" and mark_sec_camera then
		sound_name = self:get_voice_type_varies(voice_type) or "f39_any"
		interact_type = "cmd_point"
		prime_target.unit:contour():add("mark_unit", true)
	end
	if interact_type then
		if not no_gesture then
		else
		end
		self:_do_action_intimidate(t, interact_type or nil, sound_name, skip_alert)
		return true
	end
	return mark_sec_camera or mark_special_enemies
end