DeadLockeSoundPlayBack = DeadLockeSoundPlayBack or blt_class()

local SoundPlayBack = DeadLockeSoundPlayBack


function SoundPlayBack:init(ids)
	self._ids = ids or {}
	self._sound_bank = {}
	self._slot_index = {}
	self._last_slot_index = {}
	self._chance = {}
	self._delays = {}
	self._get_last_string_id = {}
	self._slot = 0
	self._playing = false
	self._volume = 2
	self._t = 0
	self._goaltimer = nil
	self._sounds = nil
end

function SoundPlayBack:add_to_sound_category(slot, file, chance, can_repeat, string_id, volume, markers)
	self._sound_bank[slot] = self._sound_bank[slot] or {}


	self._slot_index[slot] = (self._slot_index[slot] or 0) + 1
	table.insert(self._sound_bank[slot], {
		file = file,
		chance = chance or 1,
		string_id = string_id,
		volume = volume or self._volume,
		can_repeat = can_repeat and true or false,
		slot_index = self._slot_index[slot],
		markers = markers
	})
end

function SoundPlayBack:contains_id(id)
	local ids
	if type(id) == "number" then
		ids = {}
		for index, id in pairs(self._ids) do
			table.insert(ids, SoundDevice:string_to_id(id))			
		end
	else
		ids = self._ids		
	end
	return table.contains(ids, id)
end


function SoundPlayBack:add_slot_chance(slot, slot_chance)
	self._chance[slot] = slot_chance or nil
end

function SoundPlayBack:add_slot_delay(slot, slot_delay)
	self._delays[slot] = slot_delay or 0
end

function SoundPlayBack:set_last_string_id(slot)
	self._get_last_string_id[slot] = true
end


function SoundPlayBack:_add(slot, slot_delay, slot_chance, file_data)
	for index, data in pairs(file_data) do
		self:add_to_sound_category(slot, data.file, slot_chance, slot_delay, data.chance, data.can_repeat)
	end
end


function SoundPlayBack:destroy_sound_source()	
	self._goaltimer = nil
	self._sounds = nil
	self._current_markers = nil
	if self._sound_source then
		if not self._sound_source:is_closed() then				
			self._sound_source:close()
			self._sound_source = nil
			self:_buffer_close()				
		end
	end
	self._playing = false
end

function SoundPlayBack:stop()
	self:destroy_sound_source()
end

function SoundPlayBack:subtitle_len()
	local duration
	if self._roll then
		if self._roll.subtitle_len then
			duration = self._roll.subtitle_len
		elseif self._roll.use_buffer_len then
			duration = tonumber(self._sound_buffer:get_length())
		elseif self._roll.string_id then
			duration = DramaExt:_subtitle_len(self._roll.string_id)
		end
	end
	return duration
end

function SoundPlayBack:play_sound_source()
	self._buffer = self._roll.file
	self._sound_buffer = XAudio.Buffer:new(self._buffer)
	

	self._sound_source = XAudio.DeadLockeUnitSource:new(self._params.unit, self._sound_buffer)
	
	self._sound_source._gain = self._roll.volume	
	
	self._start_t = self._t
	
	
	if self._params and self._params.listener and self._params.listener.duration then
		self:sound_callback("duration", sound_buffer_duration)
	end
end

function SoundPlayBack:update_sound(t)
	self._t = t
	
	if not self._playing then
		return
	end
	
	if self._current_markers and next(self._current_markers) and self._current_markers[1].time < self._t then
		local marker_data = table.remove(self._current_markers, 1)
		if DramaExt then
			DramaExt:play_subtitle(marker_data.string_id, marker_data.duration or DramaExt:_subtitle_len(marker_data.string_id))
		end
	end
	
	if self._goaltimer and self._goaltimer < self._t then
		self._goaltimer = nil
		self:play_sound_source()
	end
	
	if self._sound_source and self._sound_source:is_closed() then
		self._sound_source = nil
		self:next_sound_file()
	end

end

function SoundPlayBack:sound_callback(marker, duration)
	if marker == "end_of_event" then
		self._playing = false
		if self._params then
			if self._params.type == "playersound" then
			end
		end
		self._params = nil
	elseif marker == "duration" and self._params.type == "briefing" then
		managers.briefing:_set_duration(duration, self._params.cookie)
	end
end

function SoundPlayBack:next_sound_file()
	if not self._sounds or not next(self._sounds) then
		self:sound_callback("end_of_event")
		self._sounds = nil
		return false
	end
	
	self._playing = true

	
	self._roll = table.remove(self._sounds, 1)
	
	local slot_delay = self._roll.delay or 0
	if slot_delay > 0 then
		self._goaltimer = self._t + slot_delay
	else
		self:play_sound_source()
	end
	
	return true
end


function SoundPlayBack:play(params)
	self._params = params
	self:destroy_sound_source()
	self:_get_sounds()
	local playing = self:next_sound_file()
	return playing
end

function SoundPlayBack:is_source_playing()
	return not self._sound_source:is_closed() and self._sound_source:is_active()
end
function SoundPlayBack:playing()
	return self._playing
end

function SoundPlayBack:_buffer_close()
	if self._sound_buffer then
		self._sound_buffer:close()
		self._sound_buffer = nil
	end
end


function SoundPlayBack:_get_sounds()
	self:_buffer_close()
	self._sounds = {}
	self._slot = 0
	while self._slot do
		self._slot = self._slot + 1
		if not self._sound_bank[self._slot] or not next(self._sound_bank[self._slot]) then
			self._slot = nil
		end
		if self._chance[self._slot] and math.random() > self._chance[self._slot] then
			self._slot = nil
		end
		if self._slot then
			local slot_data = self:get_sound_file_from_slot(self._slot)
			if slot_data then
				self._sounds[self._slot] = slot_data
			else
				self._slot = nil
			end
		end
	end
end


function SoundPlayBack:flush()	
	for slot, slot_data in pairs(self._sound_bank) do
		if slot_data then
			for index, data in pairs(slot_data) do	
				if data and data.file then
					self._sound_buffer = XAudio.Buffer:new(data.file)
					self:_buffer_close()
				end		
			end
		end
	end
end

function SoundPlayBack:get_sound_file_from_slot(slot)
	local sound_data = clone(self._sound_bank[slot])
	local sound_data_count = #sound_data
	
	
	for index, data in pairs(sound_data) do
	
		local remove
		
		if math.random() > data.chance then
			remove = true
		end
		
		if not data.can_repeat and self._last_slot_index[slot] == data.slot_index and sound_data_count > 1 then
			remove = true
		end


		if remove then
			table.remove(sound_data, index)
		end
		
	end
	
	if #sound_data == 0 then
		return false
	end
	
	local roll = sound_data[math.random(#sound_data)]
	
	if self._delays[slot] then
		roll.delay = self._delays[slot]
	end	
	
	self._last_slot_index[slot] = roll.slot_index	
	return roll
end