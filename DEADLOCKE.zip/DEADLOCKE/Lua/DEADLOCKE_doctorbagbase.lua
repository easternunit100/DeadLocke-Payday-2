local _DoctorBagBase_take = DoctorBagBase.take
function DoctorBagBase:take(unit)
	DeadLocke:update_downs_counter(unit, true)
	return _DoctorBagBase_take(self, unit)
end