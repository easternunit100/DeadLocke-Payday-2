local _CopLogicAttack_aim_allow_fire = CopLogicAttack.aim_allow_fire
function CopLogicAttack.aim_allow_fire(shoot, aim, data, my_data)
	_CopLogicAttack_aim_allow_fire(shoot, aim, data, my_data)
	DeadLocke:inform_law_enforcements(data)	
end