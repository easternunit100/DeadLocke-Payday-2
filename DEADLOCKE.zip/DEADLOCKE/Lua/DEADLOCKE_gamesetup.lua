local update_trigger_area = GameSetup.update
function GameSetup:update(t, dt)
	if DeadLockeMissionScriptElement then
		if DeadLockeMissionScriptElement._triggers then
			for _, element in pairs(DeadLockeMissionScriptElement._triggers) do
				if element then
					if element.update_area then
						element:update_area()
					end	
				end
			end
		end
	end
	return update_trigger_area(self, t, dt)
end

