local update_trigger_area = GameSetup.update
function GameSetup:update(t, dt)	
	if DeadLocke then
		DeadLocke:update_sound_playbacks(t, dt)
		if DeadLocke.DeadLockeMissionManager then
			DeadLocke.DeadLockeMissionManager:update(t, dt)
		end
	end

	return update_trigger_area(self, t, dt)
end

