if not SoundSource  then
	return
end

DeadLocke.SoundSource = DeadLocke.SoundSource or blt_class()
local DeadLocke_SoundSource = DeadLocke.SoundSource

function DeadLocke_SoundSource:init()
	self._switches = {}
	self._mapped_prefixes = {}
	self._linking_pos = nil
	self._linking = nil
end
function DeadLocke_SoundSource:get_switch()
	return self._switches
end

function DeadLocke_SoundSource:get_prefixes()
	return self:get_data().mapped_prefixes
end

function DeadLocke_SoundSource:set_link_object(object)
	self._linking = object
end

function DeadLocke_SoundSource:stop(object)
end

function DeadLocke_SoundSource:link(object)
	self._linking = object
end

function DeadLocke_SoundSource:link_position(pos)
	self._linking_pos = pos
end

function DeadLocke_SoundSource:set_position(object)
	self._linking = object
end

function DeadLocke_SoundSource:set_switch(group, state)
	self._group = group
	self._state = state
end

local _SoundSource_post_event = SoundSource.post_event
function SoundSource:post_event(event, clbk, cookie, ...)
	local playback = DeadLocke:_get_heister_sound_playback_from_id(event, self._state)
	if playback then
		return playback:play({type = "playersound", post_event_data	= {event, clbk, cookie, ..})
	else
		return _SoundSource_post_event(self, event, clbk, cookie, ...)
	end
end