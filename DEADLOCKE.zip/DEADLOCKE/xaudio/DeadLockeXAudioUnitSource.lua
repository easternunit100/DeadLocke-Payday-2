local C = blt_class(XAudio.Source)

XAudio.DeadLockeUnitSource = C

function C:init(unit, ...)
	self.super.init(self, ...)
	self._unit = unit
end


local function _get_maxixmum_vector(pos1, pos2)	
	local x = (pos1.x + pos2.x) / 2
	x = (pos1.x + x) / 2
	local y = (pos1.y + pos2.y) / 2
	y = (pos1.y + y) / 2
	local z = (pos1.z + pos2.z) / 2
	z = (pos1.z + z) / 2
	return Vector3(x, y, z)
end

function C:update(...)
	self.super.update(self, ...)
	
	if self:is_closed() then 
		return 
	end

	local unit = self._unit
	if self._unit == XAudio.PLAYER then
		unit = XAudio._player_unit
	end
	
	local cam_position
	local viewport = managers.viewport:first_active_viewport()
	if viewport then
		local cam = viewport:camera()
		if cam then
			cam_position = cam:position()
		end
	end
	
	if not alive(unit) or not cam_position then
		self:close()
		return
	end

	local pos
	if unit == XAudio._player_unit then
		pos = unit:position()
	else
		pos = _get_maxixmum_vector(cam_position, unit:position())		
	end
	
	
	self:set_position(pos)
	-- TODO velocity and direction
end